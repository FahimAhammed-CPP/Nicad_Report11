package android.support.v7.widget;

import android.content.Context;
import android.content.res.Configuration;
import android.content.res.Resources;
import android.graphics.drawable.Drawable;
import android.os.Parcel;
import android.os.Parcelable;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v4.graphics.drawable.DrawableCompat;
import android.support.v4.view.ActionProvider;
import android.support.v7.appcompat.R;
import android.support.v7.view.ActionBarPolicy;
import android.support.v7.view.menu.ActionMenuItemView;
import android.support.v7.view.menu.BaseMenuPresenter;
import android.support.v7.view.menu.MenuBuilder;
import android.support.v7.view.menu.MenuItemImpl;
import android.support.v7.view.menu.MenuPopupHelper;
import android.support.v7.view.menu.MenuPresenter;
import android.support.v7.view.menu.MenuView;
import android.support.v7.view.menu.ShowableListMenu;
import android.support.v7.view.menu.SubMenuBuilder;
import android.util.AttributeSet;
import android.util.SparseBooleanArray;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import java.util.ArrayList;

class ActionMenuPresenter extends BaseMenuPresenter implements ActionProvider.SubUiVisibilityListener {
  private static final String TAG = "ActionMenuPresenter";
  
  private final SparseBooleanArray mActionButtonGroups = new SparseBooleanArray();
  
  ActionButtonSubmenu mActionButtonPopup;
  
  private int mActionItemWidthLimit;
  
  private boolean mExpandedActionViewsExclusive;
  
  private int mMaxItems;
  
  private boolean mMaxItemsSet;
  
  private int mMinCellSize;
  
  int mOpenSubMenuId;
  
  OverflowMenuButton mOverflowButton;
  
  OverflowPopup mOverflowPopup;
  
  private Drawable mPendingOverflowIcon;
  
  private boolean mPendingOverflowIconSet;
  
  private ActionMenuPopupCallback mPopupCallback;
  
  final PopupPresenterCallback mPopupPresenterCallback = new PopupPresenterCallback();
  
  OpenOverflowRunnable mPostedOpenRunnable;
  
  private boolean mReserveOverflow;
  
  private boolean mReserveOverflowSet;
  
  private View mScrapActionButtonView;
  
  private boolean mStrictWidthLimit;
  
  private int mWidthLimit;
  
  private boolean mWidthLimitSet;
  
  public ActionMenuPresenter(Context paramContext) {
    super(paramContext, R.layout.abc_action_menu_layout, R.layout.abc_action_menu_item_layout);
  }
  
  private View findViewForItem(MenuItem paramMenuItem) {
    ViewGroup viewGroup = (ViewGroup)this.mMenuView;
    if (viewGroup == null)
      return null; 
    int j = viewGroup.getChildCount();
    for (int i = 0; i < j; i++) {
      View view = viewGroup.getChildAt(i);
      if (view instanceof MenuView.ItemView && ((MenuView.ItemView)view).getItemData() == paramMenuItem)
        return view; 
    } 
    return null;
  }
  
  public void bindItemView(MenuItemImpl paramMenuItemImpl, MenuView.ItemView paramItemView) {
    paramItemView.initialize(paramMenuItemImpl, 0);
    ActionMenuView actionMenuView = (ActionMenuView)this.mMenuView;
    ActionMenuItemView actionMenuItemView = (ActionMenuItemView)paramItemView;
    actionMenuItemView.setItemInvoker(actionMenuView);
    if (this.mPopupCallback == null)
      this.mPopupCallback = new ActionMenuPopupCallback(); 
    actionMenuItemView.setPopupCallback(this.mPopupCallback);
  }
  
  public boolean dismissPopupMenus() {
    return hideOverflowMenu() | hideSubMenus();
  }
  
  public boolean filterLeftoverView(ViewGroup paramViewGroup, int paramInt) {
    return (paramViewGroup.getChildAt(paramInt) == this.mOverflowButton) ? false : super.filterLeftoverView(paramViewGroup, paramInt);
  }
  
  public boolean flagActionItems() {
    // Byte code:
    //   0: aload_0
    //   1: astore #15
    //   3: aload #15
    //   5: getfield mMenu : Landroid/support/v7/view/menu/MenuBuilder;
    //   8: ifnull -> 31
    //   11: aload #15
    //   13: getfield mMenu : Landroid/support/v7/view/menu/MenuBuilder;
    //   16: invokevirtual getVisibleItems : ()Ljava/util/ArrayList;
    //   19: astore #14
    //   21: aload #14
    //   23: invokevirtual size : ()I
    //   26: istore #4
    //   28: goto -> 37
    //   31: aconst_null
    //   32: astore #14
    //   34: iconst_0
    //   35: istore #4
    //   37: aload #15
    //   39: getfield mMaxItems : I
    //   42: istore_1
    //   43: aload #15
    //   45: getfield mActionItemWidthLimit : I
    //   48: istore #8
    //   50: iconst_0
    //   51: iconst_0
    //   52: invokestatic makeMeasureSpec : (II)I
    //   55: istore #10
    //   57: aload #15
    //   59: getfield mMenuView : Landroid/support/v7/view/menu/MenuView;
    //   62: checkcast android/view/ViewGroup
    //   65: astore #16
    //   67: iconst_0
    //   68: istore_3
    //   69: iconst_0
    //   70: istore #5
    //   72: iconst_0
    //   73: istore #6
    //   75: iconst_0
    //   76: istore_2
    //   77: iload_3
    //   78: iload #4
    //   80: if_icmpge -> 164
    //   83: aload #14
    //   85: iload_3
    //   86: invokevirtual get : (I)Ljava/lang/Object;
    //   89: checkcast android/support/v7/view/menu/MenuItemImpl
    //   92: astore #17
    //   94: aload #17
    //   96: invokevirtual requiresActionButton : ()Z
    //   99: ifeq -> 111
    //   102: iload #5
    //   104: iconst_1
    //   105: iadd
    //   106: istore #5
    //   108: goto -> 129
    //   111: aload #17
    //   113: invokevirtual requestsActionButton : ()Z
    //   116: ifeq -> 126
    //   119: iload_2
    //   120: iconst_1
    //   121: iadd
    //   122: istore_2
    //   123: goto -> 129
    //   126: iconst_1
    //   127: istore #6
    //   129: iload_1
    //   130: istore #7
    //   132: aload #15
    //   134: getfield mExpandedActionViewsExclusive : Z
    //   137: ifeq -> 154
    //   140: iload_1
    //   141: istore #7
    //   143: aload #17
    //   145: invokevirtual isActionViewExpanded : ()Z
    //   148: ifeq -> 154
    //   151: iconst_0
    //   152: istore #7
    //   154: iload_3
    //   155: iconst_1
    //   156: iadd
    //   157: istore_3
    //   158: iload #7
    //   160: istore_1
    //   161: goto -> 77
    //   164: iload_1
    //   165: istore_3
    //   166: aload #15
    //   168: getfield mReserveOverflow : Z
    //   171: ifeq -> 193
    //   174: iload #6
    //   176: ifne -> 189
    //   179: iload_1
    //   180: istore_3
    //   181: iload_2
    //   182: iload #5
    //   184: iadd
    //   185: iload_1
    //   186: if_icmple -> 193
    //   189: iload_1
    //   190: iconst_1
    //   191: isub
    //   192: istore_3
    //   193: iload_3
    //   194: iload #5
    //   196: isub
    //   197: istore_1
    //   198: aload #15
    //   200: getfield mActionButtonGroups : Landroid/util/SparseBooleanArray;
    //   203: astore #17
    //   205: aload #17
    //   207: invokevirtual clear : ()V
    //   210: aload #15
    //   212: getfield mStrictWidthLimit : Z
    //   215: ifeq -> 254
    //   218: iload #8
    //   220: aload #15
    //   222: getfield mMinCellSize : I
    //   225: idiv
    //   226: istore_3
    //   227: aload #15
    //   229: getfield mMinCellSize : I
    //   232: istore_2
    //   233: aload #15
    //   235: getfield mMinCellSize : I
    //   238: istore #5
    //   240: iload #8
    //   242: iload_2
    //   243: irem
    //   244: iload_3
    //   245: idiv
    //   246: iload #5
    //   248: iadd
    //   249: istore #6
    //   251: goto -> 259
    //   254: iconst_0
    //   255: istore_3
    //   256: iconst_0
    //   257: istore #6
    //   259: iload #8
    //   261: istore #5
    //   263: iconst_0
    //   264: istore #8
    //   266: iconst_0
    //   267: istore_2
    //   268: iload #4
    //   270: istore #7
    //   272: aload_0
    //   273: astore #15
    //   275: iload #8
    //   277: iload #7
    //   279: if_icmpge -> 805
    //   282: aload #14
    //   284: iload #8
    //   286: invokevirtual get : (I)Ljava/lang/Object;
    //   289: checkcast android/support/v7/view/menu/MenuItemImpl
    //   292: astore #18
    //   294: aload #18
    //   296: invokevirtual requiresActionButton : ()Z
    //   299: ifeq -> 423
    //   302: aload #15
    //   304: aload #18
    //   306: aload #15
    //   308: getfield mScrapActionButtonView : Landroid/view/View;
    //   311: aload #16
    //   313: invokevirtual getItemView : (Landroid/support/v7/view/menu/MenuItemImpl;Landroid/view/View;Landroid/view/ViewGroup;)Landroid/view/View;
    //   316: astore #19
    //   318: aload #15
    //   320: getfield mScrapActionButtonView : Landroid/view/View;
    //   323: ifnonnull -> 333
    //   326: aload #15
    //   328: aload #19
    //   330: putfield mScrapActionButtonView : Landroid/view/View;
    //   333: aload #15
    //   335: getfield mStrictWidthLimit : Z
    //   338: ifeq -> 358
    //   341: iload_3
    //   342: aload #19
    //   344: iload #6
    //   346: iload_3
    //   347: iload #10
    //   349: iconst_0
    //   350: invokestatic measureChildForCells : (Landroid/view/View;IIII)I
    //   353: isub
    //   354: istore_3
    //   355: goto -> 367
    //   358: aload #19
    //   360: iload #10
    //   362: iload #10
    //   364: invokevirtual measure : (II)V
    //   367: aload #19
    //   369: invokevirtual getMeasuredWidth : ()I
    //   372: istore #4
    //   374: iload #5
    //   376: iload #4
    //   378: isub
    //   379: istore #5
    //   381: iload_2
    //   382: ifne -> 391
    //   385: iload #4
    //   387: istore_2
    //   388: goto -> 391
    //   391: aload #18
    //   393: invokevirtual getGroupId : ()I
    //   396: istore #4
    //   398: iload #4
    //   400: ifeq -> 414
    //   403: aload #17
    //   405: iload #4
    //   407: iconst_1
    //   408: invokevirtual put : (IZ)V
    //   411: goto -> 414
    //   414: aload #18
    //   416: iconst_1
    //   417: invokevirtual setIsActionButton : (Z)V
    //   420: goto -> 796
    //   423: aload #18
    //   425: invokevirtual requestsActionButton : ()Z
    //   428: ifeq -> 790
    //   431: aload #18
    //   433: invokevirtual getGroupId : ()I
    //   436: istore #11
    //   438: aload #17
    //   440: iload #11
    //   442: invokevirtual get : (I)Z
    //   445: istore #13
    //   447: iload_1
    //   448: ifgt -> 456
    //   451: iload #13
    //   453: ifeq -> 479
    //   456: iload #5
    //   458: ifle -> 479
    //   461: aload #15
    //   463: getfield mStrictWidthLimit : Z
    //   466: ifeq -> 473
    //   469: iload_3
    //   470: ifle -> 479
    //   473: iconst_1
    //   474: istore #12
    //   476: goto -> 482
    //   479: iconst_0
    //   480: istore #12
    //   482: iload #12
    //   484: ifeq -> 655
    //   487: aload #15
    //   489: aload #18
    //   491: aload #15
    //   493: getfield mScrapActionButtonView : Landroid/view/View;
    //   496: aload #16
    //   498: invokevirtual getItemView : (Landroid/support/v7/view/menu/MenuItemImpl;Landroid/view/View;Landroid/view/ViewGroup;)Landroid/view/View;
    //   501: astore #19
    //   503: aload #15
    //   505: getfield mScrapActionButtonView : Landroid/view/View;
    //   508: ifnonnull -> 518
    //   511: aload #15
    //   513: aload #19
    //   515: putfield mScrapActionButtonView : Landroid/view/View;
    //   518: aload #15
    //   520: getfield mStrictWidthLimit : Z
    //   523: ifeq -> 562
    //   526: aload #19
    //   528: iload #6
    //   530: iload_3
    //   531: iload #10
    //   533: iconst_0
    //   534: invokestatic measureChildForCells : (Landroid/view/View;IIII)I
    //   537: istore #9
    //   539: iload_3
    //   540: iload #9
    //   542: isub
    //   543: istore #4
    //   545: iload #4
    //   547: istore_3
    //   548: iload #9
    //   550: ifne -> 571
    //   553: iconst_0
    //   554: istore #12
    //   556: iload #4
    //   558: istore_3
    //   559: goto -> 571
    //   562: aload #19
    //   564: iload #10
    //   566: iload #10
    //   568: invokevirtual measure : (II)V
    //   571: aload #19
    //   573: invokevirtual getMeasuredWidth : ()I
    //   576: istore #9
    //   578: iload #5
    //   580: iload #9
    //   582: isub
    //   583: istore #5
    //   585: iload_2
    //   586: istore #4
    //   588: iload_2
    //   589: ifne -> 596
    //   592: iload #9
    //   594: istore #4
    //   596: aload #15
    //   598: getfield mStrictWidthLimit : Z
    //   601: ifeq -> 628
    //   604: iload #5
    //   606: iflt -> 614
    //   609: iconst_1
    //   610: istore_2
    //   611: goto -> 616
    //   614: iconst_0
    //   615: istore_2
    //   616: iload #12
    //   618: iload_2
    //   619: iand
    //   620: istore #12
    //   622: iload #4
    //   624: istore_2
    //   625: goto -> 655
    //   628: iload #5
    //   630: iload #4
    //   632: iadd
    //   633: ifle -> 641
    //   636: iconst_1
    //   637: istore_2
    //   638: goto -> 643
    //   641: iconst_0
    //   642: istore_2
    //   643: iload #12
    //   645: iload_2
    //   646: iand
    //   647: istore #12
    //   649: iload #4
    //   651: istore_2
    //   652: goto -> 655
    //   655: iload #12
    //   657: ifeq -> 679
    //   660: iload #11
    //   662: ifeq -> 679
    //   665: aload #17
    //   667: iload #11
    //   669: iconst_1
    //   670: invokevirtual put : (IZ)V
    //   673: iload_1
    //   674: istore #4
    //   676: goto -> 767
    //   679: iload_1
    //   680: istore #4
    //   682: iload #13
    //   684: ifeq -> 767
    //   687: aload #17
    //   689: iload #11
    //   691: iconst_0
    //   692: invokevirtual put : (IZ)V
    //   695: iconst_0
    //   696: istore #9
    //   698: iload_1
    //   699: istore #4
    //   701: iload #9
    //   703: iload #8
    //   705: if_icmpge -> 767
    //   708: aload #14
    //   710: iload #9
    //   712: invokevirtual get : (I)Ljava/lang/Object;
    //   715: checkcast android/support/v7/view/menu/MenuItemImpl
    //   718: astore #15
    //   720: iload_1
    //   721: istore #4
    //   723: aload #15
    //   725: invokevirtual getGroupId : ()I
    //   728: iload #11
    //   730: if_icmpne -> 755
    //   733: iload_1
    //   734: istore #4
    //   736: aload #15
    //   738: invokevirtual isActionButton : ()Z
    //   741: ifeq -> 749
    //   744: iload_1
    //   745: iconst_1
    //   746: iadd
    //   747: istore #4
    //   749: aload #15
    //   751: iconst_0
    //   752: invokevirtual setIsActionButton : (Z)V
    //   755: iload #9
    //   757: iconst_1
    //   758: iadd
    //   759: istore #9
    //   761: iload #4
    //   763: istore_1
    //   764: goto -> 698
    //   767: iload #4
    //   769: istore_1
    //   770: iload #12
    //   772: ifeq -> 780
    //   775: iload #4
    //   777: iconst_1
    //   778: isub
    //   779: istore_1
    //   780: aload #18
    //   782: iload #12
    //   784: invokevirtual setIsActionButton : (Z)V
    //   787: goto -> 420
    //   790: aload #18
    //   792: iconst_0
    //   793: invokevirtual setIsActionButton : (Z)V
    //   796: iload #8
    //   798: iconst_1
    //   799: iadd
    //   800: istore #8
    //   802: goto -> 272
    //   805: iconst_1
    //   806: ireturn
  }
  
  public View getItemView(MenuItemImpl paramMenuItemImpl, View paramView, ViewGroup paramViewGroup) {
    boolean bool;
    View view = paramMenuItemImpl.getActionView();
    if (view == null || paramMenuItemImpl.hasCollapsibleActionView())
      view = super.getItemView(paramMenuItemImpl, paramView, paramViewGroup); 
    if (paramMenuItemImpl.isActionViewExpanded()) {
      bool = true;
    } else {
      bool = false;
    } 
    view.setVisibility(bool);
    ActionMenuView actionMenuView = (ActionMenuView)paramViewGroup;
    ViewGroup.LayoutParams layoutParams = view.getLayoutParams();
    if (!actionMenuView.checkLayoutParams(layoutParams))
      view.setLayoutParams((ViewGroup.LayoutParams)actionMenuView.generateLayoutParams(layoutParams)); 
    return view;
  }
  
  public MenuView getMenuView(ViewGroup paramViewGroup) {
    MenuView menuView2 = this.mMenuView;
    MenuView menuView1 = super.getMenuView(paramViewGroup);
    if (menuView2 != menuView1)
      ((ActionMenuView)menuView1).setPresenter(this); 
    return menuView1;
  }
  
  public Drawable getOverflowIcon() {
    return (this.mOverflowButton != null) ? this.mOverflowButton.getDrawable() : (this.mPendingOverflowIconSet ? this.mPendingOverflowIcon : null);
  }
  
  public boolean hideOverflowMenu() {
    if (this.mPostedOpenRunnable != null && this.mMenuView != null) {
      ((View)this.mMenuView).removeCallbacks(this.mPostedOpenRunnable);
      this.mPostedOpenRunnable = null;
      return true;
    } 
    OverflowPopup overflowPopup = this.mOverflowPopup;
    if (overflowPopup != null) {
      overflowPopup.dismiss();
      return true;
    } 
    return false;
  }
  
  public boolean hideSubMenus() {
    if (this.mActionButtonPopup != null) {
      this.mActionButtonPopup.dismiss();
      return true;
    } 
    return false;
  }
  
  public void initForMenu(@NonNull Context paramContext, @Nullable MenuBuilder paramMenuBuilder) {
    super.initForMenu(paramContext, paramMenuBuilder);
    Resources resources = paramContext.getResources();
    ActionBarPolicy actionBarPolicy = ActionBarPolicy.get(paramContext);
    if (!this.mReserveOverflowSet)
      this.mReserveOverflow = actionBarPolicy.showsOverflowMenuButton(); 
    if (!this.mWidthLimitSet)
      this.mWidthLimit = actionBarPolicy.getEmbeddedMenuWidthLimit(); 
    if (!this.mMaxItemsSet)
      this.mMaxItems = actionBarPolicy.getMaxActionButtons(); 
    int i = this.mWidthLimit;
    if (this.mReserveOverflow) {
      if (this.mOverflowButton == null) {
        this.mOverflowButton = new OverflowMenuButton(this.mSystemContext);
        if (this.mPendingOverflowIconSet) {
          this.mOverflowButton.setImageDrawable(this.mPendingOverflowIcon);
          this.mPendingOverflowIcon = null;
          this.mPendingOverflowIconSet = false;
        } 
        int j = View.MeasureSpec.makeMeasureSpec(0, 0);
        this.mOverflowButton.measure(j, j);
      } 
      i -= this.mOverflowButton.getMeasuredWidth();
    } else {
      this.mOverflowButton = null;
    } 
    this.mActionItemWidthLimit = i;
    this.mMinCellSize = (int)((resources.getDisplayMetrics()).density * 56.0F);
    this.mScrapActionButtonView = null;
  }
  
  public boolean isOverflowMenuShowPending() {
    return (this.mPostedOpenRunnable != null || isOverflowMenuShowing());
  }
  
  public boolean isOverflowMenuShowing() {
    return (this.mOverflowPopup != null && this.mOverflowPopup.isShowing());
  }
  
  public boolean isOverflowReserved() {
    return this.mReserveOverflow;
  }
  
  public void onCloseMenu(MenuBuilder paramMenuBuilder, boolean paramBoolean) {
    dismissPopupMenus();
    super.onCloseMenu(paramMenuBuilder, paramBoolean);
  }
  
  public void onConfigurationChanged(Configuration paramConfiguration) {
    if (!this.mMaxItemsSet)
      this.mMaxItems = ActionBarPolicy.get(this.mContext).getMaxActionButtons(); 
    if (this.mMenu != null)
      this.mMenu.onItemsChanged(true); 
  }
  
  public void onRestoreInstanceState(Parcelable paramParcelable) {
    if (!(paramParcelable instanceof SavedState))
      return; 
    paramParcelable = paramParcelable;
    if (((SavedState)paramParcelable).openSubMenuId > 0) {
      MenuItem menuItem = this.mMenu.findItem(((SavedState)paramParcelable).openSubMenuId);
      if (menuItem != null)
        onSubMenuSelected((SubMenuBuilder)menuItem.getSubMenu()); 
    } 
  }
  
  public Parcelable onSaveInstanceState() {
    SavedState savedState = new SavedState();
    savedState.openSubMenuId = this.mOpenSubMenuId;
    return savedState;
  }
  
  public boolean onSubMenuSelected(SubMenuBuilder paramSubMenuBuilder) {
    boolean bool = paramSubMenuBuilder.hasVisibleItems();
    boolean bool1 = false;
    if (!bool)
      return false; 
    SubMenuBuilder subMenuBuilder;
    for (subMenuBuilder = paramSubMenuBuilder; subMenuBuilder.getParentMenu() != this.mMenu; subMenuBuilder = (SubMenuBuilder)subMenuBuilder.getParentMenu());
    View view = findViewForItem(subMenuBuilder.getItem());
    if (view == null)
      return false; 
    this.mOpenSubMenuId = paramSubMenuBuilder.getItem().getItemId();
    int j = paramSubMenuBuilder.size();
    int i = 0;
    while (true) {
      bool = bool1;
      if (i < j) {
        MenuItem menuItem = paramSubMenuBuilder.getItem(i);
        if (menuItem.isVisible() && menuItem.getIcon() != null) {
          bool = true;
          break;
        } 
        i++;
        continue;
      } 
      break;
    } 
    this.mActionButtonPopup = new ActionButtonSubmenu(this.mContext, paramSubMenuBuilder, view);
    this.mActionButtonPopup.setForceShowIcon(bool);
    this.mActionButtonPopup.show();
    super.onSubMenuSelected(paramSubMenuBuilder);
    return true;
  }
  
  public void onSubUiVisibilityChanged(boolean paramBoolean) {
    if (paramBoolean) {
      super.onSubMenuSelected(null);
      return;
    } 
    if (this.mMenu != null)
      this.mMenu.close(false); 
  }
  
  public void setExpandedActionViewsExclusive(boolean paramBoolean) {
    this.mExpandedActionViewsExclusive = paramBoolean;
  }
  
  public void setItemLimit(int paramInt) {
    this.mMaxItems = paramInt;
    this.mMaxItemsSet = true;
  }
  
  public void setMenuView(ActionMenuView paramActionMenuView) {
    this.mMenuView = paramActionMenuView;
    paramActionMenuView.initialize(this.mMenu);
  }
  
  public void setOverflowIcon(Drawable paramDrawable) {
    if (this.mOverflowButton != null) {
      this.mOverflowButton.setImageDrawable(paramDrawable);
      return;
    } 
    this.mPendingOverflowIconSet = true;
    this.mPendingOverflowIcon = paramDrawable;
  }
  
  public void setReserveOverflow(boolean paramBoolean) {
    this.mReserveOverflow = paramBoolean;
    this.mReserveOverflowSet = true;
  }
  
  public void setWidthLimit(int paramInt, boolean paramBoolean) {
    this.mWidthLimit = paramInt;
    this.mStrictWidthLimit = paramBoolean;
    this.mWidthLimitSet = true;
  }
  
  public boolean shouldIncludeItem(int paramInt, MenuItemImpl paramMenuItemImpl) {
    return paramMenuItemImpl.isActionButton();
  }
  
  public boolean showOverflowMenu() {
    if (this.mReserveOverflow && !isOverflowMenuShowing() && this.mMenu != null && this.mMenuView != null && this.mPostedOpenRunnable == null && !this.mMenu.getNonActionItems().isEmpty()) {
      this.mPostedOpenRunnable = new OpenOverflowRunnable(new OverflowPopup(this.mContext, this.mMenu, (View)this.mOverflowButton, true));
      ((View)this.mMenuView).post(this.mPostedOpenRunnable);
      super.onSubMenuSelected(null);
      return true;
    } 
    return false;
  }
  
  public void updateMenuView(boolean paramBoolean) {
    super.updateMenuView(paramBoolean);
    ((View)this.mMenuView).requestLayout();
    MenuBuilder<MenuItemImpl> menuBuilder = this.mMenu;
    byte b = 0;
    if (menuBuilder != null) {
      ArrayList<MenuItemImpl> arrayList = this.mMenu.getActionItems();
      int k = arrayList.size();
      for (int j = 0; j < k; j++) {
        ActionProvider actionProvider = ((MenuItemImpl)arrayList.get(j)).getSupportActionProvider();
        if (actionProvider != null)
          actionProvider.setSubUiVisibilityListener(this); 
      } 
    } 
    if (this.mMenu != null) {
      ArrayList arrayList = this.mMenu.getNonActionItems();
    } else {
      menuBuilder = null;
    } 
    int i = b;
    if (this.mReserveOverflow) {
      i = b;
      if (menuBuilder != null) {
        int j = menuBuilder.size();
        if (j == 1) {
          i = ((MenuItemImpl)menuBuilder.get(0)).isActionViewExpanded() ^ true;
        } else {
          i = b;
          if (j > 0)
            i = 1; 
        } 
      } 
    } 
    if (i != 0) {
      if (this.mOverflowButton == null)
        this.mOverflowButton = new OverflowMenuButton(this.mSystemContext); 
      ViewGroup viewGroup = (ViewGroup)this.mOverflowButton.getParent();
      if (viewGroup != this.mMenuView) {
        if (viewGroup != null)
          viewGroup.removeView((View)this.mOverflowButton); 
        viewGroup = (ActionMenuView)this.mMenuView;
        viewGroup.addView((View)this.mOverflowButton, (ViewGroup.LayoutParams)viewGroup.generateOverflowButtonLayoutParams());
      } 
    } else if (this.mOverflowButton != null && this.mOverflowButton.getParent() == this.mMenuView) {
      ((ViewGroup)this.mMenuView).removeView((View)this.mOverflowButton);
    } 
    ((ActionMenuView)this.mMenuView).setOverflowReserved(this.mReserveOverflow);
  }
  
  private class ActionButtonSubmenu extends MenuPopupHelper {
    public ActionButtonSubmenu(Context param1Context, SubMenuBuilder param1SubMenuBuilder, View param1View) {
      super(param1Context, (MenuBuilder)param1SubMenuBuilder, param1View, false, R.attr.actionOverflowMenuStyle);
      if (!((MenuItemImpl)param1SubMenuBuilder.getItem()).isActionButton()) {
        ActionMenuPresenter.OverflowMenuButton overflowMenuButton;
        if (ActionMenuPresenter.this.mOverflowButton == null) {
          View view = (View)ActionMenuPresenter.this.mMenuView;
        } else {
          overflowMenuButton = ActionMenuPresenter.this.mOverflowButton;
        } 
        setAnchorView((View)overflowMenuButton);
      } 
      setPresenterCallback(ActionMenuPresenter.this.mPopupPresenterCallback);
    }
    
    protected void onDismiss() {
      ActionMenuPresenter.this.mActionButtonPopup = null;
      ActionMenuPresenter.this.mOpenSubMenuId = 0;
      super.onDismiss();
    }
  }
  
  private class ActionMenuPopupCallback extends ActionMenuItemView.PopupCallback {
    public ShowableListMenu getPopup() {
      return (ShowableListMenu)((ActionMenuPresenter.this.mActionButtonPopup != null) ? ActionMenuPresenter.this.mActionButtonPopup.getPopup() : null);
    }
  }
  
  private class OpenOverflowRunnable implements Runnable {
    private ActionMenuPresenter.OverflowPopup mPopup;
    
    public OpenOverflowRunnable(ActionMenuPresenter.OverflowPopup param1OverflowPopup) {
      this.mPopup = param1OverflowPopup;
    }
    
    public void run() {
      if (ActionMenuPresenter.this.mMenu != null)
        ActionMenuPresenter.this.mMenu.changeMenuMode(); 
      View view = (View)ActionMenuPresenter.this.mMenuView;
      if (view != null && view.getWindowToken() != null && this.mPopup.tryShow())
        ActionMenuPresenter.this.mOverflowPopup = this.mPopup; 
      ActionMenuPresenter.this.mPostedOpenRunnable = null;
    }
  }
  
  private class OverflowMenuButton extends AppCompatImageView implements ActionMenuView.ActionMenuChildView {
    private final float[] mTempPts = new float[2];
    
    public OverflowMenuButton(Context param1Context) {
      super(param1Context, (AttributeSet)null, R.attr.actionOverflowButtonStyle);
      setClickable(true);
      setFocusable(true);
      setVisibility(0);
      setEnabled(true);
      TooltipCompat.setTooltipText((View)this, getContentDescription());
      setOnTouchListener(new ForwardingListener((View)this) {
            public ShowableListMenu getPopup() {
              return (ShowableListMenu)((ActionMenuPresenter.this.mOverflowPopup == null) ? null : ActionMenuPresenter.this.mOverflowPopup.getPopup());
            }
            
            public boolean onForwardingStarted() {
              ActionMenuPresenter.this.showOverflowMenu();
              return true;
            }
            
            public boolean onForwardingStopped() {
              if (ActionMenuPresenter.this.mPostedOpenRunnable != null)
                return false; 
              ActionMenuPresenter.this.hideOverflowMenu();
              return true;
            }
          });
    }
    
    public boolean needsDividerAfter() {
      return false;
    }
    
    public boolean needsDividerBefore() {
      return false;
    }
    
    public boolean performClick() {
      if (super.performClick())
        return true; 
      playSoundEffect(0);
      ActionMenuPresenter.this.showOverflowMenu();
      return true;
    }
    
    protected boolean setFrame(int param1Int1, int param1Int2, int param1Int3, int param1Int4) {
      boolean bool = super.setFrame(param1Int1, param1Int2, param1Int3, param1Int4);
      Drawable drawable1 = getDrawable();
      Drawable drawable2 = getBackground();
      if (drawable1 != null && drawable2 != null) {
        int i = getWidth();
        param1Int2 = getHeight();
        param1Int1 = Math.max(i, param1Int2) / 2;
        int j = getPaddingLeft();
        int k = getPaddingRight();
        param1Int3 = getPaddingTop();
        param1Int4 = getPaddingBottom();
        i = (i + j - k) / 2;
        param1Int2 = (param1Int2 + param1Int3 - param1Int4) / 2;
        DrawableCompat.setHotspotBounds(drawable2, i - param1Int1, param1Int2 - param1Int1, i + param1Int1, param1Int2 + param1Int1);
      } 
      return bool;
    }
  }
  
  class null extends ForwardingListener {
    null(View param1View) {
      super(param1View);
    }
    
    public ShowableListMenu getPopup() {
      return (ShowableListMenu)((ActionMenuPresenter.this.mOverflowPopup == null) ? null : ActionMenuPresenter.this.mOverflowPopup.getPopup());
    }
    
    public boolean onForwardingStarted() {
      ActionMenuPresenter.this.showOverflowMenu();
      return true;
    }
    
    public boolean onForwardingStopped() {
      if (ActionMenuPresenter.this.mPostedOpenRunnable != null)
        return false; 
      ActionMenuPresenter.this.hideOverflowMenu();
      return true;
    }
  }
  
  private class OverflowPopup extends MenuPopupHelper {
    public OverflowPopup(Context param1Context, MenuBuilder param1MenuBuilder, View param1View, boolean param1Boolean) {
      super(param1Context, param1MenuBuilder, param1View, param1Boolean, R.attr.actionOverflowMenuStyle);
      setGravity(8388613);
      setPresenterCallback(ActionMenuPresenter.this.mPopupPresenterCallback);
    }
    
    protected void onDismiss() {
      if (ActionMenuPresenter.this.mMenu != null)
        ActionMenuPresenter.this.mMenu.close(); 
      ActionMenuPresenter.this.mOverflowPopup = null;
      super.onDismiss();
    }
  }
  
  private class PopupPresenterCallback implements MenuPresenter.Callback {
    public void onCloseMenu(MenuBuilder param1MenuBuilder, boolean param1Boolean) {
      if (param1MenuBuilder instanceof SubMenuBuilder)
        param1MenuBuilder.getRootMenu().close(false); 
      MenuPresenter.Callback callback = ActionMenuPresenter.this.getCallback();
      if (callback != null)
        callback.onCloseMenu(param1MenuBuilder, param1Boolean); 
    }
    
    public boolean onOpenSubMenu(MenuBuilder param1MenuBuilder) {
      boolean bool = false;
      if (param1MenuBuilder == null)
        return false; 
      ActionMenuPresenter.this.mOpenSubMenuId = ((SubMenuBuilder)param1MenuBuilder).getItem().getItemId();
      MenuPresenter.Callback callback = ActionMenuPresenter.this.getCallback();
      if (callback != null)
        bool = callback.onOpenSubMenu(param1MenuBuilder); 
      return bool;
    }
  }
  
  private static class SavedState implements Parcelable {
    public static final Parcelable.Creator<SavedState> CREATOR = new Parcelable.Creator<SavedState>() {
        public ActionMenuPresenter.SavedState createFromParcel(Parcel param2Parcel) {
          return new ActionMenuPresenter.SavedState(param2Parcel);
        }
        
        public ActionMenuPresenter.SavedState[] newArray(int param2Int) {
          return new ActionMenuPresenter.SavedState[param2Int];
        }
      };
    
    public int openSubMenuId;
    
    SavedState() {}
    
    SavedState(Parcel param1Parcel) {
      this.openSubMenuId = param1Parcel.readInt();
    }
    
    public int describeContents() {
      return 0;
    }
    
    public void writeToParcel(Parcel param1Parcel, int param1Int) {
      param1Parcel.writeInt(this.openSubMenuId);
    }
  }
  
  static final class null implements Parcelable.Creator<SavedState> {
    public ActionMenuPresenter.SavedState createFromParcel(Parcel param1Parcel) {
      return new ActionMenuPresenter.SavedState(param1Parcel);
    }
    
    public ActionMenuPresenter.SavedState[] newArray(int param1Int) {
      return new ActionMenuPresenter.SavedState[param1Int];
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\9 Ball Pool-dex2jar.jar!\android\support\v7\widget\ActionMenuPresenter.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */
package android.arch.lifecycle.viewmodel;

public final class BuildConfig {
  public static final String APPLICATION_ID = "android.arch.lifecycle.viewmodel";
  
  public static final String BUILD_TYPE = "release";
  
  public static final boolean DEBUG = false;
  
  public static final String FLAVOR = "";
  
  public static final int VERSION_CODE = -1;
  
  public static final String VERSION_NAME = "";
}


/* Location:              C:\soft\dex2jar-2.0\9 Ball Pool-dex2jar.jar!\android\arch\lifecycle\viewmodel\BuildConfig.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */
package android.support.v7.graphics;

import android.support.annotation.FloatRange;
import android.support.annotation.NonNull;

public final class Target {
  public static final Target DARK_MUTED;
  
  public static final Target DARK_VIBRANT;
  
  static final int INDEX_MAX = 2;
  
  static final int INDEX_MIN = 0;
  
  static final int INDEX_TARGET = 1;
  
  static final int INDEX_WEIGHT_LUMA = 1;
  
  static final int INDEX_WEIGHT_POP = 2;
  
  static final int INDEX_WEIGHT_SAT = 0;
  
  public static final Target LIGHT_MUTED;
  
  public static final Target LIGHT_VIBRANT = new Target();
  
  private static final float MAX_DARK_LUMA = 0.45F;
  
  private static final float MAX_MUTED_SATURATION = 0.4F;
  
  private static final float MAX_NORMAL_LUMA = 0.7F;
  
  private static final float MIN_LIGHT_LUMA = 0.55F;
  
  private static final float MIN_NORMAL_LUMA = 0.3F;
  
  private static final float MIN_VIBRANT_SATURATION = 0.35F;
  
  public static final Target MUTED;
  
  private static final float TARGET_DARK_LUMA = 0.26F;
  
  private static final float TARGET_LIGHT_LUMA = 0.74F;
  
  private static final float TARGET_MUTED_SATURATION = 0.3F;
  
  private static final float TARGET_NORMAL_LUMA = 0.5F;
  
  private static final float TARGET_VIBRANT_SATURATION = 1.0F;
  
  public static final Target VIBRANT = new Target();
  
  private static final float WEIGHT_LUMA = 0.52F;
  
  private static final float WEIGHT_POPULATION = 0.24F;
  
  private static final float WEIGHT_SATURATION = 0.24F;
  
  boolean mIsExclusive = true;
  
  final float[] mLightnessTargets = new float[3];
  
  final float[] mSaturationTargets = new float[3];
  
  final float[] mWeights = new float[3];
  
  static {
    setDefaultNormalLightnessValues(VIBRANT);
    setDefaultVibrantSaturationValues(VIBRANT);
    DARK_VIBRANT = new Target();
    setDefaultDarkLightnessValues(DARK_VIBRANT);
    setDefaultVibrantSaturationValues(DARK_VIBRANT);
    LIGHT_MUTED = new Target();
    setDefaultLightLightnessValues(LIGHT_MUTED);
    setDefaultMutedSaturationValues(LIGHT_MUTED);
    MUTED = new Target();
    setDefaultNormalLightnessValues(MUTED);
    setDefaultMutedSaturationValues(MUTED);
    DARK_MUTED = new Target();
    setDefaultDarkLightnessValues(DARK_MUTED);
    setDefaultMutedSaturationValues(DARK_MUTED);
  }
  
  Target() {
    setTargetDefaultValues(this.mSaturationTargets);
    setTargetDefaultValues(this.mLightnessTargets);
    setDefaultWeights();
  }
  
  Target(@NonNull Target paramTarget) {
    System.arraycopy(paramTarget.mSaturationTargets, 0, this.mSaturationTargets, 0, this.mSaturationTargets.length);
    System.arraycopy(paramTarget.mLightnessTargets, 0, this.mLightnessTargets, 0, this.mLightnessTargets.length);
    System.arraycopy(paramTarget.mWeights, 0, this.mWeights, 0, this.mWeights.length);
  }
  
  private static void setDefaultDarkLightnessValues(Target paramTarget) {
    paramTarget.mLightnessTargets[1] = 0.26F;
    paramTarget.mLightnessTargets[2] = 0.45F;
  }
  
  private static void setDefaultLightLightnessValues(Target paramTarget) {
    paramTarget.mLightnessTargets[0] = 0.55F;
    paramTarget.mLightnessTargets[1] = 0.74F;
  }
  
  private static void setDefaultMutedSaturationValues(Target paramTarget) {
    paramTarget.mSaturationTargets[1] = 0.3F;
    paramTarget.mSaturationTargets[2] = 0.4F;
  }
  
  private static void setDefaultNormalLightnessValues(Target paramTarget) {
    paramTarget.mLightnessTargets[0] = 0.3F;
    paramTarget.mLightnessTargets[1] = 0.5F;
    paramTarget.mLightnessTargets[2] = 0.7F;
  }
  
  private static void setDefaultVibrantSaturationValues(Target paramTarget) {
    paramTarget.mSaturationTargets[0] = 0.35F;
    paramTarget.mSaturationTargets[1] = 1.0F;
  }
  
  private void setDefaultWeights() {
    this.mWeights[0] = 0.24F;
    this.mWeights[1] = 0.52F;
    this.mWeights[2] = 0.24F;
  }
  
  private static void setTargetDefaultValues(float[] paramArrayOffloat) {
    paramArrayOffloat[0] = 0.0F;
    paramArrayOffloat[1] = 0.5F;
    paramArrayOffloat[2] = 1.0F;
  }
  
  public float getLightnessWeight() {
    return this.mWeights[1];
  }
  
  @FloatRange(from = 0.0D, to = 1.0D)
  public float getMaximumLightness() {
    return this.mLightnessTargets[2];
  }
  
  @FloatRange(from = 0.0D, to = 1.0D)
  public float getMaximumSaturation() {
    return this.mSaturationTargets[2];
  }
  
  @FloatRange(from = 0.0D, to = 1.0D)
  public float getMinimumLightness() {
    return this.mLightnessTargets[0];
  }
  
  @FloatRange(from = 0.0D, to = 1.0D)
  public float getMinimumSaturation() {
    return this.mSaturationTargets[0];
  }
  
  public float getPopulationWeight() {
    return this.mWeights[2];
  }
  
  public float getSaturationWeight() {
    return this.mWeights[0];
  }
  
  @FloatRange(from = 0.0D, to = 1.0D)
  public float getTargetLightness() {
    return this.mLightnessTargets[1];
  }
  
  @FloatRange(from = 0.0D, to = 1.0D)
  public float getTargetSaturation() {
    return this.mSaturationTargets[1];
  }
  
  public boolean isExclusive() {
    return this.mIsExclusive;
  }
  
  void normalizeWeights() {
    int j = this.mWeights.length;
    boolean bool = false;
    int i = 0;
    float f;
    for (f = 0.0F; i < j; f = f1) {
      float f2 = this.mWeights[i];
      float f1 = f;
      if (f2 > 0.0F)
        f1 = f + f2; 
      i++;
    } 
    if (f != 0.0F) {
      j = this.mWeights.length;
      for (i = bool; i < j; i++) {
        if (this.mWeights[i] > 0.0F) {
          float[] arrayOfFloat = this.mWeights;
          arrayOfFloat[i] = arrayOfFloat[i] / f;
        } 
      } 
    } 
  }
  
  static {
    setDefaultLightLightnessValues(LIGHT_VIBRANT);
    setDefaultVibrantSaturationValues(LIGHT_VIBRANT);
  }
  
  public static final class Builder {
    private final Target mTarget = new Target();
    
    public Builder() {}
    
    public Builder(@NonNull Target param1Target) {}
    
    @NonNull
    public Target build() {
      return this.mTarget;
    }
    
    @NonNull
    public Builder setExclusive(boolean param1Boolean) {
      this.mTarget.mIsExclusive = param1Boolean;
      return this;
    }
    
    @NonNull
    public Builder setLightnessWeight(@FloatRange(from = 0.0D) float param1Float) {
      this.mTarget.mWeights[1] = param1Float;
      return this;
    }
    
    @NonNull
    public Builder setMaximumLightness(@FloatRange(from = 0.0D, to = 1.0D) float param1Float) {
      this.mTarget.mLightnessTargets[2] = param1Float;
      return this;
    }
    
    @NonNull
    public Builder setMaximumSaturation(@FloatRange(from = 0.0D, to = 1.0D) float param1Float) {
      this.mTarget.mSaturationTargets[2] = param1Float;
      return this;
    }
    
    @NonNull
    public Builder setMinimumLightness(@FloatRange(from = 0.0D, to = 1.0D) float param1Float) {
      this.mTarget.mLightnessTargets[0] = param1Float;
      return this;
    }
    
    @NonNull
    public Builder setMinimumSaturation(@FloatRange(from = 0.0D, to = 1.0D) float param1Float) {
      this.mTarget.mSaturationTargets[0] = param1Float;
      return this;
    }
    
    @NonNull
    public Builder setPopulationWeight(@FloatRange(from = 0.0D) float param1Float) {
      this.mTarget.mWeights[2] = param1Float;
      return this;
    }
    
    @NonNull
    public Builder setSaturationWeight(@FloatRange(from = 0.0D) float param1Float) {
      this.mTarget.mWeights[0] = param1Float;
      return this;
    }
    
    @NonNull
    public Builder setTargetLightness(@FloatRange(from = 0.0D, to = 1.0D) float param1Float) {
      this.mTarget.mLightnessTargets[1] = param1Float;
      return this;
    }
    
    @NonNull
    public Builder setTargetSaturation(@FloatRange(from = 0.0D, to = 1.0D) float param1Float) {
      this.mTarget.mSaturationTargets[1] = param1Float;
      return this;
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\9 Ball Pool-dex2jar.jar!\android\support\v7\graphics\Target.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */
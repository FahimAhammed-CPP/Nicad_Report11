package android.support.v7.graphics.drawable;

import android.content.Context;
import android.content.res.TypedArray;
import android.graphics.Canvas;
import android.graphics.ColorFilter;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.drawable.Drawable;
import android.support.annotation.ColorInt;
import android.support.annotation.FloatRange;
import android.support.annotation.RestrictTo;
import android.support.v7.appcompat.R;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;

public class DrawerArrowDrawable extends Drawable {
  public static final int ARROW_DIRECTION_END = 3;
  
  public static final int ARROW_DIRECTION_LEFT = 0;
  
  public static final int ARROW_DIRECTION_RIGHT = 1;
  
  public static final int ARROW_DIRECTION_START = 2;
  
  private static final float ARROW_HEAD_ANGLE = (float)Math.toRadians(45.0D);
  
  private float mArrowHeadLength;
  
  private float mArrowShaftLength;
  
  private float mBarGap;
  
  private float mBarLength;
  
  private int mDirection = 2;
  
  private float mMaxCutForBarSize;
  
  private final Paint mPaint = new Paint();
  
  private final Path mPath = new Path();
  
  private float mProgress;
  
  private final int mSize;
  
  private boolean mSpin;
  
  private boolean mVerticalMirror = false;
  
  public DrawerArrowDrawable(Context paramContext) {
    this.mPaint.setStyle(Paint.Style.STROKE);
    this.mPaint.setStrokeJoin(Paint.Join.MITER);
    this.mPaint.setStrokeCap(Paint.Cap.BUTT);
    this.mPaint.setAntiAlias(true);
    TypedArray typedArray = paramContext.getTheme().obtainStyledAttributes(null, R.styleable.DrawerArrowToggle, R.attr.drawerArrowStyle, R.style.Base_Widget_AppCompat_DrawerArrowToggle);
    setColor(typedArray.getColor(R.styleable.DrawerArrowToggle_color, 0));
    setBarThickness(typedArray.getDimension(R.styleable.DrawerArrowToggle_thickness, 0.0F));
    setSpinEnabled(typedArray.getBoolean(R.styleable.DrawerArrowToggle_spinBars, true));
    setGapSize(Math.round(typedArray.getDimension(R.styleable.DrawerArrowToggle_gapBetweenBars, 0.0F)));
    this.mSize = typedArray.getDimensionPixelSize(R.styleable.DrawerArrowToggle_drawableSize, 0);
    this.mBarLength = Math.round(typedArray.getDimension(R.styleable.DrawerArrowToggle_barLength, 0.0F));
    this.mArrowHeadLength = Math.round(typedArray.getDimension(R.styleable.DrawerArrowToggle_arrowHeadLength, 0.0F));
    this.mArrowShaftLength = typedArray.getDimension(R.styleable.DrawerArrowToggle_arrowShaftLength, 0.0F);
    typedArray.recycle();
  }
  
  private static float lerp(float paramFloat1, float paramFloat2, float paramFloat3) {
    return paramFloat1 + (paramFloat2 - paramFloat1) * paramFloat3;
  }
  
  public void draw(Canvas paramCanvas) {
    // Byte code:
    //   0: aload_0
    //   1: invokevirtual getBounds : ()Landroid/graphics/Rect;
    //   4: astore #19
    //   6: aload_0
    //   7: getfield mDirection : I
    //   10: istore #18
    //   12: iconst_0
    //   13: istore #17
    //   15: iconst_1
    //   16: istore #16
    //   18: iload #18
    //   20: iconst_3
    //   21: if_icmpeq -> 70
    //   24: iload #17
    //   26: istore #15
    //   28: iload #18
    //   30: tableswitch default -> 52, 0 -> 84, 1 -> 64
    //   52: iload #17
    //   54: istore #15
    //   56: aload_0
    //   57: invokestatic getLayoutDirection : (Landroid/graphics/drawable/Drawable;)I
    //   60: iconst_1
    //   61: if_icmpne -> 84
    //   64: iconst_1
    //   65: istore #15
    //   67: goto -> 84
    //   70: iload #17
    //   72: istore #15
    //   74: aload_0
    //   75: invokestatic getLayoutDirection : (Landroid/graphics/drawable/Drawable;)I
    //   78: ifne -> 84
    //   81: goto -> 64
    //   84: aload_0
    //   85: getfield mArrowHeadLength : F
    //   88: aload_0
    //   89: getfield mArrowHeadLength : F
    //   92: fmul
    //   93: fconst_2
    //   94: fmul
    //   95: f2d
    //   96: invokestatic sqrt : (D)D
    //   99: d2f
    //   100: fstore #8
    //   102: aload_0
    //   103: getfield mBarLength : F
    //   106: fload #8
    //   108: aload_0
    //   109: getfield mProgress : F
    //   112: invokestatic lerp : (FFF)F
    //   115: fstore #12
    //   117: aload_0
    //   118: getfield mBarLength : F
    //   121: aload_0
    //   122: getfield mArrowShaftLength : F
    //   125: aload_0
    //   126: getfield mProgress : F
    //   129: invokestatic lerp : (FFF)F
    //   132: fstore #10
    //   134: fconst_0
    //   135: aload_0
    //   136: getfield mMaxCutForBarSize : F
    //   139: aload_0
    //   140: getfield mProgress : F
    //   143: invokestatic lerp : (FFF)F
    //   146: invokestatic round : (F)I
    //   149: i2f
    //   150: fstore #11
    //   152: fconst_0
    //   153: getstatic android/support/v7/graphics/drawable/DrawerArrowDrawable.ARROW_HEAD_ANGLE : F
    //   156: aload_0
    //   157: getfield mProgress : F
    //   160: invokestatic lerp : (FFF)F
    //   163: fstore #13
    //   165: iload #15
    //   167: ifeq -> 176
    //   170: fconst_0
    //   171: fstore #8
    //   173: goto -> 180
    //   176: ldc -180.0
    //   178: fstore #8
    //   180: iload #15
    //   182: ifeq -> 192
    //   185: ldc 180.0
    //   187: fstore #9
    //   189: goto -> 195
    //   192: fconst_0
    //   193: fstore #9
    //   195: fload #8
    //   197: fload #9
    //   199: aload_0
    //   200: getfield mProgress : F
    //   203: invokestatic lerp : (FFF)F
    //   206: fstore #8
    //   208: fload #12
    //   210: f2d
    //   211: dstore_2
    //   212: fload #13
    //   214: f2d
    //   215: dstore #4
    //   217: dload #4
    //   219: invokestatic cos : (D)D
    //   222: dstore #6
    //   224: dload_2
    //   225: invokestatic isNaN : (D)Z
    //   228: pop
    //   229: dload #6
    //   231: dload_2
    //   232: dmul
    //   233: invokestatic round : (D)J
    //   236: l2f
    //   237: fstore #9
    //   239: dload #4
    //   241: invokestatic sin : (D)D
    //   244: dstore #4
    //   246: dload_2
    //   247: invokestatic isNaN : (D)Z
    //   250: pop
    //   251: dload_2
    //   252: dload #4
    //   254: dmul
    //   255: invokestatic round : (D)J
    //   258: l2f
    //   259: fstore #12
    //   261: aload_0
    //   262: getfield mPath : Landroid/graphics/Path;
    //   265: invokevirtual rewind : ()V
    //   268: aload_0
    //   269: getfield mBarGap : F
    //   272: aload_0
    //   273: getfield mPaint : Landroid/graphics/Paint;
    //   276: invokevirtual getStrokeWidth : ()F
    //   279: fadd
    //   280: aload_0
    //   281: getfield mMaxCutForBarSize : F
    //   284: fneg
    //   285: aload_0
    //   286: getfield mProgress : F
    //   289: invokestatic lerp : (FFF)F
    //   292: fstore #13
    //   294: fload #10
    //   296: fneg
    //   297: fconst_2
    //   298: fdiv
    //   299: fstore #14
    //   301: aload_0
    //   302: getfield mPath : Landroid/graphics/Path;
    //   305: fload #14
    //   307: fload #11
    //   309: fadd
    //   310: fconst_0
    //   311: invokevirtual moveTo : (FF)V
    //   314: aload_0
    //   315: getfield mPath : Landroid/graphics/Path;
    //   318: fload #10
    //   320: fload #11
    //   322: fconst_2
    //   323: fmul
    //   324: fsub
    //   325: fconst_0
    //   326: invokevirtual rLineTo : (FF)V
    //   329: aload_0
    //   330: getfield mPath : Landroid/graphics/Path;
    //   333: fload #14
    //   335: fload #13
    //   337: invokevirtual moveTo : (FF)V
    //   340: aload_0
    //   341: getfield mPath : Landroid/graphics/Path;
    //   344: fload #9
    //   346: fload #12
    //   348: invokevirtual rLineTo : (FF)V
    //   351: aload_0
    //   352: getfield mPath : Landroid/graphics/Path;
    //   355: fload #14
    //   357: fload #13
    //   359: fneg
    //   360: invokevirtual moveTo : (FF)V
    //   363: aload_0
    //   364: getfield mPath : Landroid/graphics/Path;
    //   367: fload #9
    //   369: fload #12
    //   371: fneg
    //   372: invokevirtual rLineTo : (FF)V
    //   375: aload_0
    //   376: getfield mPath : Landroid/graphics/Path;
    //   379: invokevirtual close : ()V
    //   382: aload_1
    //   383: invokevirtual save : ()I
    //   386: pop
    //   387: aload_0
    //   388: getfield mPaint : Landroid/graphics/Paint;
    //   391: invokevirtual getStrokeWidth : ()F
    //   394: fstore #9
    //   396: aload #19
    //   398: invokevirtual height : ()I
    //   401: i2f
    //   402: ldc_w 3.0
    //   405: fload #9
    //   407: fmul
    //   408: fsub
    //   409: aload_0
    //   410: getfield mBarGap : F
    //   413: fconst_2
    //   414: fmul
    //   415: fsub
    //   416: f2i
    //   417: iconst_4
    //   418: idiv
    //   419: iconst_2
    //   420: imul
    //   421: i2f
    //   422: fstore #10
    //   424: aload_0
    //   425: getfield mBarGap : F
    //   428: fstore #11
    //   430: aload_1
    //   431: aload #19
    //   433: invokevirtual centerX : ()I
    //   436: i2f
    //   437: fload #10
    //   439: fload #9
    //   441: ldc_w 1.5
    //   444: fmul
    //   445: fload #11
    //   447: fadd
    //   448: fadd
    //   449: invokevirtual translate : (FF)V
    //   452: aload_0
    //   453: getfield mSpin : Z
    //   456: ifeq -> 485
    //   459: aload_0
    //   460: getfield mVerticalMirror : Z
    //   463: iload #15
    //   465: ixor
    //   466: ifeq -> 472
    //   469: iconst_m1
    //   470: istore #16
    //   472: aload_1
    //   473: fload #8
    //   475: iload #16
    //   477: i2f
    //   478: fmul
    //   479: invokevirtual rotate : (F)V
    //   482: goto -> 496
    //   485: iload #15
    //   487: ifeq -> 496
    //   490: aload_1
    //   491: ldc 180.0
    //   493: invokevirtual rotate : (F)V
    //   496: aload_1
    //   497: aload_0
    //   498: getfield mPath : Landroid/graphics/Path;
    //   501: aload_0
    //   502: getfield mPaint : Landroid/graphics/Paint;
    //   505: invokevirtual drawPath : (Landroid/graphics/Path;Landroid/graphics/Paint;)V
    //   508: aload_1
    //   509: invokevirtual restore : ()V
    //   512: return
  }
  
  public float getArrowHeadLength() {
    return this.mArrowHeadLength;
  }
  
  public float getArrowShaftLength() {
    return this.mArrowShaftLength;
  }
  
  public float getBarLength() {
    return this.mBarLength;
  }
  
  public float getBarThickness() {
    return this.mPaint.getStrokeWidth();
  }
  
  @ColorInt
  public int getColor() {
    return this.mPaint.getColor();
  }
  
  public int getDirection() {
    return this.mDirection;
  }
  
  public float getGapSize() {
    return this.mBarGap;
  }
  
  public int getIntrinsicHeight() {
    return this.mSize;
  }
  
  public int getIntrinsicWidth() {
    return this.mSize;
  }
  
  public int getOpacity() {
    return -3;
  }
  
  public final Paint getPaint() {
    return this.mPaint;
  }
  
  @FloatRange(from = 0.0D, to = 1.0D)
  public float getProgress() {
    return this.mProgress;
  }
  
  public boolean isSpinEnabled() {
    return this.mSpin;
  }
  
  public void setAlpha(int paramInt) {
    if (paramInt != this.mPaint.getAlpha()) {
      this.mPaint.setAlpha(paramInt);
      invalidateSelf();
    } 
  }
  
  public void setArrowHeadLength(float paramFloat) {
    if (this.mArrowHeadLength != paramFloat) {
      this.mArrowHeadLength = paramFloat;
      invalidateSelf();
    } 
  }
  
  public void setArrowShaftLength(float paramFloat) {
    if (this.mArrowShaftLength != paramFloat) {
      this.mArrowShaftLength = paramFloat;
      invalidateSelf();
    } 
  }
  
  public void setBarLength(float paramFloat) {
    if (this.mBarLength != paramFloat) {
      this.mBarLength = paramFloat;
      invalidateSelf();
    } 
  }
  
  public void setBarThickness(float paramFloat) {
    if (this.mPaint.getStrokeWidth() != paramFloat) {
      this.mPaint.setStrokeWidth(paramFloat);
      double d1 = (paramFloat / 2.0F);
      double d2 = Math.cos(ARROW_HEAD_ANGLE);
      Double.isNaN(d1);
      this.mMaxCutForBarSize = (float)(d1 * d2);
      invalidateSelf();
    } 
  }
  
  public void setColor(@ColorInt int paramInt) {
    if (paramInt != this.mPaint.getColor()) {
      this.mPaint.setColor(paramInt);
      invalidateSelf();
    } 
  }
  
  public void setColorFilter(ColorFilter paramColorFilter) {
    this.mPaint.setColorFilter(paramColorFilter);
    invalidateSelf();
  }
  
  public void setDirection(int paramInt) {
    if (paramInt != this.mDirection) {
      this.mDirection = paramInt;
      invalidateSelf();
    } 
  }
  
  public void setGapSize(float paramFloat) {
    if (paramFloat != this.mBarGap) {
      this.mBarGap = paramFloat;
      invalidateSelf();
    } 
  }
  
  public void setProgress(@FloatRange(from = 0.0D, to = 1.0D) float paramFloat) {
    if (this.mProgress != paramFloat) {
      this.mProgress = paramFloat;
      invalidateSelf();
    } 
  }
  
  public void setSpinEnabled(boolean paramBoolean) {
    if (this.mSpin != paramBoolean) {
      this.mSpin = paramBoolean;
      invalidateSelf();
    } 
  }
  
  public void setVerticalMirror(boolean paramBoolean) {
    if (this.mVerticalMirror != paramBoolean) {
      this.mVerticalMirror = paramBoolean;
      invalidateSelf();
    } 
  }
  
  @Retention(RetentionPolicy.SOURCE)
  @RestrictTo({RestrictTo.Scope.LIBRARY_GROUP})
  public static @interface ArrowDirection {}
}


/* Location:              C:\soft\dex2jar-2.0\9 Ball Pool-dex2jar.jar!\android\support\v7\graphics\drawable\DrawerArrowDrawable.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */
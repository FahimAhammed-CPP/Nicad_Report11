package android.support.fragment;

public final class R {
  public static final class attr {
    public static final int coordinatorLayoutStyle = 2130837611;
    
    public static final int font = 2130837636;
    
    public static final int fontProviderAuthority = 2130837638;
    
    public static final int fontProviderCerts = 2130837639;
    
    public static final int fontProviderFetchStrategy = 2130837640;
    
    public static final int fontProviderFetchTimeout = 2130837641;
    
    public static final int fontProviderPackage = 2130837642;
    
    public static final int fontProviderQuery = 2130837643;
    
    public static final int fontStyle = 2130837644;
    
    public static final int fontWeight = 2130837645;
    
    public static final int keylines = 2130837666;
    
    public static final int layout_anchor = 2130837669;
    
    public static final int layout_anchorGravity = 2130837670;
    
    public static final int layout_behavior = 2130837671;
    
    public static final int layout_dodgeInsetEdges = 2130837672;
    
    public static final int layout_insetEdge = 2130837673;
    
    public static final int layout_keyline = 2130837674;
    
    public static final int statusBarBackground = 2130837749;
  }
  
  public static final class bool {
    public static final int abc_action_bar_embed_tabs = 2130903040;
  }
  
  public static final class color {
    public static final int notification_action_color_filter = 2130968654;
    
    public static final int notification_icon_bg_color = 2130968655;
    
    public static final int ripple_material_light = 2130968666;
    
    public static final int secondary_text_default_material_light = 2130968668;
  }
  
  public static final class dimen {
    public static final int compat_button_inset_horizontal_material = 2131034191;
    
    public static final int compat_button_inset_vertical_material = 2131034192;
    
    public static final int compat_button_padding_horizontal_material = 2131034193;
    
    public static final int compat_button_padding_vertical_material = 2131034194;
    
    public static final int compat_control_corner_material = 2131034195;
    
    public static final int notification_action_icon_size = 2131034211;
    
    public static final int notification_action_text_size = 2131034212;
    
    public static final int notification_big_circle_margin = 2131034213;
    
    public static final int notification_content_margin_start = 2131034214;
    
    public static final int notification_large_icon_height = 2131034215;
    
    public static final int notification_large_icon_width = 2131034216;
    
    public static final int notification_main_column_padding_top = 2131034217;
    
    public static final int notification_media_narrow_margin = 2131034218;
    
    public static final int notification_right_icon_size = 2131034219;
    
    public static final int notification_right_side_padding_top = 2131034220;
    
    public static final int notification_small_icon_background_padding = 2131034221;
    
    public static final int notification_small_icon_size_as_large = 2131034222;
    
    public static final int notification_subtext_size = 2131034223;
    
    public static final int notification_top_pad = 2131034224;
    
    public static final int notification_top_pad_large_text = 2131034225;
  }
  
  public static final class drawable {
    public static final int notification_action_background = 2131099791;
    
    public static final int notification_bg = 2131099792;
    
    public static final int notification_bg_low = 2131099793;
    
    public static final int notification_bg_low_normal = 2131099794;
    
    public static final int notification_bg_low_pressed = 2131099795;
    
    public static final int notification_bg_normal = 2131099796;
    
    public static final int notification_bg_normal_pressed = 2131099797;
    
    public static final int notification_icon_background = 2131099798;
    
    public static final int notification_template_icon_bg = 2131099799;
    
    public static final int notification_template_icon_low_bg = 2131099800;
    
    public static final int notification_tile_bg = 2131099801;
    
    public static final int notify_panel_notification_icon_bg = 2131099802;
  }
  
  public static final class id {
    public static final int action_container = 2131165200;
    
    public static final int action_divider = 2131165202;
    
    public static final int action_image = 2131165203;
    
    public static final int action_text = 2131165209;
    
    public static final int actions = 2131165210;
    
    public static final int async = 2131165221;
    
    public static final int blocking = 2131165226;
    
    public static final int bottom = 2131165227;
    
    public static final int chronometer = 2131165238;
    
    public static final int end = 2131165257;
    
    public static final int forever = 2131165266;
    
    public static final int icon = 2131165273;
    
    public static final int icon_group = 2131165274;
    
    public static final int info = 2131165283;
    
    public static final int italic = 2131165285;
    
    public static final int left = 2131165314;
    
    public static final int line1 = 2131165319;
    
    public static final int line3 = 2131165320;
    
    public static final int none = 2131165351;
    
    public static final int normal = 2131165352;
    
    public static final int notification_background = 2131165353;
    
    public static final int notification_main_column = 2131165354;
    
    public static final int notification_main_column_container = 2131165355;
    
    public static final int right = 2131165370;
    
    public static final int right_icon = 2131165371;
    
    public static final int right_side = 2131165372;
    
    public static final int start = 2131165484;
    
    public static final int tag_transition_group = 2131165489;
    
    public static final int text = 2131165490;
    
    public static final int text2 = 2131165491;
    
    public static final int time = 2131165494;
    
    public static final int title = 2131165498;
    
    public static final int top = 2131165501;
  }
  
  public static final class integer {
    public static final int status_bar_notification_info_maxnum = 2131230725;
  }
  
  public static final class layout {
    public static final int notification_action = 2131296308;
    
    public static final int notification_action_tombstone = 2131296309;
    
    public static final int notification_template_custom_big = 2131296316;
    
    public static final int notification_template_icon_group = 2131296317;
    
    public static final int notification_template_part_chronometer = 2131296321;
    
    public static final int notification_template_part_time = 2131296322;
  }
  
  public static final class string {
    public static final int status_bar_notification_info_overflow = 2131427462;
  }
  
  public static final class style {
    public static final int TextAppearance_Compat_Notification = 2131493094;
    
    public static final int TextAppearance_Compat_Notification_Info = 2131493095;
    
    public static final int TextAppearance_Compat_Notification_Line2 = 2131493097;
    
    public static final int TextAppearance_Compat_Notification_Time = 2131493100;
    
    public static final int TextAppearance_Compat_Notification_Title = 2131493102;
    
    public static final int Widget_Compat_NotificationActionContainer = 2131493209;
    
    public static final int Widget_Compat_NotificationActionText = 2131493210;
    
    public static final int Widget_Support_CoordinatorLayout = 2131493211;
  }
  
  public static final class styleable {
    public static final int[] CoordinatorLayout = new int[] { 2130837666, 2130837749 };
    
    public static final int[] CoordinatorLayout_Layout = new int[] { 16842931, 2130837669, 2130837670, 2130837671, 2130837672, 2130837673, 2130837674 };
    
    public static final int CoordinatorLayout_Layout_android_layout_gravity = 0;
    
    public static final int CoordinatorLayout_Layout_layout_anchor = 1;
    
    public static final int CoordinatorLayout_Layout_layout_anchorGravity = 2;
    
    public static final int CoordinatorLayout_Layout_layout_behavior = 3;
    
    public static final int CoordinatorLayout_Layout_layout_dodgeInsetEdges = 4;
    
    public static final int CoordinatorLayout_Layout_layout_insetEdge = 5;
    
    public static final int CoordinatorLayout_Layout_layout_keyline = 6;
    
    public static final int CoordinatorLayout_keylines = 0;
    
    public static final int CoordinatorLayout_statusBarBackground = 1;
    
    public static final int[] FontFamily = new int[] { 2130837638, 2130837639, 2130837640, 2130837641, 2130837642, 2130837643 };
    
    public static final int[] FontFamilyFont = new int[] { 16844082, 16844083, 16844095, 2130837636, 2130837644, 2130837645 };
    
    public static final int FontFamilyFont_android_font = 0;
    
    public static final int FontFamilyFont_android_fontStyle = 2;
    
    public static final int FontFamilyFont_android_fontWeight = 1;
    
    public static final int FontFamilyFont_font = 3;
    
    public static final int FontFamilyFont_fontStyle = 4;
    
    public static final int FontFamilyFont_fontWeight = 5;
    
    public static final int FontFamily_fontProviderAuthority = 0;
    
    public static final int FontFamily_fontProviderCerts = 1;
    
    public static final int FontFamily_fontProviderFetchStrategy = 2;
    
    public static final int FontFamily_fontProviderFetchTimeout = 3;
    
    public static final int FontFamily_fontProviderPackage = 4;
    
    public static final int FontFamily_fontProviderQuery = 5;
  }
}


/* Location:              C:\soft\dex2jar-2.0\9 Ball Pool-dex2jar.jar!\android\support\fragment\R.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */
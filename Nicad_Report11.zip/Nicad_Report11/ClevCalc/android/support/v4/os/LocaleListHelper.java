package android.support.v4.os;

import android.os.Build;
import android.support.annotation.GuardedBy;
import android.support.annotation.IntRange;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.annotation.RequiresApi;
import android.support.annotation.RestrictTo;
import android.support.annotation.Size;
import java.util.Arrays;
import java.util.Collection;
import java.util.HashSet;
import java.util.Locale;

@RequiresApi(14)
@RestrictTo({RestrictTo.Scope.LIBRARY_GROUP})
final class LocaleListHelper {
  private static final Locale EN_LATN;
  
  private static final Locale LOCALE_AR_XB;
  
  private static final Locale LOCALE_EN_XA;
  
  private static final int NUM_PSEUDO_LOCALES = 2;
  
  private static final String STRING_AR_XB = "ar-XB";
  
  private static final String STRING_EN_XA = "en-XA";
  
  @GuardedBy("sLock")
  private static LocaleListHelper sDefaultAdjustedLocaleList;
  
  @GuardedBy("sLock")
  private static LocaleListHelper sDefaultLocaleList;
  
  private static final Locale[] sEmptyList = new Locale[0];
  
  private static final LocaleListHelper sEmptyLocaleList = new LocaleListHelper(new Locale[0]);
  
  @GuardedBy("sLock")
  private static Locale sLastDefaultLocale;
  
  @GuardedBy("sLock")
  private static LocaleListHelper sLastExplicitlySetLocaleList;
  
  private static final Object sLock;
  
  private final Locale[] mList;
  
  @NonNull
  private final String mStringRepresentation;
  
  static {
    LOCALE_EN_XA = new Locale("en", "XA");
    LOCALE_AR_XB = new Locale("ar", "XB");
    EN_LATN = LocaleHelper.forLanguageTag("en-Latn");
    sLock = new Object();
    sLastExplicitlySetLocaleList = null;
    sDefaultLocaleList = null;
    sDefaultAdjustedLocaleList = null;
    sLastDefaultLocale = null;
  }
  
  @RestrictTo({RestrictTo.Scope.LIBRARY_GROUP})
  LocaleListHelper(@NonNull Locale paramLocale, LocaleListHelper paramLocaleListHelper) {
    // Byte code:
    //   0: aload_0
    //   1: invokespecial <init> : ()V
    //   4: aload_1
    //   5: ifnull -> 280
    //   8: iconst_0
    //   9: istore #6
    //   11: aload_2
    //   12: ifnonnull -> 21
    //   15: iconst_0
    //   16: istore #4
    //   18: goto -> 28
    //   21: aload_2
    //   22: getfield mList : [Ljava/util/Locale;
    //   25: arraylength
    //   26: istore #4
    //   28: iconst_0
    //   29: istore_3
    //   30: iload_3
    //   31: iload #4
    //   33: if_icmpge -> 59
    //   36: aload_1
    //   37: aload_2
    //   38: getfield mList : [Ljava/util/Locale;
    //   41: iload_3
    //   42: aaload
    //   43: invokevirtual equals : (Ljava/lang/Object;)Z
    //   46: ifeq -> 52
    //   49: goto -> 61
    //   52: iload_3
    //   53: iconst_1
    //   54: iadd
    //   55: istore_3
    //   56: goto -> 30
    //   59: iconst_m1
    //   60: istore_3
    //   61: iload_3
    //   62: iconst_m1
    //   63: if_icmpne -> 72
    //   66: iconst_1
    //   67: istore #5
    //   69: goto -> 75
    //   72: iconst_0
    //   73: istore #5
    //   75: iload #5
    //   77: iload #4
    //   79: iadd
    //   80: istore #8
    //   82: iload #8
    //   84: anewarray java/util/Locale
    //   87: astore #9
    //   89: aload #9
    //   91: iconst_0
    //   92: aload_1
    //   93: invokevirtual clone : ()Ljava/lang/Object;
    //   96: checkcast java/util/Locale
    //   99: aastore
    //   100: iload_3
    //   101: iconst_m1
    //   102: if_icmpne -> 141
    //   105: iconst_0
    //   106: istore_3
    //   107: iload_3
    //   108: iload #4
    //   110: if_icmpge -> 214
    //   113: iload_3
    //   114: iconst_1
    //   115: iadd
    //   116: istore #5
    //   118: aload #9
    //   120: iload #5
    //   122: aload_2
    //   123: getfield mList : [Ljava/util/Locale;
    //   126: iload_3
    //   127: aaload
    //   128: invokevirtual clone : ()Ljava/lang/Object;
    //   131: checkcast java/util/Locale
    //   134: aastore
    //   135: iload #5
    //   137: istore_3
    //   138: goto -> 107
    //   141: iconst_0
    //   142: istore #5
    //   144: iload #5
    //   146: iload_3
    //   147: if_icmpge -> 181
    //   150: iload #5
    //   152: iconst_1
    //   153: iadd
    //   154: istore #7
    //   156: aload #9
    //   158: iload #7
    //   160: aload_2
    //   161: getfield mList : [Ljava/util/Locale;
    //   164: iload #5
    //   166: aaload
    //   167: invokevirtual clone : ()Ljava/lang/Object;
    //   170: checkcast java/util/Locale
    //   173: aastore
    //   174: iload #7
    //   176: istore #5
    //   178: goto -> 144
    //   181: iload_3
    //   182: iconst_1
    //   183: iadd
    //   184: istore_3
    //   185: iload_3
    //   186: iload #4
    //   188: if_icmpge -> 214
    //   191: aload #9
    //   193: iload_3
    //   194: aload_2
    //   195: getfield mList : [Ljava/util/Locale;
    //   198: iload_3
    //   199: aaload
    //   200: invokevirtual clone : ()Ljava/lang/Object;
    //   203: checkcast java/util/Locale
    //   206: aastore
    //   207: iload_3
    //   208: iconst_1
    //   209: iadd
    //   210: istore_3
    //   211: goto -> 185
    //   214: new java/lang/StringBuilder
    //   217: dup
    //   218: invokespecial <init> : ()V
    //   221: astore_1
    //   222: iload #6
    //   224: istore_3
    //   225: iload_3
    //   226: iload #8
    //   228: if_icmpge -> 265
    //   231: aload_1
    //   232: aload #9
    //   234: iload_3
    //   235: aaload
    //   236: invokestatic toLanguageTag : (Ljava/util/Locale;)Ljava/lang/String;
    //   239: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   242: pop
    //   243: iload_3
    //   244: iload #8
    //   246: iconst_1
    //   247: isub
    //   248: if_icmpge -> 258
    //   251: aload_1
    //   252: bipush #44
    //   254: invokevirtual append : (C)Ljava/lang/StringBuilder;
    //   257: pop
    //   258: iload_3
    //   259: iconst_1
    //   260: iadd
    //   261: istore_3
    //   262: goto -> 225
    //   265: aload_0
    //   266: aload #9
    //   268: putfield mList : [Ljava/util/Locale;
    //   271: aload_0
    //   272: aload_1
    //   273: invokevirtual toString : ()Ljava/lang/String;
    //   276: putfield mStringRepresentation : Ljava/lang/String;
    //   279: return
    //   280: new java/lang/NullPointerException
    //   283: dup
    //   284: ldc 'topLocale is null'
    //   286: invokespecial <init> : (Ljava/lang/String;)V
    //   289: athrow
  }
  
  @RestrictTo({RestrictTo.Scope.LIBRARY_GROUP})
  LocaleListHelper(@NonNull Locale... paramVarArgs) {
    if (paramVarArgs.length == 0) {
      this.mList = sEmptyList;
      this.mStringRepresentation = "";
      return;
    } 
    Locale[] arrayOfLocale = new Locale[paramVarArgs.length];
    HashSet<Locale> hashSet = new HashSet();
    StringBuilder stringBuilder = new StringBuilder();
    int i = 0;
    while (i < paramVarArgs.length) {
      Locale locale = paramVarArgs[i];
      if (locale != null) {
        if (!hashSet.contains(locale)) {
          locale = (Locale)locale.clone();
          arrayOfLocale[i] = locale;
          stringBuilder.append(LocaleHelper.toLanguageTag(locale));
          if (i < paramVarArgs.length - 1)
            stringBuilder.append(','); 
          hashSet.add(locale);
          i++;
          continue;
        } 
        StringBuilder stringBuilder2 = new StringBuilder();
        stringBuilder2.append("list[");
        stringBuilder2.append(i);
        stringBuilder2.append("] is a repetition");
        throw new IllegalArgumentException(stringBuilder2.toString());
      } 
      StringBuilder stringBuilder1 = new StringBuilder();
      stringBuilder1.append("list[");
      stringBuilder1.append(i);
      stringBuilder1.append("] is null");
      throw new NullPointerException(stringBuilder1.toString());
    } 
    this.mList = arrayOfLocale;
    this.mStringRepresentation = stringBuilder.toString();
  }
  
  private Locale computeFirstMatch(Collection<String> paramCollection, boolean paramBoolean) {
    int i = computeFirstMatchIndex(paramCollection, paramBoolean);
    return (i == -1) ? null : this.mList[i];
  }
  
  private int computeFirstMatchIndex(Collection<String> paramCollection, boolean paramBoolean) {
    // Byte code:
    //   0: aload_0
    //   1: getfield mList : [Ljava/util/Locale;
    //   4: arraylength
    //   5: iconst_1
    //   6: if_icmpne -> 11
    //   9: iconst_0
    //   10: ireturn
    //   11: aload_0
    //   12: getfield mList : [Ljava/util/Locale;
    //   15: arraylength
    //   16: ifne -> 21
    //   19: iconst_m1
    //   20: ireturn
    //   21: iload_2
    //   22: ifeq -> 48
    //   25: aload_0
    //   26: getstatic android/support/v4/os/LocaleListHelper.EN_LATN : Ljava/util/Locale;
    //   29: invokespecial findFirstMatchIndex : (Ljava/util/Locale;)I
    //   32: istore_3
    //   33: iload_3
    //   34: ifne -> 39
    //   37: iconst_0
    //   38: ireturn
    //   39: iload_3
    //   40: ldc 2147483647
    //   42: if_icmpge -> 48
    //   45: goto -> 51
    //   48: ldc 2147483647
    //   50: istore_3
    //   51: aload_1
    //   52: invokeinterface iterator : ()Ljava/util/Iterator;
    //   57: astore_1
    //   58: aload_1
    //   59: invokeinterface hasNext : ()Z
    //   64: ifeq -> 104
    //   67: aload_0
    //   68: aload_1
    //   69: invokeinterface next : ()Ljava/lang/Object;
    //   74: checkcast java/lang/String
    //   77: invokestatic forLanguageTag : (Ljava/lang/String;)Ljava/util/Locale;
    //   80: invokespecial findFirstMatchIndex : (Ljava/util/Locale;)I
    //   83: istore #4
    //   85: iload #4
    //   87: ifne -> 92
    //   90: iconst_0
    //   91: ireturn
    //   92: iload #4
    //   94: iload_3
    //   95: if_icmpge -> 58
    //   98: iload #4
    //   100: istore_3
    //   101: goto -> 58
    //   104: iload_3
    //   105: ldc 2147483647
    //   107: if_icmpne -> 112
    //   110: iconst_0
    //   111: ireturn
    //   112: iload_3
    //   113: ireturn
  }
  
  private int findFirstMatchIndex(Locale paramLocale) {
    for (int i = 0; i < this.mList.length; i++) {
      if (matchScore(paramLocale, this.mList[i]) > 0)
        return i; 
    } 
    return Integer.MAX_VALUE;
  }
  
  @NonNull
  @RestrictTo({RestrictTo.Scope.LIBRARY_GROUP})
  static LocaleListHelper forLanguageTags(@Nullable String paramString) {
    if (paramString == null || paramString.isEmpty())
      return getEmptyLocaleList(); 
    String[] arrayOfString = paramString.split(",");
    Locale[] arrayOfLocale = new Locale[arrayOfString.length];
    for (int i = 0; i < arrayOfLocale.length; i++)
      arrayOfLocale[i] = LocaleHelper.forLanguageTag(arrayOfString[i]); 
    return new LocaleListHelper(arrayOfLocale);
  }
  
  @NonNull
  @Size(min = 1L)
  static LocaleListHelper getAdjustedDefault() {
    getDefault();
    synchronized (sLock) {
      return sDefaultAdjustedLocaleList;
    } 
  }
  
  @NonNull
  @RestrictTo({RestrictTo.Scope.LIBRARY_GROUP})
  @Size(min = 1L)
  static LocaleListHelper getDefault() {
    null = Locale.getDefault();
    synchronized (sLock) {
      if (!null.equals(sLastDefaultLocale)) {
        LocaleListHelper localeListHelper;
        sLastDefaultLocale = null;
        if (sDefaultLocaleList != null && null.equals(sDefaultLocaleList.get(0))) {
          localeListHelper = sDefaultLocaleList;
          return localeListHelper;
        } 
        sDefaultLocaleList = new LocaleListHelper((Locale)localeListHelper, sLastExplicitlySetLocaleList);
        sDefaultAdjustedLocaleList = sDefaultLocaleList;
      } 
      return sDefaultLocaleList;
    } 
  }
  
  @NonNull
  @RestrictTo({RestrictTo.Scope.LIBRARY_GROUP})
  static LocaleListHelper getEmptyLocaleList() {
    return sEmptyLocaleList;
  }
  
  private static String getLikelyScript(Locale paramLocale) {
    if (Build.VERSION.SDK_INT >= 21) {
      String str = paramLocale.getScript();
      return !str.isEmpty() ? str : "";
    } 
    return "";
  }
  
  private static boolean isPseudoLocale(String paramString) {
    return ("en-XA".equals(paramString) || "ar-XB".equals(paramString));
  }
  
  private static boolean isPseudoLocale(Locale paramLocale) {
    return (LOCALE_EN_XA.equals(paramLocale) || LOCALE_AR_XB.equals(paramLocale));
  }
  
  @RestrictTo({RestrictTo.Scope.LIBRARY_GROUP})
  static boolean isPseudoLocalesOnly(@Nullable String[] paramArrayOfString) {
    if (paramArrayOfString == null)
      return true; 
    if (paramArrayOfString.length > 3)
      return false; 
    int j = paramArrayOfString.length;
    for (int i = 0; i < j; i++) {
      String str = paramArrayOfString[i];
      if (!str.isEmpty() && !isPseudoLocale(str))
        return false; 
    } 
    return true;
  }
  
  @IntRange(from = 0L, to = 1L)
  private static int matchScore(Locale paramLocale1, Locale paramLocale2) {
    throw new RuntimeException("d2j fail translate: java.lang.RuntimeException: can not merge I and Z\r\n\tat com.googlecode.dex2jar.ir.TypeClass.merge(TypeClass.java:100)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeRef.updateTypeClass(TypeTransformer.java:174)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.provideAs(TypeTransformer.java:780)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.enexpr(TypeTransformer.java:659)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.exExpr(TypeTransformer.java:719)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.exExpr(TypeTransformer.java:703)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.s1stmt(TypeTransformer.java:810)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.sxStmt(TypeTransformer.java:840)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.analyze(TypeTransformer.java:206)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer.transform(TypeTransformer.java:44)\r\n\tat com.googlecode.d2j.dex.Dex2jar$2.optimize(Dex2jar.java:162)\r\n\tat com.googlecode.d2j.dex.Dex2Asm.convertCode(Dex2Asm.java:414)\r\n\tat com.googlecode.d2j.dex.ExDex2Asm.convertCode(ExDex2Asm.java:42)\r\n\tat com.googlecode.d2j.dex.Dex2jar$2.convertCode(Dex2jar.java:128)\r\n\tat com.googlecode.d2j.dex.Dex2Asm.convertMethod(Dex2Asm.java:509)\r\n\tat com.googlecode.d2j.dex.Dex2Asm.convertClass(Dex2Asm.java:406)\r\n\tat com.googlecode.d2j.dex.Dex2Asm.convertDex(Dex2Asm.java:422)\r\n\tat com.googlecode.d2j.dex.Dex2jar.doTranslate(Dex2jar.java:172)\r\n\tat com.googlecode.d2j.dex.Dex2jar.to(Dex2jar.java:272)\r\n\tat com.googlecode.dex2jar.tools.Dex2jarCmd.doCommandLine(Dex2jarCmd.java:108)\r\n\tat com.googlecode.dex2jar.tools.BaseCmd.doMain(BaseCmd.java:288)\r\n\tat com.googlecode.dex2jar.tools.Dex2jarCmd.main(Dex2jarCmd.java:32)\r\n");
  }
  
  @RestrictTo({RestrictTo.Scope.LIBRARY_GROUP})
  static void setDefault(@NonNull @Size(min = 1L) LocaleListHelper paramLocaleListHelper) {
    setDefault(paramLocaleListHelper, 0);
  }
  
  @RestrictTo({RestrictTo.Scope.LIBRARY_GROUP})
  static void setDefault(@NonNull @Size(min = 1L) LocaleListHelper paramLocaleListHelper, int paramInt) {
    if (paramLocaleListHelper != null) {
      if (!paramLocaleListHelper.isEmpty())
        synchronized (sLock) {
          sLastDefaultLocale = paramLocaleListHelper.get(paramInt);
          Locale.setDefault(sLastDefaultLocale);
          sLastExplicitlySetLocaleList = paramLocaleListHelper;
          sDefaultLocaleList = paramLocaleListHelper;
          if (paramInt == 0) {
            sDefaultAdjustedLocaleList = sDefaultLocaleList;
          } else {
            sDefaultAdjustedLocaleList = new LocaleListHelper(sLastDefaultLocale, sDefaultLocaleList);
          } 
          return;
        }  
      throw new IllegalArgumentException("locales is empty");
    } 
    throw new NullPointerException("locales is null");
  }
  
  public boolean equals(Object paramObject) {
    if (paramObject == this)
      return true; 
    if (!(paramObject instanceof LocaleListHelper))
      return false; 
    paramObject = ((LocaleListHelper)paramObject).mList;
    if (this.mList.length != paramObject.length)
      return false; 
    for (int i = 0; i < this.mList.length; i++) {
      if (!this.mList[i].equals(paramObject[i]))
        return false; 
    } 
    return true;
  }
  
  @RestrictTo({RestrictTo.Scope.LIBRARY_GROUP})
  Locale get(int paramInt) {
    return (paramInt >= 0 && paramInt < this.mList.length) ? this.mList[paramInt] : null;
  }
  
  @Nullable
  @RestrictTo({RestrictTo.Scope.LIBRARY_GROUP})
  Locale getFirstMatch(String[] paramArrayOfString) {
    return computeFirstMatch(Arrays.asList(paramArrayOfString), false);
  }
  
  @RestrictTo({RestrictTo.Scope.LIBRARY_GROUP})
  int getFirstMatchIndex(String[] paramArrayOfString) {
    return computeFirstMatchIndex(Arrays.asList(paramArrayOfString), false);
  }
  
  @RestrictTo({RestrictTo.Scope.LIBRARY_GROUP})
  int getFirstMatchIndexWithEnglishSupported(Collection<String> paramCollection) {
    return computeFirstMatchIndex(paramCollection, true);
  }
  
  @RestrictTo({RestrictTo.Scope.LIBRARY_GROUP})
  int getFirstMatchIndexWithEnglishSupported(String[] paramArrayOfString) {
    return getFirstMatchIndexWithEnglishSupported(Arrays.asList(paramArrayOfString));
  }
  
  @Nullable
  @RestrictTo({RestrictTo.Scope.LIBRARY_GROUP})
  Locale getFirstMatchWithEnglishSupported(String[] paramArrayOfString) {
    return computeFirstMatch(Arrays.asList(paramArrayOfString), true);
  }
  
  public int hashCode() {
    int j = 1;
    for (int i = 0; i < this.mList.length; i++)
      j = j * 31 + this.mList[i].hashCode(); 
    return j;
  }
  
  @IntRange(from = -1L)
  @RestrictTo({RestrictTo.Scope.LIBRARY_GROUP})
  int indexOf(Locale paramLocale) {
    for (int i = 0; i < this.mList.length; i++) {
      if (this.mList[i].equals(paramLocale))
        return i; 
    } 
    return -1;
  }
  
  @RestrictTo({RestrictTo.Scope.LIBRARY_GROUP})
  boolean isEmpty() {
    return (this.mList.length == 0);
  }
  
  @IntRange(from = 0L)
  @RestrictTo({RestrictTo.Scope.LIBRARY_GROUP})
  int size() {
    return this.mList.length;
  }
  
  @NonNull
  @RestrictTo({RestrictTo.Scope.LIBRARY_GROUP})
  String toLanguageTags() {
    return this.mStringRepresentation;
  }
  
  public String toString() {
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("[");
    for (int i = 0; i < this.mList.length; i++) {
      stringBuilder.append(this.mList[i]);
      if (i < this.mList.length - 1)
        stringBuilder.append(','); 
    } 
    stringBuilder.append("]");
    return stringBuilder.toString();
  }
}


/* Location:              C:\soft\dex2jar-2.0\9 Ball Pool-dex2jar.jar!\android\support\v4\os\LocaleListHelper.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */
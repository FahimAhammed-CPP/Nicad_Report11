package android.support.multidex;

import android.content.Context;
import android.content.SharedPreferences;
import android.os.Build;
import android.util.Log;
import java.io.Closeable;
import java.io.File;
import java.io.FileFilter;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.zip.ZipEntry;
import java.util.zip.ZipFile;

final class MultiDexExtractor {
  private static final int BUFFER_SIZE = 16384;
  
  private static final String DEX_PREFIX = "classes";
  
  private static final String DEX_SUFFIX = ".dex";
  
  private static final String EXTRACTED_NAME_EXT = ".classes";
  
  private static final String EXTRACTED_SUFFIX = ".zip";
  
  private static final String KEY_CRC = "crc";
  
  private static final String KEY_DEX_CRC = "dex.crc.";
  
  private static final String KEY_DEX_NUMBER = "dex.number";
  
  private static final String KEY_DEX_TIME = "dex.time.";
  
  private static final String KEY_TIME_STAMP = "timestamp";
  
  private static final String LOCK_FILENAME = "MultiDex.lock";
  
  private static final int MAX_EXTRACT_ATTEMPTS = 3;
  
  private static final long NO_VALUE = -1L;
  
  private static final String PREFS_FILE = "multidex.version";
  
  private static final String TAG = "MultiDex";
  
  private static void closeQuietly(Closeable paramCloseable) {
    try {
      paramCloseable.close();
      return;
    } catch (IOException iOException) {
      Log.w("MultiDex", "Failed to close resource", iOException);
      return;
    } 
  }
  
  private static void extract(ZipFile paramZipFile, ZipEntry paramZipEntry, File paramFile, String paramString) throws IOException, FileNotFoundException {
    InputStream inputStream = paramZipFile.getInputStream(paramZipEntry);
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("tmp-");
    stringBuilder.append(paramString);
    File file = File.createTempFile(stringBuilder.toString(), ".zip", paramFile.getParentFile());
    stringBuilder = new StringBuilder();
    stringBuilder.append("Extracting ");
    stringBuilder.append(file.getPath());
    Log.i("MultiDex", stringBuilder.toString());
    try {
    
    } finally {
      closeQuietly(inputStream);
      file.delete();
    } 
  }
  
  private static SharedPreferences getMultiDexPreferences(Context paramContext) {
    byte b;
    if (Build.VERSION.SDK_INT < 11) {
      b = 0;
    } else {
      b = 4;
    } 
    return paramContext.getSharedPreferences("multidex.version", b);
  }
  
  private static long getTimeStamp(File paramFile) {
    long l2 = paramFile.lastModified();
    long l1 = l2;
    if (l2 == -1L)
      l1 = l2 - 1L; 
    return l1;
  }
  
  private static long getZipCrc(File paramFile) throws IOException {
    long l2 = ZipUtil.getZipCrc(paramFile);
    long l1 = l2;
    if (l2 == -1L)
      l1 = l2 - 1L; 
    return l1;
  }
  
  private static boolean isModified(Context paramContext, File paramFile, long paramLong, String paramString) {
    SharedPreferences sharedPreferences = getMultiDexPreferences(paramContext);
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append(paramString);
    stringBuilder.append("timestamp");
    if (sharedPreferences.getLong(stringBuilder.toString(), -1L) == getTimeStamp(paramFile)) {
      StringBuilder stringBuilder1 = new StringBuilder();
      stringBuilder1.append(paramString);
      stringBuilder1.append("crc");
      if (sharedPreferences.getLong(stringBuilder1.toString(), -1L) == paramLong)
        return false; 
    } 
    return true;
  }
  
  static List<? extends File> load(Context paramContext, File paramFile1, File paramFile2, String paramString, boolean paramBoolean) throws IOException {
    // Byte code:
    //   0: new java/lang/StringBuilder
    //   3: dup
    //   4: invokespecial <init> : ()V
    //   7: astore #7
    //   9: aload #7
    //   11: ldc 'MultiDexExtractor.load('
    //   13: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   16: pop
    //   17: aload #7
    //   19: aload_1
    //   20: invokevirtual getPath : ()Ljava/lang/String;
    //   23: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   26: pop
    //   27: aload #7
    //   29: ldc ', '
    //   31: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   34: pop
    //   35: aload #7
    //   37: iload #4
    //   39: invokevirtual append : (Z)Ljava/lang/StringBuilder;
    //   42: pop
    //   43: aload #7
    //   45: ldc ', '
    //   47: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   50: pop
    //   51: aload #7
    //   53: aload_3
    //   54: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   57: pop
    //   58: aload #7
    //   60: ldc ')'
    //   62: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   65: pop
    //   66: ldc 'MultiDex'
    //   68: aload #7
    //   70: invokevirtual toString : ()Ljava/lang/String;
    //   73: invokestatic i : (Ljava/lang/String;Ljava/lang/String;)I
    //   76: pop
    //   77: aload_1
    //   78: invokestatic getZipCrc : (Ljava/io/File;)J
    //   81: lstore #5
    //   83: new java/io/File
    //   86: dup
    //   87: aload_2
    //   88: ldc 'MultiDex.lock'
    //   90: invokespecial <init> : (Ljava/io/File;Ljava/lang/String;)V
    //   93: astore #11
    //   95: new java/io/RandomAccessFile
    //   98: dup
    //   99: aload #11
    //   101: ldc 'rw'
    //   103: invokespecial <init> : (Ljava/io/File;Ljava/lang/String;)V
    //   106: astore #10
    //   108: aload #10
    //   110: invokevirtual getChannel : ()Ljava/nio/channels/FileChannel;
    //   113: astore #7
    //   115: new java/lang/StringBuilder
    //   118: dup
    //   119: invokespecial <init> : ()V
    //   122: astore #8
    //   124: aload #8
    //   126: ldc_w 'Blocking on lock '
    //   129: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   132: pop
    //   133: aload #8
    //   135: aload #11
    //   137: invokevirtual getPath : ()Ljava/lang/String;
    //   140: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   143: pop
    //   144: ldc 'MultiDex'
    //   146: aload #8
    //   148: invokevirtual toString : ()Ljava/lang/String;
    //   151: invokestatic i : (Ljava/lang/String;Ljava/lang/String;)I
    //   154: pop
    //   155: aload #7
    //   157: invokevirtual lock : ()Ljava/nio/channels/FileLock;
    //   160: astore #8
    //   162: new java/lang/StringBuilder
    //   165: dup
    //   166: invokespecial <init> : ()V
    //   169: astore #9
    //   171: aload #9
    //   173: aload #11
    //   175: invokevirtual getPath : ()Ljava/lang/String;
    //   178: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   181: pop
    //   182: aload #9
    //   184: ldc_w ' locked'
    //   187: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   190: pop
    //   191: ldc 'MultiDex'
    //   193: aload #9
    //   195: invokevirtual toString : ()Ljava/lang/String;
    //   198: invokestatic i : (Ljava/lang/String;Ljava/lang/String;)I
    //   201: pop
    //   202: iload #4
    //   204: ifne -> 518
    //   207: aload_0
    //   208: aload_1
    //   209: lload #5
    //   211: aload_3
    //   212: invokestatic isModified : (Landroid/content/Context;Ljava/io/File;JLjava/lang/String;)Z
    //   215: istore #4
    //   217: iload #4
    //   219: ifne -> 273
    //   222: aload_0
    //   223: aload_1
    //   224: aload_2
    //   225: aload_3
    //   226: invokestatic loadExistingExtractions : (Landroid/content/Context;Ljava/io/File;Ljava/io/File;Ljava/lang/String;)Ljava/util/List;
    //   229: astore #9
    //   231: aload #9
    //   233: astore_0
    //   234: goto -> 305
    //   237: astore #9
    //   239: ldc 'MultiDex'
    //   241: ldc_w 'Failed to reload existing extracted secondary dex files, falling back to fresh extraction'
    //   244: aload #9
    //   246: invokestatic w : (Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I
    //   249: pop
    //   250: aload_1
    //   251: aload_2
    //   252: invokestatic performExtractions : (Ljava/io/File;Ljava/io/File;)Ljava/util/List;
    //   255: astore_2
    //   256: aload_0
    //   257: aload_3
    //   258: aload_1
    //   259: invokestatic getTimeStamp : (Ljava/io/File;)J
    //   262: lload #5
    //   264: aload_2
    //   265: invokestatic putStoredApkInfo : (Landroid/content/Context;Ljava/lang/String;JJLjava/util/List;)V
    //   268: aload_2
    //   269: astore_0
    //   270: goto -> 234
    //   273: ldc 'MultiDex'
    //   275: ldc_w 'Detected that extraction must be performed.'
    //   278: invokestatic i : (Ljava/lang/String;Ljava/lang/String;)I
    //   281: pop
    //   282: aload_1
    //   283: aload_2
    //   284: invokestatic performExtractions : (Ljava/io/File;Ljava/io/File;)Ljava/util/List;
    //   287: astore_2
    //   288: aload_0
    //   289: aload_3
    //   290: aload_1
    //   291: invokestatic getTimeStamp : (Ljava/io/File;)J
    //   294: lload #5
    //   296: aload_2
    //   297: invokestatic putStoredApkInfo : (Landroid/content/Context;Ljava/lang/String;JJLjava/util/List;)V
    //   300: aload_2
    //   301: astore_0
    //   302: goto -> 234
    //   305: aload #8
    //   307: ifnull -> 358
    //   310: aload #8
    //   312: invokevirtual release : ()V
    //   315: goto -> 358
    //   318: astore_1
    //   319: new java/lang/StringBuilder
    //   322: dup
    //   323: invokespecial <init> : ()V
    //   326: astore_2
    //   327: aload_2
    //   328: ldc_w 'Failed to release lock on '
    //   331: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   334: pop
    //   335: aload_2
    //   336: aload #11
    //   338: invokevirtual getPath : ()Ljava/lang/String;
    //   341: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   344: pop
    //   345: ldc 'MultiDex'
    //   347: aload_2
    //   348: invokevirtual toString : ()Ljava/lang/String;
    //   351: invokestatic e : (Ljava/lang/String;Ljava/lang/String;)I
    //   354: pop
    //   355: goto -> 360
    //   358: aconst_null
    //   359: astore_1
    //   360: aload #7
    //   362: ifnull -> 370
    //   365: aload #7
    //   367: invokestatic closeQuietly : (Ljava/io/Closeable;)V
    //   370: aload #10
    //   372: invokestatic closeQuietly : (Ljava/io/Closeable;)V
    //   375: aload_1
    //   376: ifnonnull -> 426
    //   379: new java/lang/StringBuilder
    //   382: dup
    //   383: invokespecial <init> : ()V
    //   386: astore_1
    //   387: aload_1
    //   388: ldc_w 'load found '
    //   391: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   394: pop
    //   395: aload_1
    //   396: aload_0
    //   397: invokeinterface size : ()I
    //   402: invokevirtual append : (I)Ljava/lang/StringBuilder;
    //   405: pop
    //   406: aload_1
    //   407: ldc_w ' secondary dex files'
    //   410: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   413: pop
    //   414: ldc 'MultiDex'
    //   416: aload_1
    //   417: invokevirtual toString : ()Ljava/lang/String;
    //   420: invokestatic i : (Ljava/lang/String;Ljava/lang/String;)I
    //   423: pop
    //   424: aload_0
    //   425: areturn
    //   426: aload_1
    //   427: athrow
    //   428: astore_0
    //   429: aload #7
    //   431: astore_2
    //   432: aload #8
    //   434: astore_1
    //   435: goto -> 452
    //   438: astore_0
    //   439: aconst_null
    //   440: astore_1
    //   441: aload #7
    //   443: astore_2
    //   444: goto -> 452
    //   447: astore_0
    //   448: aconst_null
    //   449: astore_2
    //   450: aload_2
    //   451: astore_1
    //   452: aload_1
    //   453: ifnull -> 499
    //   456: aload_1
    //   457: invokevirtual release : ()V
    //   460: goto -> 499
    //   463: new java/lang/StringBuilder
    //   466: dup
    //   467: invokespecial <init> : ()V
    //   470: astore_1
    //   471: aload_1
    //   472: ldc_w 'Failed to release lock on '
    //   475: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   478: pop
    //   479: aload_1
    //   480: aload #11
    //   482: invokevirtual getPath : ()Ljava/lang/String;
    //   485: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   488: pop
    //   489: ldc 'MultiDex'
    //   491: aload_1
    //   492: invokevirtual toString : ()Ljava/lang/String;
    //   495: invokestatic e : (Ljava/lang/String;Ljava/lang/String;)I
    //   498: pop
    //   499: aload_2
    //   500: ifnull -> 507
    //   503: aload_2
    //   504: invokestatic closeQuietly : (Ljava/io/Closeable;)V
    //   507: aload #10
    //   509: invokestatic closeQuietly : (Ljava/io/Closeable;)V
    //   512: aload_0
    //   513: athrow
    //   514: astore_1
    //   515: goto -> 463
    //   518: goto -> 273
    // Exception table:
    //   from	to	target	type
    //   108	115	447	finally
    //   115	162	438	finally
    //   162	202	428	finally
    //   207	217	428	finally
    //   222	231	237	java/io/IOException
    //   222	231	428	finally
    //   239	268	428	finally
    //   273	300	428	finally
    //   310	315	318	java/io/IOException
    //   456	460	514	java/io/IOException
  }
  
  private static List<ExtractedDex> loadExistingExtractions(Context paramContext, File paramFile1, File paramFile2, String paramString) throws IOException {
    Log.i("MultiDex", "loading existing secondary dex files");
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append(paramFile1.getName());
    stringBuilder.append(".classes");
    String str = stringBuilder.toString();
    SharedPreferences sharedPreferences = getMultiDexPreferences(paramContext);
    stringBuilder = new StringBuilder();
    stringBuilder.append(paramString);
    stringBuilder.append("dex.number");
    int j = sharedPreferences.getInt(stringBuilder.toString(), 1);
    ArrayList<ExtractedDex> arrayList = new ArrayList(j - 1);
    int i = 2;
    while (i <= j) {
      StringBuilder stringBuilder2 = new StringBuilder();
      stringBuilder2.append(str);
      stringBuilder2.append(i);
      stringBuilder2.append(".zip");
      ExtractedDex extractedDex = new ExtractedDex(paramFile2, stringBuilder2.toString());
      if (extractedDex.isFile()) {
        extractedDex.crc = getZipCrc(extractedDex);
        StringBuilder stringBuilder4 = new StringBuilder();
        stringBuilder4.append(paramString);
        stringBuilder4.append("dex.crc.");
        stringBuilder4.append(i);
        long l1 = sharedPreferences.getLong(stringBuilder4.toString(), -1L);
        stringBuilder4 = new StringBuilder();
        stringBuilder4.append(paramString);
        stringBuilder4.append("dex.time.");
        stringBuilder4.append(i);
        long l2 = sharedPreferences.getLong(stringBuilder4.toString(), -1L);
        long l3 = extractedDex.lastModified();
        if (l2 == l3 && l1 == extractedDex.crc) {
          arrayList.add(extractedDex);
          i++;
          continue;
        } 
        StringBuilder stringBuilder3 = new StringBuilder();
        stringBuilder3.append("Invalid extracted dex: ");
        stringBuilder3.append(extractedDex);
        stringBuilder3.append(" (key \"");
        stringBuilder3.append(paramString);
        stringBuilder3.append("\"), expected modification time: ");
        stringBuilder3.append(l2);
        stringBuilder3.append(", modification time: ");
        stringBuilder3.append(l3);
        stringBuilder3.append(", expected crc: ");
        stringBuilder3.append(l1);
        stringBuilder3.append(", file crc: ");
        stringBuilder3.append(extractedDex.crc);
        throw new IOException(stringBuilder3.toString());
      } 
      StringBuilder stringBuilder1 = new StringBuilder();
      stringBuilder1.append("Missing extracted secondary dex file '");
      stringBuilder1.append(extractedDex.getPath());
      stringBuilder1.append("'");
      throw new IOException(stringBuilder1.toString());
    } 
    return arrayList;
  }
  
  private static List<ExtractedDex> performExtractions(File paramFile1, File paramFile2) throws IOException {
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append(paramFile1.getName());
    stringBuilder.append(".classes");
    String str = stringBuilder.toString();
    prepareDexDir(paramFile2, str);
    ArrayList<ExtractedDex> arrayList = new ArrayList();
    ZipFile zipFile = new ZipFile(paramFile1);
    int i = 2;
    try {
      StringBuilder stringBuilder1 = new StringBuilder();
      stringBuilder1.append("classes");
      stringBuilder1.append(2);
      stringBuilder1.append(".dex");
      ZipEntry zipEntry = zipFile.getEntry(stringBuilder1.toString());
      label43: while (true) {
        if (zipEntry != null) {
          stringBuilder = new StringBuilder();
          stringBuilder.append(str);
          stringBuilder.append(i);
          stringBuilder.append(".zip");
          ExtractedDex extractedDex = new ExtractedDex(paramFile2, stringBuilder.toString());
          arrayList.add(extractedDex);
          stringBuilder = new StringBuilder();
          stringBuilder.append("Extraction is needed for file ");
          stringBuilder.append(extractedDex);
          Log.i("MultiDex", stringBuilder.toString());
          int j = 0;
          boolean bool = false;
          while (true) {
            if (j < 3 && !bool) {
              boolean bool1;
              String str1;
              int k = j + 1;
              extract(zipFile, zipEntry, extractedDex, str);
              try {
                extractedDex.crc = getZipCrc(extractedDex);
                bool1 = true;
              } catch (IOException iOException) {
                StringBuilder stringBuilder4 = new StringBuilder();
                stringBuilder4.append("Failed to read crc from ");
                stringBuilder4.append(extractedDex.getAbsolutePath());
                Log.w("MultiDex", stringBuilder4.toString(), iOException);
                bool1 = false;
              } 
              StringBuilder stringBuilder3 = new StringBuilder();
              stringBuilder3.append("Extraction ");
              if (bool1) {
                str1 = "succeeded";
              } else {
                str1 = "failed";
              } 
              stringBuilder3.append(str1);
              stringBuilder3.append(" - length ");
              stringBuilder3.append(extractedDex.getAbsolutePath());
              stringBuilder3.append(": ");
              stringBuilder3.append(extractedDex.length());
              stringBuilder3.append(" - crc: ");
              stringBuilder3.append(extractedDex.crc);
              Log.i("MultiDex", stringBuilder3.toString());
              j = k;
              bool = bool1;
              if (!bool1) {
                extractedDex.delete();
                j = k;
                bool = bool1;
                if (extractedDex.exists()) {
                  StringBuilder stringBuilder4 = new StringBuilder();
                  stringBuilder4.append("Failed to delete corrupted secondary dex '");
                  stringBuilder4.append(extractedDex.getPath());
                  stringBuilder4.append("'");
                  Log.w("MultiDex", stringBuilder4.toString());
                  j = k;
                  bool = bool1;
                } 
              } 
              continue;
            } 
            if (bool) {
              i++;
              StringBuilder stringBuilder3 = new StringBuilder();
              stringBuilder3.append("classes");
              stringBuilder3.append(i);
              stringBuilder3.append(".dex");
              ZipEntry zipEntry1 = zipFile.getEntry(stringBuilder3.toString());
              continue label43;
            } 
            StringBuilder stringBuilder2 = new StringBuilder();
            stringBuilder2.append("Could not create zip file ");
            stringBuilder2.append(extractedDex.getAbsolutePath());
            stringBuilder2.append(" for secondary dex (");
            stringBuilder2.append(i);
            stringBuilder2.append(")");
            throw new IOException(stringBuilder2.toString());
          } 
          break;
        } 
        try {
          return arrayList;
        } catch (IOException iOException) {
          return arrayList;
        } 
      } 
    } finally {
      try {
        zipFile.close();
      } catch (IOException iOException) {
        Log.w("MultiDex", "Failed to close resource", iOException);
      } 
    } 
  }
  
  private static void prepareDexDir(File paramFile, final String extractedFilePrefix) {
    StringBuilder stringBuilder;
    File[] arrayOfFile = paramFile.listFiles(new FileFilter() {
          public boolean accept(File param1File) {
            String str = param1File.getName();
            return (!str.startsWith(extractedFilePrefix) && !str.equals("MultiDex.lock"));
          }
        });
    if (arrayOfFile == null) {
      stringBuilder = new StringBuilder();
      stringBuilder.append("Failed to list secondary dex dir content (");
      stringBuilder.append(paramFile.getPath());
      stringBuilder.append(").");
      Log.w("MultiDex", stringBuilder.toString());
      return;
    } 
    int j = stringBuilder.length;
    for (int i = 0; i < j; i++) {
      StringBuilder stringBuilder1 = stringBuilder[i];
      StringBuilder stringBuilder2 = new StringBuilder();
      stringBuilder2.append("Trying to delete old file ");
      stringBuilder2.append(stringBuilder1.getPath());
      stringBuilder2.append(" of size ");
      stringBuilder2.append(stringBuilder1.length());
      Log.i("MultiDex", stringBuilder2.toString());
      if (!stringBuilder1.delete()) {
        stringBuilder2 = new StringBuilder();
        stringBuilder2.append("Failed to delete old file ");
        stringBuilder2.append(stringBuilder1.getPath());
        Log.w("MultiDex", stringBuilder2.toString());
      } else {
        stringBuilder2 = new StringBuilder();
        stringBuilder2.append("Deleted old file ");
        stringBuilder2.append(stringBuilder1.getPath());
        Log.i("MultiDex", stringBuilder2.toString());
      } 
    } 
  }
  
  private static void putStoredApkInfo(Context paramContext, String paramString, long paramLong1, long paramLong2, List<ExtractedDex> paramList) {
    SharedPreferences.Editor editor = getMultiDexPreferences(paramContext).edit();
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append(paramString);
    stringBuilder.append("timestamp");
    editor.putLong(stringBuilder.toString(), paramLong1);
    stringBuilder = new StringBuilder();
    stringBuilder.append(paramString);
    stringBuilder.append("crc");
    editor.putLong(stringBuilder.toString(), paramLong2);
    stringBuilder = new StringBuilder();
    stringBuilder.append(paramString);
    stringBuilder.append("dex.number");
    editor.putInt(stringBuilder.toString(), paramList.size() + 1);
    Iterator<ExtractedDex> iterator = paramList.iterator();
    int i;
    for (i = 2; iterator.hasNext(); i++) {
      ExtractedDex extractedDex = iterator.next();
      StringBuilder stringBuilder1 = new StringBuilder();
      stringBuilder1.append(paramString);
      stringBuilder1.append("dex.crc.");
      stringBuilder1.append(i);
      editor.putLong(stringBuilder1.toString(), extractedDex.crc);
      stringBuilder1 = new StringBuilder();
      stringBuilder1.append(paramString);
      stringBuilder1.append("dex.time.");
      stringBuilder1.append(i);
      editor.putLong(stringBuilder1.toString(), extractedDex.lastModified());
    } 
    editor.commit();
  }
  
  private static class ExtractedDex extends File {
    public long crc = -1L;
    
    public ExtractedDex(File param1File, String param1String) {
      super(param1File, param1String);
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\9 Ball Pool-dex2jar.jar!\android\support\multidex\MultiDexExtractor.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */
package android.support.v4.view;

import android.view.VelocityTracker;

@Deprecated
public final class VelocityTrackerCompat {
  @Deprecated
  public static float getXVelocity(VelocityTracker paramVelocityTracker, int paramInt) {
    return paramVelocityTracker.getXVelocity(paramInt);
  }
  
  @Deprecated
  public static float getYVelocity(VelocityTracker paramVelocityTracker, int paramInt) {
    return paramVelocityTracker.getYVelocity(paramInt);
  }
}


/* Location:              C:\soft\dex2jar-2.0\9 Ball Pool-dex2jar.jar!\android\support\v4\view\VelocityTrackerCompat.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */
package android.support.media;

import android.content.res.AssetManager;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.location.Location;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.annotation.RestrictTo;
import android.util.Log;
import android.util.Pair;
import java.io.BufferedInputStream;
import java.io.ByteArrayInputStream;
import java.io.Closeable;
import java.io.DataInput;
import java.io.DataInputStream;
import java.io.EOFException;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.FilterOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.nio.charset.Charset;
import java.text.ParsePosition;
import java.text.SimpleDateFormat;
import java.util.Arrays;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.TimeZone;
import java.util.concurrent.TimeUnit;
import java.util.regex.Pattern;

public class ExifInterface {
  public static final short ALTITUDE_ABOVE_SEA_LEVEL = 0;
  
  public static final short ALTITUDE_BELOW_SEA_LEVEL = 1;
  
  private static final Charset ASCII;
  
  public static final int[] BITS_PER_SAMPLE_GREYSCALE_1;
  
  public static final int[] BITS_PER_SAMPLE_GREYSCALE_2;
  
  public static final int[] BITS_PER_SAMPLE_RGB;
  
  static final short BYTE_ALIGN_II = 18761;
  
  static final short BYTE_ALIGN_MM = 19789;
  
  public static final int COLOR_SPACE_S_RGB = 1;
  
  public static final int COLOR_SPACE_UNCALIBRATED = 65535;
  
  public static final short CONTRAST_HARD = 2;
  
  public static final short CONTRAST_NORMAL = 0;
  
  public static final short CONTRAST_SOFT = 1;
  
  public static final int DATA_DEFLATE_ZIP = 8;
  
  public static final int DATA_HUFFMAN_COMPRESSED = 2;
  
  public static final int DATA_JPEG = 6;
  
  public static final int DATA_JPEG_COMPRESSED = 7;
  
  public static final int DATA_LOSSY_JPEG = 34892;
  
  public static final int DATA_PACK_BITS_COMPRESSED = 32773;
  
  public static final int DATA_UNCOMPRESSED = 1;
  
  private static final boolean DEBUG = false;
  
  private static final byte[] EXIF_ASCII_PREFIX;
  
  private static final ExifTag[] EXIF_POINTER_TAGS;
  
  static final ExifTag[][] EXIF_TAGS;
  
  public static final short EXPOSURE_MODE_AUTO = 0;
  
  public static final short EXPOSURE_MODE_AUTO_BRACKET = 2;
  
  public static final short EXPOSURE_MODE_MANUAL = 1;
  
  public static final short EXPOSURE_PROGRAM_ACTION = 6;
  
  public static final short EXPOSURE_PROGRAM_APERTURE_PRIORITY = 3;
  
  public static final short EXPOSURE_PROGRAM_CREATIVE = 5;
  
  public static final short EXPOSURE_PROGRAM_LANDSCAPE_MODE = 8;
  
  public static final short EXPOSURE_PROGRAM_MANUAL = 1;
  
  public static final short EXPOSURE_PROGRAM_NORMAL = 2;
  
  public static final short EXPOSURE_PROGRAM_NOT_DEFINED = 0;
  
  public static final short EXPOSURE_PROGRAM_PORTRAIT_MODE = 7;
  
  public static final short EXPOSURE_PROGRAM_SHUTTER_PRIORITY = 4;
  
  public static final short FILE_SOURCE_DSC = 3;
  
  public static final short FILE_SOURCE_OTHER = 0;
  
  public static final short FILE_SOURCE_REFLEX_SCANNER = 2;
  
  public static final short FILE_SOURCE_TRANSPARENT_SCANNER = 1;
  
  public static final short FLAG_FLASH_FIRED = 1;
  
  public static final short FLAG_FLASH_MODE_AUTO = 24;
  
  public static final short FLAG_FLASH_MODE_COMPULSORY_FIRING = 8;
  
  public static final short FLAG_FLASH_MODE_COMPULSORY_SUPPRESSION = 16;
  
  public static final short FLAG_FLASH_NO_FLASH_FUNCTION = 32;
  
  public static final short FLAG_FLASH_RED_EYE_SUPPORTED = 64;
  
  public static final short FLAG_FLASH_RETURN_LIGHT_DETECTED = 6;
  
  public static final short FLAG_FLASH_RETURN_LIGHT_NOT_DETECTED = 4;
  
  private static final List<Integer> FLIPPED_ROTATION_ORDER;
  
  public static final short FORMAT_CHUNKY = 1;
  
  public static final short FORMAT_PLANAR = 2;
  
  public static final short GAIN_CONTROL_HIGH_GAIN_DOWN = 4;
  
  public static final short GAIN_CONTROL_HIGH_GAIN_UP = 2;
  
  public static final short GAIN_CONTROL_LOW_GAIN_DOWN = 3;
  
  public static final short GAIN_CONTROL_LOW_GAIN_UP = 1;
  
  public static final short GAIN_CONTROL_NONE = 0;
  
  public static final String GPS_DIRECTION_MAGNETIC = "M";
  
  public static final String GPS_DIRECTION_TRUE = "T";
  
  public static final String GPS_DISTANCE_KILOMETERS = "K";
  
  public static final String GPS_DISTANCE_MILES = "M";
  
  public static final String GPS_DISTANCE_NAUTICAL_MILES = "N";
  
  public static final String GPS_MEASUREMENT_2D = "2";
  
  public static final String GPS_MEASUREMENT_3D = "3";
  
  public static final short GPS_MEASUREMENT_DIFFERENTIAL_CORRECTED = 1;
  
  public static final String GPS_MEASUREMENT_INTERRUPTED = "V";
  
  public static final String GPS_MEASUREMENT_IN_PROGRESS = "A";
  
  public static final short GPS_MEASUREMENT_NO_DIFFERENTIAL = 0;
  
  public static final String GPS_SPEED_KILOMETERS_PER_HOUR = "K";
  
  public static final String GPS_SPEED_KNOTS = "N";
  
  public static final String GPS_SPEED_MILES_PER_HOUR = "M";
  
  static final byte[] IDENTIFIER_EXIF_APP1;
  
  private static final ExifTag[] IFD_EXIF_TAGS;
  
  private static final int IFD_FORMAT_BYTE = 1;
  
  static final int[] IFD_FORMAT_BYTES_PER_FORMAT;
  
  private static final int IFD_FORMAT_DOUBLE = 12;
  
  private static final int IFD_FORMAT_IFD = 13;
  
  static final String[] IFD_FORMAT_NAMES;
  
  private static final int IFD_FORMAT_SBYTE = 6;
  
  private static final int IFD_FORMAT_SINGLE = 11;
  
  private static final int IFD_FORMAT_SLONG = 9;
  
  private static final int IFD_FORMAT_SRATIONAL = 10;
  
  private static final int IFD_FORMAT_SSHORT = 8;
  
  private static final int IFD_FORMAT_STRING = 2;
  
  private static final int IFD_FORMAT_ULONG = 4;
  
  private static final int IFD_FORMAT_UNDEFINED = 7;
  
  private static final int IFD_FORMAT_URATIONAL = 5;
  
  private static final int IFD_FORMAT_USHORT = 3;
  
  private static final ExifTag[] IFD_GPS_TAGS;
  
  private static final ExifTag[] IFD_INTEROPERABILITY_TAGS;
  
  private static final int IFD_OFFSET = 8;
  
  private static final ExifTag[] IFD_THUMBNAIL_TAGS;
  
  private static final ExifTag[] IFD_TIFF_TAGS;
  
  private static final int IFD_TYPE_EXIF = 1;
  
  private static final int IFD_TYPE_GPS = 2;
  
  private static final int IFD_TYPE_INTEROPERABILITY = 3;
  
  private static final int IFD_TYPE_ORF_CAMERA_SETTINGS = 7;
  
  private static final int IFD_TYPE_ORF_IMAGE_PROCESSING = 8;
  
  private static final int IFD_TYPE_ORF_MAKER_NOTE = 6;
  
  private static final int IFD_TYPE_PEF = 9;
  
  static final int IFD_TYPE_PREVIEW = 5;
  
  static final int IFD_TYPE_PRIMARY = 0;
  
  static final int IFD_TYPE_THUMBNAIL = 4;
  
  private static final int IMAGE_TYPE_ARW = 1;
  
  private static final int IMAGE_TYPE_CR2 = 2;
  
  private static final int IMAGE_TYPE_DNG = 3;
  
  private static final int IMAGE_TYPE_JPEG = 4;
  
  private static final int IMAGE_TYPE_NEF = 5;
  
  private static final int IMAGE_TYPE_NRW = 6;
  
  private static final int IMAGE_TYPE_ORF = 7;
  
  private static final int IMAGE_TYPE_PEF = 8;
  
  private static final int IMAGE_TYPE_RAF = 9;
  
  private static final int IMAGE_TYPE_RW2 = 10;
  
  private static final int IMAGE_TYPE_SRW = 11;
  
  private static final int IMAGE_TYPE_UNKNOWN = 0;
  
  private static final ExifTag JPEG_INTERCHANGE_FORMAT_LENGTH_TAG;
  
  private static final ExifTag JPEG_INTERCHANGE_FORMAT_TAG;
  
  static final byte[] JPEG_SIGNATURE;
  
  public static final String LATITUDE_NORTH = "N";
  
  public static final String LATITUDE_SOUTH = "S";
  
  public static final short LIGHT_SOURCE_CLOUDY_WEATHER = 10;
  
  public static final short LIGHT_SOURCE_COOL_WHITE_FLUORESCENT = 14;
  
  public static final short LIGHT_SOURCE_D50 = 23;
  
  public static final short LIGHT_SOURCE_D55 = 20;
  
  public static final short LIGHT_SOURCE_D65 = 21;
  
  public static final short LIGHT_SOURCE_D75 = 22;
  
  public static final short LIGHT_SOURCE_DAYLIGHT = 1;
  
  public static final short LIGHT_SOURCE_DAYLIGHT_FLUORESCENT = 12;
  
  public static final short LIGHT_SOURCE_DAY_WHITE_FLUORESCENT = 13;
  
  public static final short LIGHT_SOURCE_FINE_WEATHER = 9;
  
  public static final short LIGHT_SOURCE_FLASH = 4;
  
  public static final short LIGHT_SOURCE_FLUORESCENT = 2;
  
  public static final short LIGHT_SOURCE_ISO_STUDIO_TUNGSTEN = 24;
  
  public static final short LIGHT_SOURCE_OTHER = 255;
  
  public static final short LIGHT_SOURCE_SHADE = 11;
  
  public static final short LIGHT_SOURCE_STANDARD_LIGHT_A = 17;
  
  public static final short LIGHT_SOURCE_STANDARD_LIGHT_B = 18;
  
  public static final short LIGHT_SOURCE_STANDARD_LIGHT_C = 19;
  
  public static final short LIGHT_SOURCE_TUNGSTEN = 3;
  
  public static final short LIGHT_SOURCE_UNKNOWN = 0;
  
  public static final short LIGHT_SOURCE_WARM_WHITE_FLUORESCENT = 16;
  
  public static final short LIGHT_SOURCE_WHITE_FLUORESCENT = 15;
  
  public static final String LONGITUDE_EAST = "E";
  
  public static final String LONGITUDE_WEST = "W";
  
  static final byte MARKER = -1;
  
  static final byte MARKER_APP1 = -31;
  
  private static final byte MARKER_COM = -2;
  
  static final byte MARKER_EOI = -39;
  
  private static final byte MARKER_SOF0 = -64;
  
  private static final byte MARKER_SOF1 = -63;
  
  private static final byte MARKER_SOF10 = -54;
  
  private static final byte MARKER_SOF11 = -53;
  
  private static final byte MARKER_SOF13 = -51;
  
  private static final byte MARKER_SOF14 = -50;
  
  private static final byte MARKER_SOF15 = -49;
  
  private static final byte MARKER_SOF2 = -62;
  
  private static final byte MARKER_SOF3 = -61;
  
  private static final byte MARKER_SOF5 = -59;
  
  private static final byte MARKER_SOF6 = -58;
  
  private static final byte MARKER_SOF7 = -57;
  
  private static final byte MARKER_SOF9 = -55;
  
  private static final byte MARKER_SOI = -40;
  
  private static final byte MARKER_SOS = -38;
  
  private static final int MAX_THUMBNAIL_SIZE = 512;
  
  public static final short METERING_MODE_AVERAGE = 1;
  
  public static final short METERING_MODE_CENTER_WEIGHT_AVERAGE = 2;
  
  public static final short METERING_MODE_MULTI_SPOT = 4;
  
  public static final short METERING_MODE_OTHER = 255;
  
  public static final short METERING_MODE_PARTIAL = 6;
  
  public static final short METERING_MODE_PATTERN = 5;
  
  public static final short METERING_MODE_SPOT = 3;
  
  public static final short METERING_MODE_UNKNOWN = 0;
  
  private static final ExifTag[] ORF_CAMERA_SETTINGS_TAGS;
  
  private static final ExifTag[] ORF_IMAGE_PROCESSING_TAGS;
  
  private static final byte[] ORF_MAKER_NOTE_HEADER_1;
  
  private static final int ORF_MAKER_NOTE_HEADER_1_SIZE = 8;
  
  private static final byte[] ORF_MAKER_NOTE_HEADER_2;
  
  private static final int ORF_MAKER_NOTE_HEADER_2_SIZE = 12;
  
  private static final ExifTag[] ORF_MAKER_NOTE_TAGS;
  
  private static final short ORF_SIGNATURE_1 = 20306;
  
  private static final short ORF_SIGNATURE_2 = 21330;
  
  public static final int ORIENTATION_FLIP_HORIZONTAL = 2;
  
  public static final int ORIENTATION_FLIP_VERTICAL = 4;
  
  public static final int ORIENTATION_NORMAL = 1;
  
  public static final int ORIENTATION_ROTATE_180 = 3;
  
  public static final int ORIENTATION_ROTATE_270 = 8;
  
  public static final int ORIENTATION_ROTATE_90 = 6;
  
  public static final int ORIENTATION_TRANSPOSE = 5;
  
  public static final int ORIENTATION_TRANSVERSE = 7;
  
  public static final int ORIENTATION_UNDEFINED = 0;
  
  public static final int ORIGINAL_RESOLUTION_IMAGE = 0;
  
  private static final int PEF_MAKER_NOTE_SKIP_SIZE = 6;
  
  private static final String PEF_SIGNATURE = "PENTAX";
  
  private static final ExifTag[] PEF_TAGS;
  
  public static final int PHOTOMETRIC_INTERPRETATION_BLACK_IS_ZERO = 1;
  
  public static final int PHOTOMETRIC_INTERPRETATION_RGB = 2;
  
  public static final int PHOTOMETRIC_INTERPRETATION_WHITE_IS_ZERO = 0;
  
  public static final int PHOTOMETRIC_INTERPRETATION_YCBCR = 6;
  
  private static final int RAF_INFO_SIZE = 160;
  
  private static final int RAF_JPEG_LENGTH_VALUE_SIZE = 4;
  
  private static final int RAF_OFFSET_TO_JPEG_IMAGE_OFFSET = 84;
  
  private static final String RAF_SIGNATURE = "FUJIFILMCCD-RAW";
  
  public static final int REDUCED_RESOLUTION_IMAGE = 1;
  
  public static final short RENDERED_PROCESS_CUSTOM = 1;
  
  public static final short RENDERED_PROCESS_NORMAL = 0;
  
  public static final short RESOLUTION_UNIT_CENTIMETERS = 3;
  
  public static final short RESOLUTION_UNIT_INCHES = 2;
  
  private static final List<Integer> ROTATION_ORDER = Arrays.asList(new Integer[] { Integer.valueOf(1), Integer.valueOf(6), Integer.valueOf(3), Integer.valueOf(8) });
  
  private static final short RW2_SIGNATURE = 85;
  
  public static final short SATURATION_HIGH = 0;
  
  public static final short SATURATION_LOW = 0;
  
  public static final short SATURATION_NORMAL = 0;
  
  public static final short SCENE_CAPTURE_TYPE_LANDSCAPE = 1;
  
  public static final short SCENE_CAPTURE_TYPE_NIGHT = 3;
  
  public static final short SCENE_CAPTURE_TYPE_PORTRAIT = 2;
  
  public static final short SCENE_CAPTURE_TYPE_STANDARD = 0;
  
  public static final short SCENE_TYPE_DIRECTLY_PHOTOGRAPHED = 1;
  
  public static final short SENSITIVITY_TYPE_ISO_SPEED = 3;
  
  public static final short SENSITIVITY_TYPE_REI = 2;
  
  public static final short SENSITIVITY_TYPE_REI_AND_ISO = 6;
  
  public static final short SENSITIVITY_TYPE_SOS = 1;
  
  public static final short SENSITIVITY_TYPE_SOS_AND_ISO = 5;
  
  public static final short SENSITIVITY_TYPE_SOS_AND_REI = 4;
  
  public static final short SENSITIVITY_TYPE_SOS_AND_REI_AND_ISO = 7;
  
  public static final short SENSITIVITY_TYPE_UNKNOWN = 0;
  
  public static final short SENSOR_TYPE_COLOR_SEQUENTIAL = 5;
  
  public static final short SENSOR_TYPE_COLOR_SEQUENTIAL_LINEAR = 8;
  
  public static final short SENSOR_TYPE_NOT_DEFINED = 1;
  
  public static final short SENSOR_TYPE_ONE_CHIP = 2;
  
  public static final short SENSOR_TYPE_THREE_CHIP = 4;
  
  public static final short SENSOR_TYPE_TRILINEAR = 7;
  
  public static final short SENSOR_TYPE_TWO_CHIP = 3;
  
  public static final short SHARPNESS_HARD = 2;
  
  public static final short SHARPNESS_NORMAL = 0;
  
  public static final short SHARPNESS_SOFT = 1;
  
  private static final int SIGNATURE_CHECK_SIZE = 5000;
  
  static final byte START_CODE = 42;
  
  public static final short SUBJECT_DISTANCE_RANGE_CLOSE_VIEW = 2;
  
  public static final short SUBJECT_DISTANCE_RANGE_DISTANT_VIEW = 3;
  
  public static final short SUBJECT_DISTANCE_RANGE_MACRO = 1;
  
  public static final short SUBJECT_DISTANCE_RANGE_UNKNOWN = 0;
  
  private static final String TAG = "ExifInterface";
  
  public static final String TAG_APERTURE_VALUE = "ApertureValue";
  
  public static final String TAG_ARTIST = "Artist";
  
  public static final String TAG_BITS_PER_SAMPLE = "BitsPerSample";
  
  public static final String TAG_BODY_SERIAL_NUMBER = "BodySerialNumber";
  
  public static final String TAG_BRIGHTNESS_VALUE = "BrightnessValue";
  
  public static final String TAG_CAMARA_OWNER_NAME = "CameraOwnerName";
  
  public static final String TAG_CFA_PATTERN = "CFAPattern";
  
  public static final String TAG_COLOR_SPACE = "ColorSpace";
  
  public static final String TAG_COMPONENTS_CONFIGURATION = "ComponentsConfiguration";
  
  public static final String TAG_COMPRESSED_BITS_PER_PIXEL = "CompressedBitsPerPixel";
  
  public static final String TAG_COMPRESSION = "Compression";
  
  public static final String TAG_CONTRAST = "Contrast";
  
  public static final String TAG_COPYRIGHT = "Copyright";
  
  public static final String TAG_CUSTOM_RENDERED = "CustomRendered";
  
  public static final String TAG_DATETIME = "DateTime";
  
  public static final String TAG_DATETIME_DIGITIZED = "DateTimeDigitized";
  
  public static final String TAG_DATETIME_ORIGINAL = "DateTimeOriginal";
  
  public static final String TAG_DEFAULT_CROP_SIZE = "DefaultCropSize";
  
  public static final String TAG_DEVICE_SETTING_DESCRIPTION = "DeviceSettingDescription";
  
  public static final String TAG_DIGITAL_ZOOM_RATIO = "DigitalZoomRatio";
  
  public static final String TAG_DNG_VERSION = "DNGVersion";
  
  private static final String TAG_EXIF_IFD_POINTER = "ExifIFDPointer";
  
  public static final String TAG_EXIF_VERSION = "ExifVersion";
  
  public static final String TAG_EXPOSURE_BIAS_VALUE = "ExposureBiasValue";
  
  public static final String TAG_EXPOSURE_INDEX = "ExposureIndex";
  
  public static final String TAG_EXPOSURE_MODE = "ExposureMode";
  
  public static final String TAG_EXPOSURE_PROGRAM = "ExposureProgram";
  
  public static final String TAG_EXPOSURE_TIME = "ExposureTime";
  
  public static final String TAG_FILE_SOURCE = "FileSource";
  
  public static final String TAG_FLASH = "Flash";
  
  public static final String TAG_FLASHPIX_VERSION = "FlashpixVersion";
  
  public static final String TAG_FLASH_ENERGY = "FlashEnergy";
  
  public static final String TAG_FOCAL_LENGTH = "FocalLength";
  
  public static final String TAG_FOCAL_LENGTH_IN_35MM_FILM = "FocalLengthIn35mmFilm";
  
  public static final String TAG_FOCAL_PLANE_RESOLUTION_UNIT = "FocalPlaneResolutionUnit";
  
  public static final String TAG_FOCAL_PLANE_X_RESOLUTION = "FocalPlaneXResolution";
  
  public static final String TAG_FOCAL_PLANE_Y_RESOLUTION = "FocalPlaneYResolution";
  
  public static final String TAG_F_NUMBER = "FNumber";
  
  public static final String TAG_GAIN_CONTROL = "GainControl";
  
  public static final String TAG_GAMMA = "Gamma";
  
  public static final String TAG_GPS_ALTITUDE = "GPSAltitude";
  
  public static final String TAG_GPS_ALTITUDE_REF = "GPSAltitudeRef";
  
  public static final String TAG_GPS_AREA_INFORMATION = "GPSAreaInformation";
  
  public static final String TAG_GPS_DATESTAMP = "GPSDateStamp";
  
  public static final String TAG_GPS_DEST_BEARING = "GPSDestBearing";
  
  public static final String TAG_GPS_DEST_BEARING_REF = "GPSDestBearingRef";
  
  public static final String TAG_GPS_DEST_DISTANCE = "GPSDestDistance";
  
  public static final String TAG_GPS_DEST_DISTANCE_REF = "GPSDestDistanceRef";
  
  public static final String TAG_GPS_DEST_LATITUDE = "GPSDestLatitude";
  
  public static final String TAG_GPS_DEST_LATITUDE_REF = "GPSDestLatitudeRef";
  
  public static final String TAG_GPS_DEST_LONGITUDE = "GPSDestLongitude";
  
  public static final String TAG_GPS_DEST_LONGITUDE_REF = "GPSDestLongitudeRef";
  
  public static final String TAG_GPS_DIFFERENTIAL = "GPSDifferential";
  
  public static final String TAG_GPS_DOP = "GPSDOP";
  
  public static final String TAG_GPS_H_POSITIONING_ERROR = "GPSHPositioningError";
  
  public static final String TAG_GPS_IMG_DIRECTION = "GPSImgDirection";
  
  public static final String TAG_GPS_IMG_DIRECTION_REF = "GPSImgDirectionRef";
  
  private static final String TAG_GPS_INFO_IFD_POINTER = "GPSInfoIFDPointer";
  
  public static final String TAG_GPS_LATITUDE = "GPSLatitude";
  
  public static final String TAG_GPS_LATITUDE_REF = "GPSLatitudeRef";
  
  public static final String TAG_GPS_LONGITUDE = "GPSLongitude";
  
  public static final String TAG_GPS_LONGITUDE_REF = "GPSLongitudeRef";
  
  public static final String TAG_GPS_MAP_DATUM = "GPSMapDatum";
  
  public static final String TAG_GPS_MEASURE_MODE = "GPSMeasureMode";
  
  public static final String TAG_GPS_PROCESSING_METHOD = "GPSProcessingMethod";
  
  public static final String TAG_GPS_SATELLITES = "GPSSatellites";
  
  public static final String TAG_GPS_SPEED = "GPSSpeed";
  
  public static final String TAG_GPS_SPEED_REF = "GPSSpeedRef";
  
  public static final String TAG_GPS_STATUS = "GPSStatus";
  
  public static final String TAG_GPS_TIMESTAMP = "GPSTimeStamp";
  
  public static final String TAG_GPS_TRACK = "GPSTrack";
  
  public static final String TAG_GPS_TRACK_REF = "GPSTrackRef";
  
  public static final String TAG_GPS_VERSION_ID = "GPSVersionID";
  
  private static final String TAG_HAS_THUMBNAIL = "HasThumbnail";
  
  public static final String TAG_IMAGE_DESCRIPTION = "ImageDescription";
  
  public static final String TAG_IMAGE_LENGTH = "ImageLength";
  
  public static final String TAG_IMAGE_UNIQUE_ID = "ImageUniqueID";
  
  public static final String TAG_IMAGE_WIDTH = "ImageWidth";
  
  private static final String TAG_INTEROPERABILITY_IFD_POINTER = "InteroperabilityIFDPointer";
  
  public static final String TAG_INTEROPERABILITY_INDEX = "InteroperabilityIndex";
  
  public static final String TAG_ISO_SPEED = "ISOSpeed";
  
  public static final String TAG_ISO_SPEED_LATITUDE_YYY = "ISOSpeedLatitudeyyy";
  
  public static final String TAG_ISO_SPEED_LATITUDE_ZZZ = "ISOSpeedLatitudezzz";
  
  @Deprecated
  public static final String TAG_ISO_SPEED_RATINGS = "ISOSpeedRatings";
  
  public static final String TAG_JPEG_INTERCHANGE_FORMAT = "JPEGInterchangeFormat";
  
  public static final String TAG_JPEG_INTERCHANGE_FORMAT_LENGTH = "JPEGInterchangeFormatLength";
  
  public static final String TAG_LENS_MAKE = "LensMake";
  
  public static final String TAG_LENS_MODEL = "LensModel";
  
  public static final String TAG_LENS_SERIAL_NUMBER = "LensSerialNumber";
  
  public static final String TAG_LENS_SPECIFICATION = "LensSpecification";
  
  public static final String TAG_LIGHT_SOURCE = "LightSource";
  
  public static final String TAG_MAKE = "Make";
  
  public static final String TAG_MAKER_NOTE = "MakerNote";
  
  public static final String TAG_MAX_APERTURE_VALUE = "MaxApertureValue";
  
  public static final String TAG_METERING_MODE = "MeteringMode";
  
  public static final String TAG_MODEL = "Model";
  
  public static final String TAG_NEW_SUBFILE_TYPE = "NewSubfileType";
  
  public static final String TAG_OECF = "OECF";
  
  public static final String TAG_ORF_ASPECT_FRAME = "AspectFrame";
  
  private static final String TAG_ORF_CAMERA_SETTINGS_IFD_POINTER = "CameraSettingsIFDPointer";
  
  private static final String TAG_ORF_IMAGE_PROCESSING_IFD_POINTER = "ImageProcessingIFDPointer";
  
  public static final String TAG_ORF_PREVIEW_IMAGE_LENGTH = "PreviewImageLength";
  
  public static final String TAG_ORF_PREVIEW_IMAGE_START = "PreviewImageStart";
  
  public static final String TAG_ORF_THUMBNAIL_IMAGE = "ThumbnailImage";
  
  public static final String TAG_ORIENTATION = "Orientation";
  
  public static final String TAG_PHOTOGRAPHIC_SENSITIVITY = "PhotographicSensitivity";
  
  public static final String TAG_PHOTOMETRIC_INTERPRETATION = "PhotometricInterpretation";
  
  public static final String TAG_PIXEL_X_DIMENSION = "PixelXDimension";
  
  public static final String TAG_PIXEL_Y_DIMENSION = "PixelYDimension";
  
  public static final String TAG_PLANAR_CONFIGURATION = "PlanarConfiguration";
  
  public static final String TAG_PRIMARY_CHROMATICITIES = "PrimaryChromaticities";
  
  private static final ExifTag TAG_RAF_IMAGE_SIZE;
  
  public static final String TAG_RECOMMENDED_EXPOSURE_INDEX = "RecommendedExposureIndex";
  
  public static final String TAG_REFERENCE_BLACK_WHITE = "ReferenceBlackWhite";
  
  public static final String TAG_RELATED_SOUND_FILE = "RelatedSoundFile";
  
  public static final String TAG_RESOLUTION_UNIT = "ResolutionUnit";
  
  public static final String TAG_ROWS_PER_STRIP = "RowsPerStrip";
  
  public static final String TAG_RW2_ISO = "ISO";
  
  public static final String TAG_RW2_JPG_FROM_RAW = "JpgFromRaw";
  
  public static final String TAG_RW2_SENSOR_BOTTOM_BORDER = "SensorBottomBorder";
  
  public static final String TAG_RW2_SENSOR_LEFT_BORDER = "SensorLeftBorder";
  
  public static final String TAG_RW2_SENSOR_RIGHT_BORDER = "SensorRightBorder";
  
  public static final String TAG_RW2_SENSOR_TOP_BORDER = "SensorTopBorder";
  
  public static final String TAG_SAMPLES_PER_PIXEL = "SamplesPerPixel";
  
  public static final String TAG_SATURATION = "Saturation";
  
  public static final String TAG_SCENE_CAPTURE_TYPE = "SceneCaptureType";
  
  public static final String TAG_SCENE_TYPE = "SceneType";
  
  public static final String TAG_SENSING_METHOD = "SensingMethod";
  
  public static final String TAG_SENSITIVITY_TYPE = "SensitivityType";
  
  public static final String TAG_SHARPNESS = "Sharpness";
  
  public static final String TAG_SHUTTER_SPEED_VALUE = "ShutterSpeedValue";
  
  public static final String TAG_SOFTWARE = "Software";
  
  public static final String TAG_SPATIAL_FREQUENCY_RESPONSE = "SpatialFrequencyResponse";
  
  public static final String TAG_SPECTRAL_SENSITIVITY = "SpectralSensitivity";
  
  public static final String TAG_STANDARD_OUTPUT_SENSITIVITY = "StandardOutputSensitivity";
  
  public static final String TAG_STRIP_BYTE_COUNTS = "StripByteCounts";
  
  public static final String TAG_STRIP_OFFSETS = "StripOffsets";
  
  public static final String TAG_SUBFILE_TYPE = "SubfileType";
  
  public static final String TAG_SUBJECT_AREA = "SubjectArea";
  
  public static final String TAG_SUBJECT_DISTANCE = "SubjectDistance";
  
  public static final String TAG_SUBJECT_DISTANCE_RANGE = "SubjectDistanceRange";
  
  public static final String TAG_SUBJECT_LOCATION = "SubjectLocation";
  
  public static final String TAG_SUBSEC_TIME = "SubSecTime";
  
  public static final String TAG_SUBSEC_TIME_DIGITIZED = "SubSecTimeDigitized";
  
  public static final String TAG_SUBSEC_TIME_ORIGINAL = "SubSecTimeOriginal";
  
  private static final String TAG_SUB_IFD_POINTER = "SubIFDPointer";
  
  private static final String TAG_THUMBNAIL_DATA = "ThumbnailData";
  
  public static final String TAG_THUMBNAIL_IMAGE_LENGTH = "ThumbnailImageLength";
  
  public static final String TAG_THUMBNAIL_IMAGE_WIDTH = "ThumbnailImageWidth";
  
  private static final String TAG_THUMBNAIL_LENGTH = "ThumbnailLength";
  
  private static final String TAG_THUMBNAIL_OFFSET = "ThumbnailOffset";
  
  public static final String TAG_TRANSFER_FUNCTION = "TransferFunction";
  
  public static final String TAG_USER_COMMENT = "UserComment";
  
  public static final String TAG_WHITE_BALANCE = "WhiteBalance";
  
  public static final String TAG_WHITE_POINT = "WhitePoint";
  
  public static final String TAG_X_RESOLUTION = "XResolution";
  
  public static final String TAG_Y_CB_CR_COEFFICIENTS = "YCbCrCoefficients";
  
  public static final String TAG_Y_CB_CR_POSITIONING = "YCbCrPositioning";
  
  public static final String TAG_Y_CB_CR_SUB_SAMPLING = "YCbCrSubSampling";
  
  public static final String TAG_Y_RESOLUTION = "YResolution";
  
  @Deprecated
  public static final int WHITEBALANCE_AUTO = 0;
  
  @Deprecated
  public static final int WHITEBALANCE_MANUAL = 1;
  
  public static final short WHITE_BALANCE_AUTO = 0;
  
  public static final short WHITE_BALANCE_MANUAL = 1;
  
  public static final short Y_CB_CR_POSITIONING_CENTERED = 1;
  
  public static final short Y_CB_CR_POSITIONING_CO_SITED = 2;
  
  private static final HashMap<Integer, Integer> sExifPointerTagMap;
  
  private static final HashMap<Integer, ExifTag>[] sExifTagMapsForReading;
  
  private static final HashMap<String, ExifTag>[] sExifTagMapsForWriting;
  
  private static SimpleDateFormat sFormatter;
  
  private static final Pattern sGpsTimestampPattern;
  
  private static final Pattern sNonZeroTimePattern;
  
  private static final HashSet<String> sTagSetForCompatibility;
  
  private final AssetManager.AssetInputStream mAssetInputStream;
  
  private final HashMap<String, ExifAttribute>[] mAttributes = (HashMap<String, ExifAttribute>[])new HashMap[EXIF_TAGS.length];
  
  private ByteOrder mExifByteOrder = ByteOrder.BIG_ENDIAN;
  
  private int mExifOffset;
  
  private final String mFilename;
  
  private boolean mHasThumbnail;
  
  private boolean mIsSupportedFile;
  
  private int mMimeType;
  
  private int mOrfMakerNoteOffset;
  
  private int mOrfThumbnailLength;
  
  private int mOrfThumbnailOffset;
  
  private int mRw2JpgFromRawOffset;
  
  private byte[] mThumbnailBytes;
  
  private int mThumbnailCompression;
  
  private int mThumbnailLength;
  
  private int mThumbnailOffset;
  
  static {
    FLIPPED_ROTATION_ORDER = Arrays.asList(new Integer[] { Integer.valueOf(2), Integer.valueOf(7), Integer.valueOf(4), Integer.valueOf(5) });
    BITS_PER_SAMPLE_RGB = new int[] { 8, 8, 8 };
    BITS_PER_SAMPLE_GREYSCALE_1 = new int[] { 4 };
    BITS_PER_SAMPLE_GREYSCALE_2 = new int[] { 8 };
    JPEG_SIGNATURE = new byte[] { -1, -40, -1 };
    ORF_MAKER_NOTE_HEADER_1 = new byte[] { 79, 76, 89, 77, 80, 0 };
    ORF_MAKER_NOTE_HEADER_2 = new byte[] { 79, 76, 89, 77, 80, 85, 83, 0, 73, 73 };
    IFD_FORMAT_NAMES = new String[] { 
        "", "BYTE", "STRING", "USHORT", "ULONG", "URATIONAL", "SBYTE", "UNDEFINED", "SSHORT", "SLONG", 
        "SRATIONAL", "SINGLE", "DOUBLE" };
    IFD_FORMAT_BYTES_PER_FORMAT = new int[] { 
        0, 1, 1, 2, 4, 8, 1, 1, 2, 4, 
        8, 4, 8, 1 };
    EXIF_ASCII_PREFIX = new byte[] { 65, 83, 67, 73, 73, 0, 0, 0 };
    IFD_TIFF_TAGS = new ExifTag[] { 
        new ExifTag("NewSubfileType", 254, 4), new ExifTag("SubfileType", 255, 4), new ExifTag("ImageWidth", 256, 3, 4), new ExifTag("ImageLength", 257, 3, 4), new ExifTag("BitsPerSample", 258, 3), new ExifTag("Compression", 259, 3), new ExifTag("PhotometricInterpretation", 262, 3), new ExifTag("ImageDescription", 270, 2), new ExifTag("Make", 271, 2), new ExifTag("Model", 272, 2), 
        new ExifTag("StripOffsets", 273, 3, 4), new ExifTag("Orientation", 274, 3), new ExifTag("SamplesPerPixel", 277, 3), new ExifTag("RowsPerStrip", 278, 3, 4), new ExifTag("StripByteCounts", 279, 3, 4), new ExifTag("XResolution", 282, 5), new ExifTag("YResolution", 283, 5), new ExifTag("PlanarConfiguration", 284, 3), new ExifTag("ResolutionUnit", 296, 3), new ExifTag("TransferFunction", 301, 3), 
        new ExifTag("Software", 305, 2), new ExifTag("DateTime", 306, 2), new ExifTag("Artist", 315, 2), new ExifTag("WhitePoint", 318, 5), new ExifTag("PrimaryChromaticities", 319, 5), new ExifTag("SubIFDPointer", 330, 4), new ExifTag("JPEGInterchangeFormat", 513, 4), new ExifTag("JPEGInterchangeFormatLength", 514, 4), new ExifTag("YCbCrCoefficients", 529, 5), new ExifTag("YCbCrSubSampling", 530, 3), 
        new ExifTag("YCbCrPositioning", 531, 3), new ExifTag("ReferenceBlackWhite", 532, 5), new ExifTag("Copyright", 33432, 2), new ExifTag("ExifIFDPointer", 34665, 4), new ExifTag("GPSInfoIFDPointer", 34853, 4), new ExifTag("SensorTopBorder", 4, 4), new ExifTag("SensorLeftBorder", 5, 4), new ExifTag("SensorBottomBorder", 6, 4), new ExifTag("SensorRightBorder", 7, 4), new ExifTag("ISO", 23, 3), 
        new ExifTag("JpgFromRaw", 46, 7) };
    IFD_EXIF_TAGS = new ExifTag[] { 
        new ExifTag("ExposureTime", 33434, 5), new ExifTag("FNumber", 33437, 5), new ExifTag("ExposureProgram", 34850, 3), new ExifTag("SpectralSensitivity", 34852, 2), new ExifTag("PhotographicSensitivity", 34855, 3), new ExifTag("OECF", 34856, 7), new ExifTag("ExifVersion", 36864, 2), new ExifTag("DateTimeOriginal", 36867, 2), new ExifTag("DateTimeDigitized", 36868, 2), new ExifTag("ComponentsConfiguration", 37121, 7), 
        new ExifTag("CompressedBitsPerPixel", 37122, 5), new ExifTag("ShutterSpeedValue", 37377, 10), new ExifTag("ApertureValue", 37378, 5), new ExifTag("BrightnessValue", 37379, 10), new ExifTag("ExposureBiasValue", 37380, 10), new ExifTag("MaxApertureValue", 37381, 5), new ExifTag("SubjectDistance", 37382, 5), new ExifTag("MeteringMode", 37383, 3), new ExifTag("LightSource", 37384, 3), new ExifTag("Flash", 37385, 3), 
        new ExifTag("FocalLength", 37386, 5), new ExifTag("SubjectArea", 37396, 3), new ExifTag("MakerNote", 37500, 7), new ExifTag("UserComment", 37510, 7), new ExifTag("SubSecTime", 37520, 2), new ExifTag("SubSecTimeOriginal", 37521, 2), new ExifTag("SubSecTimeDigitized", 37522, 2), new ExifTag("FlashpixVersion", 40960, 7), new ExifTag("ColorSpace", 40961, 3), new ExifTag("PixelXDimension", 40962, 3, 4), 
        new ExifTag("PixelYDimension", 40963, 3, 4), new ExifTag("RelatedSoundFile", 40964, 2), new ExifTag("InteroperabilityIFDPointer", 40965, 4), new ExifTag("FlashEnergy", 41483, 5), new ExifTag("SpatialFrequencyResponse", 41484, 7), new ExifTag("FocalPlaneXResolution", 41486, 5), new ExifTag("FocalPlaneYResolution", 41487, 5), new ExifTag("FocalPlaneResolutionUnit", 41488, 3), new ExifTag("SubjectLocation", 41492, 3), new ExifTag("ExposureIndex", 41493, 5), 
        new ExifTag("SensingMethod", 41495, 3), new ExifTag("FileSource", 41728, 7), new ExifTag("SceneType", 41729, 7), new ExifTag("CFAPattern", 41730, 7), new ExifTag("CustomRendered", 41985, 3), new ExifTag("ExposureMode", 41986, 3), new ExifTag("WhiteBalance", 41987, 3), new ExifTag("DigitalZoomRatio", 41988, 5), new ExifTag("FocalLengthIn35mmFilm", 41989, 3), new ExifTag("SceneCaptureType", 41990, 3), 
        new ExifTag("GainControl", 41991, 3), new ExifTag("Contrast", 41992, 3), new ExifTag("Saturation", 41993, 3), new ExifTag("Sharpness", 41994, 3), new ExifTag("DeviceSettingDescription", 41995, 7), new ExifTag("SubjectDistanceRange", 41996, 3), new ExifTag("ImageUniqueID", 42016, 2), new ExifTag("DNGVersion", 50706, 1), new ExifTag("DefaultCropSize", 50720, 3, 4) };
    IFD_GPS_TAGS = new ExifTag[] { 
        new ExifTag("GPSVersionID", 0, 1), new ExifTag("GPSLatitudeRef", 1, 2), new ExifTag("GPSLatitude", 2, 5), new ExifTag("GPSLongitudeRef", 3, 2), new ExifTag("GPSLongitude", 4, 5), new ExifTag("GPSAltitudeRef", 5, 1), new ExifTag("GPSAltitude", 6, 5), new ExifTag("GPSTimeStamp", 7, 5), new ExifTag("GPSSatellites", 8, 2), new ExifTag("GPSStatus", 9, 2), 
        new ExifTag("GPSMeasureMode", 10, 2), new ExifTag("GPSDOP", 11, 5), new ExifTag("GPSSpeedRef", 12, 2), new ExifTag("GPSSpeed", 13, 5), new ExifTag("GPSTrackRef", 14, 2), new ExifTag("GPSTrack", 15, 5), new ExifTag("GPSImgDirectionRef", 16, 2), new ExifTag("GPSImgDirection", 17, 5), new ExifTag("GPSMapDatum", 18, 2), new ExifTag("GPSDestLatitudeRef", 19, 2), 
        new ExifTag("GPSDestLatitude", 20, 5), new ExifTag("GPSDestLongitudeRef", 21, 2), new ExifTag("GPSDestLongitude", 22, 5), new ExifTag("GPSDestBearingRef", 23, 2), new ExifTag("GPSDestBearing", 24, 5), new ExifTag("GPSDestDistanceRef", 25, 2), new ExifTag("GPSDestDistance", 26, 5), new ExifTag("GPSProcessingMethod", 27, 7), new ExifTag("GPSAreaInformation", 28, 7), new ExifTag("GPSDateStamp", 29, 2), 
        new ExifTag("GPSDifferential", 30, 3) };
    IFD_INTEROPERABILITY_TAGS = new ExifTag[] { new ExifTag("InteroperabilityIndex", 1, 2) };
    IFD_THUMBNAIL_TAGS = new ExifTag[] { 
        new ExifTag("NewSubfileType", 254, 4), new ExifTag("SubfileType", 255, 4), new ExifTag("ThumbnailImageWidth", 256, 3, 4), new ExifTag("ThumbnailImageLength", 257, 3, 4), new ExifTag("BitsPerSample", 258, 3), new ExifTag("Compression", 259, 3), new ExifTag("PhotometricInterpretation", 262, 3), new ExifTag("ImageDescription", 270, 2), new ExifTag("Make", 271, 2), new ExifTag("Model", 272, 2), 
        new ExifTag("StripOffsets", 273, 3, 4), new ExifTag("Orientation", 274, 3), new ExifTag("SamplesPerPixel", 277, 3), new ExifTag("RowsPerStrip", 278, 3, 4), new ExifTag("StripByteCounts", 279, 3, 4), new ExifTag("XResolution", 282, 5), new ExifTag("YResolution", 283, 5), new ExifTag("PlanarConfiguration", 284, 3), new ExifTag("ResolutionUnit", 296, 3), new ExifTag("TransferFunction", 301, 3), 
        new ExifTag("Software", 305, 2), new ExifTag("DateTime", 306, 2), new ExifTag("Artist", 315, 2), new ExifTag("WhitePoint", 318, 5), new ExifTag("PrimaryChromaticities", 319, 5), new ExifTag("SubIFDPointer", 330, 4), new ExifTag("JPEGInterchangeFormat", 513, 4), new ExifTag("JPEGInterchangeFormatLength", 514, 4), new ExifTag("YCbCrCoefficients", 529, 5), new ExifTag("YCbCrSubSampling", 530, 3), 
        new ExifTag("YCbCrPositioning", 531, 3), new ExifTag("ReferenceBlackWhite", 532, 5), new ExifTag("Copyright", 33432, 2), new ExifTag("ExifIFDPointer", 34665, 4), new ExifTag("GPSInfoIFDPointer", 34853, 4), new ExifTag("DNGVersion", 50706, 1), new ExifTag("DefaultCropSize", 50720, 3, 4) };
    TAG_RAF_IMAGE_SIZE = new ExifTag("StripOffsets", 273, 3);
    ORF_MAKER_NOTE_TAGS = new ExifTag[] { new ExifTag("ThumbnailImage", 256, 7), new ExifTag("CameraSettingsIFDPointer", 8224, 4), new ExifTag("ImageProcessingIFDPointer", 8256, 4) };
    ORF_CAMERA_SETTINGS_TAGS = new ExifTag[] { new ExifTag("PreviewImageStart", 257, 4), new ExifTag("PreviewImageLength", 258, 4) };
    ORF_IMAGE_PROCESSING_TAGS = new ExifTag[] { new ExifTag("AspectFrame", 4371, 3) };
    PEF_TAGS = new ExifTag[] { new ExifTag("ColorSpace", 55, 3) };
    EXIF_TAGS = new ExifTag[][] { IFD_TIFF_TAGS, IFD_EXIF_TAGS, IFD_GPS_TAGS, IFD_INTEROPERABILITY_TAGS, IFD_THUMBNAIL_TAGS, IFD_TIFF_TAGS, ORF_MAKER_NOTE_TAGS, ORF_CAMERA_SETTINGS_TAGS, ORF_IMAGE_PROCESSING_TAGS, PEF_TAGS };
    EXIF_POINTER_TAGS = new ExifTag[] { new ExifTag("SubIFDPointer", 330, 4), new ExifTag("ExifIFDPointer", 34665, 4), new ExifTag("GPSInfoIFDPointer", 34853, 4), new ExifTag("InteroperabilityIFDPointer", 40965, 4), new ExifTag("CameraSettingsIFDPointer", 8224, 1), new ExifTag("ImageProcessingIFDPointer", 8256, 1) };
    JPEG_INTERCHANGE_FORMAT_TAG = new ExifTag("JPEGInterchangeFormat", 513, 4);
    JPEG_INTERCHANGE_FORMAT_LENGTH_TAG = new ExifTag("JPEGInterchangeFormatLength", 514, 4);
    sExifTagMapsForReading = (HashMap<Integer, ExifTag>[])new HashMap[EXIF_TAGS.length];
    sExifTagMapsForWriting = (HashMap<String, ExifTag>[])new HashMap[EXIF_TAGS.length];
    sTagSetForCompatibility = new HashSet<String>(Arrays.asList(new String[] { "FNumber", "DigitalZoomRatio", "ExposureTime", "SubjectDistance", "GPSTimeStamp" }));
    sExifPointerTagMap = new HashMap<Integer, Integer>();
    ASCII = Charset.forName("US-ASCII");
    IDENTIFIER_EXIF_APP1 = "Exif\000\000".getBytes(ASCII);
    sFormatter = new SimpleDateFormat("yyyy:MM:dd HH:mm:ss");
    sFormatter.setTimeZone(TimeZone.getTimeZone("UTC"));
    for (int i = 0; i < EXIF_TAGS.length; i++) {
      sExifTagMapsForReading[i] = new HashMap<Integer, ExifTag>();
      sExifTagMapsForWriting[i] = new HashMap<String, ExifTag>();
      for (ExifTag exifTag : EXIF_TAGS[i]) {
        sExifTagMapsForReading[i].put(Integer.valueOf(exifTag.number), exifTag);
        sExifTagMapsForWriting[i].put(exifTag.name, exifTag);
      } 
    } 
    sExifPointerTagMap.put(Integer.valueOf((EXIF_POINTER_TAGS[0]).number), Integer.valueOf(5));
    sExifPointerTagMap.put(Integer.valueOf((EXIF_POINTER_TAGS[1]).number), Integer.valueOf(1));
    sExifPointerTagMap.put(Integer.valueOf((EXIF_POINTER_TAGS[2]).number), Integer.valueOf(2));
    sExifPointerTagMap.put(Integer.valueOf((EXIF_POINTER_TAGS[3]).number), Integer.valueOf(3));
    sExifPointerTagMap.put(Integer.valueOf((EXIF_POINTER_TAGS[4]).number), Integer.valueOf(7));
    sExifPointerTagMap.put(Integer.valueOf((EXIF_POINTER_TAGS[5]).number), Integer.valueOf(8));
    sNonZeroTimePattern = Pattern.compile(".*[1-9].*");
    sGpsTimestampPattern = Pattern.compile("^([0-9][0-9]):([0-9][0-9]):([0-9][0-9])$");
  }
  
  public ExifInterface(@NonNull InputStream paramInputStream) throws IOException {
    if (paramInputStream != null) {
      this.mFilename = null;
      if (paramInputStream instanceof AssetManager.AssetInputStream) {
        this.mAssetInputStream = (AssetManager.AssetInputStream)paramInputStream;
      } else {
        this.mAssetInputStream = null;
      } 
      loadAttributes(paramInputStream);
      return;
    } 
    throw new IllegalArgumentException("inputStream cannot be null");
  }
  
  public ExifInterface(@NonNull String paramString) throws IOException {
    if (paramString != null) {
      Exception exception;
      String str = null;
      this.mAssetInputStream = null;
      this.mFilename = paramString;
      try {
        FileInputStream fileInputStream = new FileInputStream(paramString);
      } finally {
        exception = null;
      } 
      closeQuietly((Closeable)paramString);
      throw exception;
    } 
    throw new IllegalArgumentException("filename cannot be null");
  }
  
  private void addDefaultValuesForCompatibility() {
    String str = getAttribute("DateTimeOriginal");
    if (str != null && getAttribute("DateTime") == null)
      this.mAttributes[0].put("DateTime", ExifAttribute.createString(str)); 
    if (getAttribute("ImageWidth") == null)
      this.mAttributes[0].put("ImageWidth", ExifAttribute.createULong(0L, this.mExifByteOrder)); 
    if (getAttribute("ImageLength") == null)
      this.mAttributes[0].put("ImageLength", ExifAttribute.createULong(0L, this.mExifByteOrder)); 
    if (getAttribute("Orientation") == null)
      this.mAttributes[0].put("Orientation", ExifAttribute.createULong(0L, this.mExifByteOrder)); 
    if (getAttribute("LightSource") == null)
      this.mAttributes[1].put("LightSource", ExifAttribute.createULong(0L, this.mExifByteOrder)); 
  }
  
  private static void closeQuietly(Closeable paramCloseable) {
    if (paramCloseable != null)
      try {
        paramCloseable.close();
        return;
      } catch (RuntimeException runtimeException) {
        throw runtimeException;
      } catch (Exception exception) {
        return;
      }  
  }
  
  private String convertDecimalDegree(double paramDouble) {
    long l1 = (long)paramDouble;
    double d = l1;
    Double.isNaN(d);
    paramDouble -= d;
    long l2 = (long)(paramDouble * 60.0D);
    d = l2;
    Double.isNaN(d);
    long l3 = Math.round((paramDouble - d / 60.0D) * 3600.0D * 1.0E7D);
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append(l1);
    stringBuilder.append("/1,");
    stringBuilder.append(l2);
    stringBuilder.append("/1,");
    stringBuilder.append(l3);
    stringBuilder.append("/10000000");
    return stringBuilder.toString();
  }
  
  private static double convertRationalLatLonToDouble(String paramString1, String paramString2) {
    try {
      String[] arrayOfString1 = paramString1.split(",");
      String[] arrayOfString2 = arrayOfString1[0].split("/");
      double d1 = Double.parseDouble(arrayOfString2[0].trim()) / Double.parseDouble(arrayOfString2[1].trim());
      arrayOfString2 = arrayOfString1[1].split("/");
      double d2 = Double.parseDouble(arrayOfString2[0].trim()) / Double.parseDouble(arrayOfString2[1].trim());
      arrayOfString1 = arrayOfString1[2].split("/");
      double d3 = Double.parseDouble(arrayOfString1[0].trim()) / Double.parseDouble(arrayOfString1[1].trim());
      d1 = d1 + d2 / 60.0D + d3 / 3600.0D;
      if (paramString2.equals("S") || paramString2.equals("W"))
        return -d1; 
      if (!paramString2.equals("N")) {
        if (paramString2.equals("E"))
          return d1; 
        throw new IllegalArgumentException();
      } 
      return d1;
    } catch (NumberFormatException|ArrayIndexOutOfBoundsException numberFormatException) {
      throw new IllegalArgumentException();
    } 
  }
  
  private static long[] convertToLongArray(Object paramObject) {
    if (paramObject instanceof int[]) {
      paramObject = paramObject;
      long[] arrayOfLong = new long[paramObject.length];
      for (int i = 0; i < paramObject.length; i++)
        arrayOfLong[i] = paramObject[i]; 
      return arrayOfLong;
    } 
    return (paramObject instanceof long[]) ? (long[])paramObject : null;
  }
  
  private static int copy(InputStream paramInputStream, OutputStream paramOutputStream) throws IOException {
    byte[] arrayOfByte = new byte[8192];
    int i = 0;
    while (true) {
      int j = paramInputStream.read(arrayOfByte);
      if (j != -1) {
        i += j;
        paramOutputStream.write(arrayOfByte, 0, j);
        continue;
      } 
      return i;
    } 
  }
  
  @Nullable
  private ExifAttribute getExifAttribute(@NonNull String paramString) {
    String str = paramString;
    if ("ISOSpeedRatings".equals(paramString))
      str = "PhotographicSensitivity"; 
    for (int i = 0; i < EXIF_TAGS.length; i++) {
      ExifAttribute exifAttribute = this.mAttributes[i].get(str);
      if (exifAttribute != null)
        return exifAttribute; 
    } 
    return null;
  }
  
  private void getJpegAttributes(ByteOrderedDataInputStream paramByteOrderedDataInputStream, int paramInt1, int paramInt2) throws IOException {
    paramByteOrderedDataInputStream.setByteOrder(ByteOrder.BIG_ENDIAN);
    paramByteOrderedDataInputStream.seek(paramInt1);
    int i = paramByteOrderedDataInputStream.readByte();
    if (i == -1) {
      if (paramByteOrderedDataInputStream.readByte() == -40) {
        paramInt1 = paramInt1 + 1 + 1;
        while (true) {
          i = paramByteOrderedDataInputStream.readByte();
          if (i == -1) {
            byte b = paramByteOrderedDataInputStream.readByte();
            if (b != -39) {
              if (b == -38)
                continue; 
              i = paramByteOrderedDataInputStream.readUnsignedShort() - 2;
              int j = paramInt1 + 1 + 1 + 2;
              if (i >= 0) {
                if (b != -31) {
                  if (b != -2) {
                    switch (b) {
                      default:
                        switch (b) {
                          default:
                            switch (b) {
                              default:
                                switch (b) {
                                  default:
                                    paramInt1 = i;
                                    i = j;
                                    break;
                                  case -51:
                                  case -50:
                                  case -49:
                                    break;
                                } 
                                break;
                              case -55:
                              case -54:
                              case -53:
                                break;
                            } 
                            break;
                          case -59:
                          case -58:
                          case -57:
                            break;
                        } 
                      case -64:
                      case -63:
                      case -62:
                      case -61:
                        if (paramByteOrderedDataInputStream.skipBytes(1) == 1) {
                          this.mAttributes[paramInt2].put("ImageLength", ExifAttribute.createULong(paramByteOrderedDataInputStream.readUnsignedShort(), this.mExifByteOrder));
                          this.mAttributes[paramInt2].put("ImageWidth", ExifAttribute.createULong(paramByteOrderedDataInputStream.readUnsignedShort(), this.mExifByteOrder));
                          paramInt1 = i - 5;
                          i = j;
                          break;
                        } 
                        throw new IOException("Invalid SOFx");
                    } 
                  } else {
                    byte[] arrayOfByte = new byte[i];
                    if (paramByteOrderedDataInputStream.read(arrayOfByte) == i) {
                      i = j;
                      if (getAttribute("UserComment") == null) {
                        this.mAttributes[1].put("UserComment", ExifAttribute.createString(new String(arrayOfByte, ASCII)));
                        i = j;
                      } 
                    } else {
                      throw new IOException("Invalid exif");
                    } 
                    paramInt1 = 0;
                  } 
                } else if (i < 6) {
                  paramInt1 = i;
                  i = j;
                } else {
                  byte[] arrayOfByte = new byte[6];
                  if (paramByteOrderedDataInputStream.read(arrayOfByte) == 6) {
                    j += 6;
                    paramInt1 = i - 6;
                    if (!Arrays.equals(arrayOfByte, IDENTIFIER_EXIF_APP1)) {
                      i = j;
                    } else {
                      if (paramInt1 > 0) {
                        this.mExifOffset = j;
                        arrayOfByte = new byte[paramInt1];
                        if (paramByteOrderedDataInputStream.read(arrayOfByte) == paramInt1) {
                          i = j + paramInt1;
                          readExifSegment(arrayOfByte, paramInt2);
                        } else {
                          throw new IOException("Invalid exif");
                        } 
                      } else {
                        throw new IOException("Invalid exif");
                      } 
                      paramInt1 = 0;
                    } 
                  } else {
                    throw new IOException("Invalid exif");
                  } 
                } 
                if (paramInt1 >= 0) {
                  if (paramByteOrderedDataInputStream.skipBytes(paramInt1) == paramInt1) {
                    paramInt1 = i + paramInt1;
                    continue;
                  } 
                  throw new IOException("Invalid JPEG segment");
                } 
                throw new IOException("Invalid length");
              } 
              throw new IOException("Invalid length");
            } 
            paramByteOrderedDataInputStream.setByteOrder(this.mExifByteOrder);
            return;
          } 
          StringBuilder stringBuilder2 = new StringBuilder();
          stringBuilder2.append("Invalid marker:");
          stringBuilder2.append(Integer.toHexString(i & 0xFF));
          throw new IOException(stringBuilder2.toString());
        } 
      } 
      StringBuilder stringBuilder1 = new StringBuilder();
      stringBuilder1.append("Invalid marker: ");
      stringBuilder1.append(Integer.toHexString(i & 0xFF));
      throw new IOException(stringBuilder1.toString());
    } 
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("Invalid marker: ");
    stringBuilder.append(Integer.toHexString(i & 0xFF));
    throw new IOException(stringBuilder.toString());
  }
  
  private int getMimeType(BufferedInputStream paramBufferedInputStream) throws IOException {
    paramBufferedInputStream.mark(5000);
    byte[] arrayOfByte = new byte[5000];
    paramBufferedInputStream.read(arrayOfByte);
    paramBufferedInputStream.reset();
    return isJpegFormat(arrayOfByte) ? 4 : (isRafFormat(arrayOfByte) ? 9 : (isOrfFormat(arrayOfByte) ? 7 : (isRw2Format(arrayOfByte) ? 10 : 0)));
  }
  
  private void getOrfAttributes(ByteOrderedDataInputStream paramByteOrderedDataInputStream) throws IOException {
    getRawAttributes(paramByteOrderedDataInputStream);
    ExifAttribute exifAttribute = this.mAttributes[1].get("MakerNote");
    if (exifAttribute != null) {
      ByteOrderedDataInputStream byteOrderedDataInputStream = new ByteOrderedDataInputStream(exifAttribute.bytes);
      byteOrderedDataInputStream.setByteOrder(this.mExifByteOrder);
      byte[] arrayOfByte1 = new byte[ORF_MAKER_NOTE_HEADER_1.length];
      byteOrderedDataInputStream.readFully(arrayOfByte1);
      byteOrderedDataInputStream.seek(0L);
      byte[] arrayOfByte2 = new byte[ORF_MAKER_NOTE_HEADER_2.length];
      byteOrderedDataInputStream.readFully(arrayOfByte2);
      if (Arrays.equals(arrayOfByte1, ORF_MAKER_NOTE_HEADER_1)) {
        byteOrderedDataInputStream.seek(8L);
      } else if (Arrays.equals(arrayOfByte2, ORF_MAKER_NOTE_HEADER_2)) {
        byteOrderedDataInputStream.seek(12L);
      } 
      readImageFileDirectory(byteOrderedDataInputStream, 6);
      ExifAttribute exifAttribute1 = this.mAttributes[7].get("PreviewImageStart");
      ExifAttribute exifAttribute2 = this.mAttributes[7].get("PreviewImageLength");
      if (exifAttribute1 != null && exifAttribute2 != null) {
        this.mAttributes[5].put("JPEGInterchangeFormat", exifAttribute1);
        this.mAttributes[5].put("JPEGInterchangeFormatLength", exifAttribute2);
      } 
      exifAttribute1 = this.mAttributes[8].get("AspectFrame");
      if (exifAttribute1 != null) {
        int[] arrayOfInt = (int[])exifAttribute1.getValue(this.mExifByteOrder);
        if (arrayOfInt == null || arrayOfInt.length != 4) {
          StringBuilder stringBuilder = new StringBuilder();
          stringBuilder.append("Invalid aspect frame values. frame=");
          stringBuilder.append(Arrays.toString(arrayOfInt));
          Log.w("ExifInterface", stringBuilder.toString());
          return;
        } 
        if (arrayOfInt[2] > arrayOfInt[0] && arrayOfInt[3] > arrayOfInt[1]) {
          int m = arrayOfInt[2] - arrayOfInt[0] + 1;
          int k = arrayOfInt[3] - arrayOfInt[1] + 1;
          int j = m;
          int i = k;
          if (m < k) {
            j = m + k;
            i = j - k;
            j -= i;
          } 
          ExifAttribute exifAttribute3 = ExifAttribute.createUShort(j, this.mExifByteOrder);
          exifAttribute2 = ExifAttribute.createUShort(i, this.mExifByteOrder);
          this.mAttributes[0].put("ImageWidth", exifAttribute3);
          this.mAttributes[0].put("ImageLength", exifAttribute2);
          return;
        } 
      } 
    } 
  }
  
  private void getRafAttributes(ByteOrderedDataInputStream paramByteOrderedDataInputStream) throws IOException {
    paramByteOrderedDataInputStream.skipBytes(84);
    byte[] arrayOfByte1 = new byte[4];
    byte[] arrayOfByte2 = new byte[4];
    paramByteOrderedDataInputStream.read(arrayOfByte1);
    paramByteOrderedDataInputStream.skipBytes(4);
    paramByteOrderedDataInputStream.read(arrayOfByte2);
    int i = ByteBuffer.wrap(arrayOfByte1).getInt();
    int j = ByteBuffer.wrap(arrayOfByte2).getInt();
    getJpegAttributes(paramByteOrderedDataInputStream, i, 5);
    paramByteOrderedDataInputStream.seek(j);
    paramByteOrderedDataInputStream.setByteOrder(ByteOrder.BIG_ENDIAN);
    j = paramByteOrderedDataInputStream.readInt();
    for (i = 0; i < j; i++) {
      ExifAttribute exifAttribute;
      int k = paramByteOrderedDataInputStream.readUnsignedShort();
      int m = paramByteOrderedDataInputStream.readUnsignedShort();
      if (k == TAG_RAF_IMAGE_SIZE.number) {
        i = paramByteOrderedDataInputStream.readShort();
        j = paramByteOrderedDataInputStream.readShort();
        exifAttribute = ExifAttribute.createUShort(i, this.mExifByteOrder);
        ExifAttribute exifAttribute1 = ExifAttribute.createUShort(j, this.mExifByteOrder);
        this.mAttributes[0].put("ImageLength", exifAttribute);
        this.mAttributes[0].put("ImageWidth", exifAttribute1);
        return;
      } 
      exifAttribute.skipBytes(m);
    } 
  }
  
  private void getRawAttributes(ByteOrderedDataInputStream paramByteOrderedDataInputStream) throws IOException {
    parseTiffHeaders(paramByteOrderedDataInputStream, paramByteOrderedDataInputStream.available());
    readImageFileDirectory(paramByteOrderedDataInputStream, 0);
    updateImageSizeValues(paramByteOrderedDataInputStream, 0);
    updateImageSizeValues(paramByteOrderedDataInputStream, 5);
    updateImageSizeValues(paramByteOrderedDataInputStream, 4);
    validateImages(paramByteOrderedDataInputStream);
    if (this.mMimeType == 8) {
      ExifAttribute exifAttribute = this.mAttributes[1].get("MakerNote");
      if (exifAttribute != null) {
        ByteOrderedDataInputStream byteOrderedDataInputStream = new ByteOrderedDataInputStream(exifAttribute.bytes);
        byteOrderedDataInputStream.setByteOrder(this.mExifByteOrder);
        byteOrderedDataInputStream.seek(6L);
        readImageFileDirectory(byteOrderedDataInputStream, 9);
        ExifAttribute exifAttribute1 = this.mAttributes[9].get("ColorSpace");
        if (exifAttribute1 != null)
          this.mAttributes[1].put("ColorSpace", exifAttribute1); 
      } 
    } 
  }
  
  private void getRw2Attributes(ByteOrderedDataInputStream paramByteOrderedDataInputStream) throws IOException {
    getRawAttributes(paramByteOrderedDataInputStream);
    if ((ExifAttribute)this.mAttributes[0].get("JpgFromRaw") != null)
      getJpegAttributes(paramByteOrderedDataInputStream, this.mRw2JpgFromRawOffset, 5); 
    ExifAttribute exifAttribute1 = this.mAttributes[0].get("ISO");
    ExifAttribute exifAttribute2 = this.mAttributes[1].get("PhotographicSensitivity");
    if (exifAttribute1 != null && exifAttribute2 == null)
      this.mAttributes[1].put("PhotographicSensitivity", exifAttribute1); 
  }
  
  private static Pair<Integer, Integer> guessDataFormat(String paramString) {
    Pair<Integer, Integer> pair;
    long l1;
    long l2;
    boolean bool = paramString.contains(",");
    int i = 1;
    if (bool) {
      String[] arrayOfString = paramString.split(",");
      Pair<Integer, Integer> pair1 = guessDataFormat(arrayOfString[0]);
      pair = pair1;
      if (((Integer)pair1.first).intValue() == 2)
        return pair1; 
      while (i < arrayOfString.length) {
        byte b1;
        byte b2;
        pair1 = guessDataFormat(arrayOfString[i]);
        if (((Integer)pair1.first).equals(pair.first) || ((Integer)pair1.second).equals(pair.first)) {
          b1 = ((Integer)pair.first).intValue();
        } else {
          b1 = -1;
        } 
        if (((Integer)pair.second).intValue() != -1 && (((Integer)pair1.first).equals(pair.second) || ((Integer)pair1.second).equals(pair.second))) {
          b2 = ((Integer)pair.second).intValue();
        } else {
          b2 = -1;
        } 
        if (b1 == -1 && b2 == -1)
          return new Pair(Integer.valueOf(2), Integer.valueOf(-1)); 
        if (b1 == -1) {
          pair = new Pair(Integer.valueOf(b2), Integer.valueOf(-1));
        } else if (b2 == -1) {
          pair = new Pair(Integer.valueOf(b1), Integer.valueOf(-1));
        } 
        i++;
      } 
      return pair;
    } 
    if (pair.contains("/")) {
      String[] arrayOfString = pair.split("/");
      if (arrayOfString.length == 2) {
        try {
          l1 = (long)Double.parseDouble(arrayOfString[0]);
          l2 = (long)Double.parseDouble(arrayOfString[1]);
          if (l1 < 0L || l2 < 0L)
            return new Pair(Integer.valueOf(10), Integer.valueOf(-1)); 
        } catch (NumberFormatException numberFormatException) {
          return new Pair(Integer.valueOf(2), Integer.valueOf(-1));
        } 
      } else {
        return new Pair(Integer.valueOf(2), Integer.valueOf(-1));
      } 
    } else {
      try {
        Long long_ = Long.valueOf(Long.parseLong((String)numberFormatException));
        return (long_.longValue() >= 0L && long_.longValue() <= 65535L) ? new Pair(Integer.valueOf(3), Integer.valueOf(4)) : ((long_.longValue() < 0L) ? new Pair(Integer.valueOf(9), Integer.valueOf(-1)) : new Pair(Integer.valueOf(4), Integer.valueOf(-1)));
      } catch (NumberFormatException numberFormatException1) {
        try {
          Double.parseDouble((String)numberFormatException);
          return new Pair(Integer.valueOf(12), Integer.valueOf(-1));
        } catch (NumberFormatException numberFormatException2) {
          return new Pair(Integer.valueOf(2), Integer.valueOf(-1));
        } 
      } 
    } 
    return (l1 > 2147483647L || l2 > 2147483647L) ? new Pair(Integer.valueOf(5), Integer.valueOf(-1)) : new Pair(Integer.valueOf(10), Integer.valueOf(5));
  }
  
  private void handleThumbnailFromJfif(ByteOrderedDataInputStream paramByteOrderedDataInputStream, HashMap paramHashMap) throws IOException {
    ExifAttribute exifAttribute2 = (ExifAttribute)paramHashMap.get("JPEGInterchangeFormat");
    ExifAttribute exifAttribute1 = (ExifAttribute)paramHashMap.get("JPEGInterchangeFormatLength");
    if (exifAttribute2 != null && exifAttribute1 != null) {
      int i;
      int j = exifAttribute2.getIntValue(this.mExifByteOrder);
      int k = Math.min(exifAttribute1.getIntValue(this.mExifByteOrder), paramByteOrderedDataInputStream.available() - j);
      if (this.mMimeType == 4 || this.mMimeType == 9 || this.mMimeType == 10) {
        i = j + this.mExifOffset;
      } else {
        i = j;
        if (this.mMimeType == 7)
          i = j + this.mOrfMakerNoteOffset; 
      } 
      if (i > 0 && k > 0) {
        this.mHasThumbnail = true;
        this.mThumbnailOffset = i;
        this.mThumbnailLength = k;
        if (this.mFilename == null && this.mAssetInputStream == null) {
          byte[] arrayOfByte = new byte[k];
          paramByteOrderedDataInputStream.seek(i);
          paramByteOrderedDataInputStream.readFully(arrayOfByte);
          this.mThumbnailBytes = arrayOfByte;
        } 
      } 
    } 
  }
  
  private void handleThumbnailFromStrips(ByteOrderedDataInputStream paramByteOrderedDataInputStream, HashMap paramHashMap) throws IOException {
    ExifAttribute exifAttribute1 = (ExifAttribute)paramHashMap.get("StripOffsets");
    ExifAttribute exifAttribute2 = (ExifAttribute)paramHashMap.get("StripByteCounts");
    if (exifAttribute1 != null && exifAttribute2 != null) {
      long[] arrayOfLong1 = convertToLongArray(exifAttribute1.getValue(this.mExifByteOrder));
      long[] arrayOfLong2 = convertToLongArray(exifAttribute2.getValue(this.mExifByteOrder));
      if (arrayOfLong1 == null) {
        Log.w("ExifInterface", "stripOffsets should not be null.");
        return;
      } 
      if (arrayOfLong2 == null) {
        Log.w("ExifInterface", "stripByteCounts should not be null.");
        return;
      } 
      int j = arrayOfLong2.length;
      long l = 0L;
      int i;
      for (i = 0; i < j; i++)
        l += arrayOfLong2[i]; 
      byte[] arrayOfByte = new byte[(int)l];
      j = 0;
      int k = 0;
      i = 0;
      while (j < arrayOfLong1.length) {
        int n = (int)arrayOfLong1[j];
        int m = (int)arrayOfLong2[j];
        n -= k;
        if (n < 0)
          Log.d("ExifInterface", "Invalid strip offset value"); 
        paramByteOrderedDataInputStream.seek(n);
        byte[] arrayOfByte1 = new byte[m];
        paramByteOrderedDataInputStream.read(arrayOfByte1);
        k = k + n + m;
        System.arraycopy(arrayOfByte1, 0, arrayOfByte, i, arrayOfByte1.length);
        i += arrayOfByte1.length;
        j++;
      } 
      this.mHasThumbnail = true;
      this.mThumbnailBytes = arrayOfByte;
      this.mThumbnailLength = arrayOfByte.length;
    } 
  }
  
  private static boolean isJpegFormat(byte[] paramArrayOfbyte) throws IOException {
    for (int i = 0; i < JPEG_SIGNATURE.length; i++) {
      if (paramArrayOfbyte[i] != JPEG_SIGNATURE[i])
        return false; 
    } 
    return true;
  }
  
  private boolean isOrfFormat(byte[] paramArrayOfbyte) throws IOException {
    ByteOrderedDataInputStream byteOrderedDataInputStream = new ByteOrderedDataInputStream(paramArrayOfbyte);
    this.mExifByteOrder = readByteOrder(byteOrderedDataInputStream);
    byteOrderedDataInputStream.setByteOrder(this.mExifByteOrder);
    short s = byteOrderedDataInputStream.readShort();
    byteOrderedDataInputStream.close();
    return (s == 20306 || s == 21330);
  }
  
  private boolean isRafFormat(byte[] paramArrayOfbyte) throws IOException {
    byte[] arrayOfByte = "FUJIFILMCCD-RAW".getBytes(Charset.defaultCharset());
    for (int i = 0; i < arrayOfByte.length; i++) {
      if (paramArrayOfbyte[i] != arrayOfByte[i])
        return false; 
    } 
    return true;
  }
  
  private boolean isRw2Format(byte[] paramArrayOfbyte) throws IOException {
    ByteOrderedDataInputStream byteOrderedDataInputStream = new ByteOrderedDataInputStream(paramArrayOfbyte);
    this.mExifByteOrder = readByteOrder(byteOrderedDataInputStream);
    byteOrderedDataInputStream.setByteOrder(this.mExifByteOrder);
    short s = byteOrderedDataInputStream.readShort();
    byteOrderedDataInputStream.close();
    return (s == 85);
  }
  
  private boolean isSupportedDataType(HashMap paramHashMap) throws IOException {
    ExifAttribute exifAttribute = (ExifAttribute)paramHashMap.get("BitsPerSample");
    if (exifAttribute != null) {
      int[] arrayOfInt = (int[])exifAttribute.getValue(this.mExifByteOrder);
      if (Arrays.equals(BITS_PER_SAMPLE_RGB, arrayOfInt))
        return true; 
      if (this.mMimeType == 3) {
        ExifAttribute exifAttribute1 = (ExifAttribute)paramHashMap.get("PhotometricInterpretation");
        if (exifAttribute1 != null) {
          int i = exifAttribute1.getIntValue(this.mExifByteOrder);
          if ((i == 1 && Arrays.equals(arrayOfInt, BITS_PER_SAMPLE_GREYSCALE_2)) || (i == 6 && Arrays.equals(arrayOfInt, BITS_PER_SAMPLE_RGB)))
            return true; 
        } 
      } 
    } 
    return false;
  }
  
  private boolean isThumbnail(HashMap paramHashMap) throws IOException {
    ExifAttribute exifAttribute2 = (ExifAttribute)paramHashMap.get("ImageLength");
    ExifAttribute exifAttribute1 = (ExifAttribute)paramHashMap.get("ImageWidth");
    if (exifAttribute2 != null && exifAttribute1 != null) {
      int i = exifAttribute2.getIntValue(this.mExifByteOrder);
      int j = exifAttribute1.getIntValue(this.mExifByteOrder);
      if (i <= 512 && j <= 512)
        return true; 
    } 
    return false;
  }
  
  private void loadAttributes(@NonNull InputStream paramInputStream) throws IOException {
    int i = 0;
    try {
      while (i < EXIF_TAGS.length) {
        this.mAttributes[i] = new HashMap<String, ExifAttribute>();
        i++;
      } 
      paramInputStream = new BufferedInputStream(paramInputStream, 5000);
      this.mMimeType = getMimeType((BufferedInputStream)paramInputStream);
      paramInputStream = new ByteOrderedDataInputStream(paramInputStream);
      switch (this.mMimeType) {
        case 10:
          getRw2Attributes((ByteOrderedDataInputStream)paramInputStream);
          break;
        case 9:
          getRafAttributes((ByteOrderedDataInputStream)paramInputStream);
          break;
        case 7:
          getOrfAttributes((ByteOrderedDataInputStream)paramInputStream);
          break;
        case 4:
          getJpegAttributes((ByteOrderedDataInputStream)paramInputStream, 0, 0);
          break;
        case 0:
        case 1:
        case 2:
        case 3:
        case 5:
        case 6:
        case 8:
        case 11:
          getRawAttributes((ByteOrderedDataInputStream)paramInputStream);
          break;
      } 
      setThumbnailData((ByteOrderedDataInputStream)paramInputStream);
    } catch (IOException iOException) {
    
    } finally {
      addDefaultValuesForCompatibility();
    } 
    addDefaultValuesForCompatibility();
  }
  
  private void parseTiffHeaders(ByteOrderedDataInputStream paramByteOrderedDataInputStream, int paramInt) throws IOException {
    this.mExifByteOrder = readByteOrder(paramByteOrderedDataInputStream);
    paramByteOrderedDataInputStream.setByteOrder(this.mExifByteOrder);
    int i = paramByteOrderedDataInputStream.readUnsignedShort();
    if (this.mMimeType == 7 || this.mMimeType == 10 || i == 42) {
      i = paramByteOrderedDataInputStream.readInt();
      if (i >= 8 && i < paramInt) {
        paramInt = i - 8;
        if (paramInt > 0) {
          if (paramByteOrderedDataInputStream.skipBytes(paramInt) == paramInt)
            return; 
          StringBuilder stringBuilder2 = new StringBuilder();
          stringBuilder2.append("Couldn't jump to first Ifd: ");
          stringBuilder2.append(paramInt);
          throw new IOException(stringBuilder2.toString());
        } 
        return;
      } 
      StringBuilder stringBuilder1 = new StringBuilder();
      stringBuilder1.append("Invalid first Ifd offset: ");
      stringBuilder1.append(i);
      throw new IOException(stringBuilder1.toString());
    } 
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("Invalid start code: ");
    stringBuilder.append(Integer.toHexString(i));
    throw new IOException(stringBuilder.toString());
  }
  
  private void printAttributes() {
    for (int i = 0; i < this.mAttributes.length; i++) {
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("The size of tag group[");
      stringBuilder.append(i);
      stringBuilder.append("]: ");
      stringBuilder.append(this.mAttributes[i].size());
      Log.d("ExifInterface", stringBuilder.toString());
      for (Map.Entry<String, ExifAttribute> entry : this.mAttributes[i].entrySet()) {
        ExifAttribute exifAttribute = (ExifAttribute)entry.getValue();
        StringBuilder stringBuilder1 = new StringBuilder();
        stringBuilder1.append("tagName: ");
        stringBuilder1.append((String)entry.getKey());
        stringBuilder1.append(", tagType: ");
        stringBuilder1.append(exifAttribute.toString());
        stringBuilder1.append(", tagValue: '");
        stringBuilder1.append(exifAttribute.getStringValue(this.mExifByteOrder));
        stringBuilder1.append("'");
        Log.d("ExifInterface", stringBuilder1.toString());
      } 
    } 
  }
  
  private ByteOrder readByteOrder(ByteOrderedDataInputStream paramByteOrderedDataInputStream) throws IOException {
    short s = paramByteOrderedDataInputStream.readShort();
    if (s != 18761) {
      if (s == 19789)
        return ByteOrder.BIG_ENDIAN; 
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("Invalid byte order: ");
      stringBuilder.append(Integer.toHexString(s));
      throw new IOException(stringBuilder.toString());
    } 
    return ByteOrder.LITTLE_ENDIAN;
  }
  
  private void readExifSegment(byte[] paramArrayOfbyte, int paramInt) throws IOException {
    ByteOrderedDataInputStream byteOrderedDataInputStream = new ByteOrderedDataInputStream(paramArrayOfbyte);
    parseTiffHeaders(byteOrderedDataInputStream, paramArrayOfbyte.length);
    readImageFileDirectory(byteOrderedDataInputStream, paramInt);
  }
  
  private void readImageFileDirectory(ByteOrderedDataInputStream paramByteOrderedDataInputStream, int paramInt) throws IOException {
    int i = paramInt;
    if (paramByteOrderedDataInputStream.mPosition + 2 > paramByteOrderedDataInputStream.mLength)
      return; 
    short s = paramByteOrderedDataInputStream.readShort();
    if (paramByteOrderedDataInputStream.mPosition + s * 12 > paramByteOrderedDataInputStream.mLength)
      return; 
    short s1 = 0;
    while (true) {
      if (s1 < s) {
        int m = paramByteOrderedDataInputStream.readUnsignedShort();
        int k = paramByteOrderedDataInputStream.readUnsignedShort();
        int n = paramByteOrderedDataInputStream.readInt();
        long l2 = paramByteOrderedDataInputStream.peek() + 4L;
        ExifTag exifTag = sExifTagMapsForReading[i].get(Integer.valueOf(m));
        if (exifTag == null) {
          StringBuilder stringBuilder = new StringBuilder();
          stringBuilder.append("Skip the tag entry since tag number is not defined: ");
          stringBuilder.append(m);
          Log.w("ExifInterface", stringBuilder.toString());
        } else if (k <= 0 || k >= IFD_FORMAT_BYTES_PER_FORMAT.length) {
          StringBuilder stringBuilder = new StringBuilder();
          stringBuilder.append("Skip the tag entry since data format is invalid: ");
          stringBuilder.append(k);
          Log.w("ExifInterface", stringBuilder.toString());
        } else if (!exifTag.isFormatCompatible(k)) {
          StringBuilder stringBuilder = new StringBuilder();
          stringBuilder.append("Skip the tag entry since data format (");
          stringBuilder.append(IFD_FORMAT_NAMES[k]);
          stringBuilder.append(") is unexpected for tag: ");
          stringBuilder.append(exifTag.name);
          Log.w("ExifInterface", stringBuilder.toString());
        } else {
          int i1 = k;
          if (k == 7)
            i1 = exifTag.primaryFormat; 
          long l = n * IFD_FORMAT_BYTES_PER_FORMAT[i1];
          if (l < 0L || l > 2147483647L) {
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append("Skip the tag entry since the number of components is invalid: ");
            stringBuilder.append(n);
            Log.w("ExifInterface", stringBuilder.toString());
          } else {
            k = 1;
            if (k == 0) {
              paramByteOrderedDataInputStream.seek(l2);
              i1 = i;
            } else {
              StringBuilder stringBuilder;
              if (l > 4L) {
                k = paramByteOrderedDataInputStream.readInt();
                if (this.mMimeType == 7) {
                  if ("MakerNote".equals(exifTag.name)) {
                    this.mOrfMakerNoteOffset = k;
                  } else if (i == 6 && "ThumbnailImage".equals(exifTag.name)) {
                    this.mOrfThumbnailOffset = k;
                    this.mOrfThumbnailLength = n;
                    ExifAttribute exifAttribute1 = ExifAttribute.createUShort(6, this.mExifByteOrder);
                    ExifAttribute exifAttribute2 = ExifAttribute.createULong(this.mOrfThumbnailOffset, this.mExifByteOrder);
                    ExifAttribute exifAttribute3 = ExifAttribute.createULong(this.mOrfThumbnailLength, this.mExifByteOrder);
                    this.mAttributes[4].put("Compression", exifAttribute1);
                    this.mAttributes[4].put("JPEGInterchangeFormat", exifAttribute2);
                    this.mAttributes[4].put("JPEGInterchangeFormatLength", exifAttribute3);
                  } 
                } else if (this.mMimeType == 10 && "JpgFromRaw".equals(exifTag.name)) {
                  this.mRw2JpgFromRawOffset = k;
                } 
                long l3 = k;
                if (l3 + l <= paramByteOrderedDataInputStream.mLength) {
                  paramByteOrderedDataInputStream.seek(l3);
                } else {
                  stringBuilder = new StringBuilder();
                  stringBuilder.append("Skip the tag entry since data offset is invalid: ");
                  stringBuilder.append(k);
                  Log.w("ExifInterface", stringBuilder.toString());
                  paramByteOrderedDataInputStream.seek(l2);
                  i1 = paramInt;
                } 
              } 
              Integer integer = sExifPointerTagMap.get(Integer.valueOf(m));
              if (integer != null) {
                l = -1L;
                switch (i1) {
                  case 9:
                  case 13:
                    l = paramByteOrderedDataInputStream.readInt();
                    break;
                  case 8:
                    l = paramByteOrderedDataInputStream.readShort();
                    break;
                  case 4:
                    l = paramByteOrderedDataInputStream.readUnsignedInt();
                    break;
                  case 3:
                    l = paramByteOrderedDataInputStream.readUnsignedShort();
                    break;
                } 
                if (l > 0L && l < paramByteOrderedDataInputStream.mLength) {
                  paramByteOrderedDataInputStream.seek(l);
                  readImageFileDirectory(paramByteOrderedDataInputStream, integer.intValue());
                } else {
                  stringBuilder = new StringBuilder();
                  stringBuilder.append("Skip jump into the IFD since its offset is invalid: ");
                  stringBuilder.append(l);
                  Log.w("ExifInterface", stringBuilder.toString());
                } 
                paramByteOrderedDataInputStream.seek(l2);
              } else {
                byte[] arrayOfByte = new byte[(int)l];
                paramByteOrderedDataInputStream.readFully(arrayOfByte);
                ExifAttribute exifAttribute = new ExifAttribute(i1, n, arrayOfByte);
                HashMap<String, ExifAttribute>[] arrayOfHashMap = this.mAttributes;
                i = paramInt;
                arrayOfHashMap[i].put(((ExifTag)stringBuilder).name, exifAttribute);
                if ("DNGVersion".equals(((ExifTag)stringBuilder).name))
                  this.mMimeType = 3; 
                if ((("Make".equals(((ExifTag)stringBuilder).name) || "Model".equals(((ExifTag)stringBuilder).name)) && exifAttribute.getStringValue(this.mExifByteOrder).contains("PENTAX")) || ("Compression".equals(((ExifTag)stringBuilder).name) && exifAttribute.getIntValue(this.mExifByteOrder) == 65535))
                  this.mMimeType = 8; 
                i1 = i;
                if (paramByteOrderedDataInputStream.peek() != l2) {
                  paramByteOrderedDataInputStream.seek(l2);
                  i1 = i;
                } 
                s1 = (short)(s1 + 1);
                i = i1;
              } 
              i1 = paramInt;
            } 
          } 
          k = 0;
        } 
        long l1 = 0L;
        int j = k;
      } else {
        break;
      } 
      boolean bool = false;
    } 
    if (paramByteOrderedDataInputStream.peek() + 4 <= paramByteOrderedDataInputStream.mLength) {
      paramInt = paramByteOrderedDataInputStream.readInt();
      if (paramInt > 8 && paramInt < paramByteOrderedDataInputStream.mLength) {
        paramByteOrderedDataInputStream.seek(paramInt);
        if (this.mAttributes[4].isEmpty()) {
          readImageFileDirectory(paramByteOrderedDataInputStream, 4);
          return;
        } 
        if (this.mAttributes[5].isEmpty())
          readImageFileDirectory(paramByteOrderedDataInputStream, 5); 
      } 
    } 
  }
  
  private void removeAttribute(String paramString) {
    for (int i = 0; i < EXIF_TAGS.length; i++)
      this.mAttributes[i].remove(paramString); 
  }
  
  private void retrieveJpegImageSize(ByteOrderedDataInputStream paramByteOrderedDataInputStream, int paramInt) throws IOException {
    ExifAttribute exifAttribute1 = this.mAttributes[paramInt].get("ImageLength");
    ExifAttribute exifAttribute2 = this.mAttributes[paramInt].get("ImageWidth");
    if (exifAttribute1 == null || exifAttribute2 == null) {
      exifAttribute1 = this.mAttributes[paramInt].get("JPEGInterchangeFormat");
      if (exifAttribute1 != null)
        getJpegAttributes(paramByteOrderedDataInputStream, exifAttribute1.getIntValue(this.mExifByteOrder), paramInt); 
    } 
  }
  
  private void saveJpegAttributes(InputStream paramInputStream, OutputStream paramOutputStream) throws IOException {
    paramInputStream = new DataInputStream(paramInputStream);
    paramOutputStream = new ByteOrderedDataOutputStream(paramOutputStream, ByteOrder.BIG_ENDIAN);
    if (paramInputStream.readByte() == -1) {
      paramOutputStream.writeByte(-1);
      if (paramInputStream.readByte() == -40) {
        paramOutputStream.writeByte(-40);
        paramOutputStream.writeByte(-1);
        paramOutputStream.writeByte(-31);
        writeExifSegment((ByteOrderedDataOutputStream)paramOutputStream, 6);
        byte[] arrayOfByte = new byte[4096];
        while (paramInputStream.readByte() == -1) {
          byte b = paramInputStream.readByte();
          if (b != -31) {
            int j;
            switch (b) {
              default:
                paramOutputStream.writeByte(-1);
                paramOutputStream.writeByte(b);
                j = paramInputStream.readUnsignedShort();
                paramOutputStream.writeUnsignedShort(j);
                j -= 2;
                if (j >= 0) {
                  while (j > 0) {
                    int k = paramInputStream.read(arrayOfByte, 0, Math.min(j, arrayOfByte.length));
                    if (k >= 0) {
                      paramOutputStream.write(arrayOfByte, 0, k);
                      j -= k;
                    } 
                  } 
                  continue;
                } 
                throw new IOException("Invalid length");
              case -39:
              case -38:
                break;
            } 
            paramOutputStream.writeByte(-1);
            paramOutputStream.writeByte(j);
            copy(paramInputStream, paramOutputStream);
            return;
          } 
          int i = paramInputStream.readUnsignedShort() - 2;
          if (i >= 0) {
            byte[] arrayOfByte1 = new byte[6];
            if (i >= 6)
              if (paramInputStream.read(arrayOfByte1) == 6) {
                if (Arrays.equals(arrayOfByte1, IDENTIFIER_EXIF_APP1)) {
                  j = i - 6;
                  if (paramInputStream.skipBytes(j) == j)
                    continue; 
                  throw new IOException("Invalid length");
                } 
              } else {
                throw new IOException("Invalid exif");
              }  
            paramOutputStream.writeByte(-1);
            paramOutputStream.writeByte(j);
            paramOutputStream.writeUnsignedShort(i + 2);
            int j = i;
            if (i >= 6) {
              j = i - 6;
              paramOutputStream.write(arrayOfByte1);
            } 
            while (j > 0) {
              i = paramInputStream.read(arrayOfByte, 0, Math.min(j, arrayOfByte.length));
              if (i >= 0) {
                paramOutputStream.write(arrayOfByte, 0, i);
                j -= i;
              } 
            } 
            continue;
          } 
          throw new IOException("Invalid length");
        } 
        throw new IOException("Invalid marker");
      } 
      throw new IOException("Invalid marker");
    } 
    throw new IOException("Invalid marker");
  }
  
  private void setThumbnailData(ByteOrderedDataInputStream paramByteOrderedDataInputStream) throws IOException {
    HashMap<String, ExifAttribute> hashMap = this.mAttributes[4];
    ExifAttribute exifAttribute = hashMap.get("Compression");
    if (exifAttribute != null) {
      this.mThumbnailCompression = exifAttribute.getIntValue(this.mExifByteOrder);
      int i = this.mThumbnailCompression;
      if (i != 1)
        switch (i) {
          default:
            return;
          case 6:
            handleThumbnailFromJfif(paramByteOrderedDataInputStream, hashMap);
            return;
          case 7:
            break;
        }  
      if (isSupportedDataType(hashMap)) {
        handleThumbnailFromStrips(paramByteOrderedDataInputStream, hashMap);
        return;
      } 
    } else {
      this.mThumbnailCompression = 6;
      handleThumbnailFromJfif(paramByteOrderedDataInputStream, hashMap);
    } 
  }
  
  private void swapBasedOnImageSize(int paramInt1, int paramInt2) throws IOException {
    if (!this.mAttributes[paramInt1].isEmpty()) {
      if (this.mAttributes[paramInt2].isEmpty())
        return; 
      ExifAttribute exifAttribute1 = this.mAttributes[paramInt1].get("ImageLength");
      ExifAttribute exifAttribute2 = this.mAttributes[paramInt1].get("ImageWidth");
      ExifAttribute exifAttribute3 = this.mAttributes[paramInt2].get("ImageLength");
      ExifAttribute exifAttribute4 = this.mAttributes[paramInt2].get("ImageWidth");
      if (exifAttribute1 != null) {
        if (exifAttribute2 == null)
          return; 
        if (exifAttribute3 != null) {
          if (exifAttribute4 == null)
            return; 
          int i = exifAttribute1.getIntValue(this.mExifByteOrder);
          int j = exifAttribute2.getIntValue(this.mExifByteOrder);
          int k = exifAttribute3.getIntValue(this.mExifByteOrder);
          int m = exifAttribute4.getIntValue(this.mExifByteOrder);
          if (i < k && j < m) {
            HashMap<String, ExifAttribute> hashMap = this.mAttributes[paramInt1];
            this.mAttributes[paramInt1] = this.mAttributes[paramInt2];
            this.mAttributes[paramInt2] = hashMap;
          } 
        } 
      } 
      return;
    } 
  }
  
  private boolean updateAttribute(String paramString, ExifAttribute paramExifAttribute) {
    int i = 0;
    boolean bool = false;
    while (i < EXIF_TAGS.length) {
      if (this.mAttributes[i].containsKey(paramString)) {
        this.mAttributes[i].put(paramString, paramExifAttribute);
        bool = true;
      } 
      i++;
    } 
    return bool;
  }
  
  private void updateImageSizeValues(ByteOrderedDataInputStream paramByteOrderedDataInputStream, int paramInt) throws IOException {
    ExifAttribute exifAttribute1;
    ExifAttribute exifAttribute2 = this.mAttributes[paramInt].get("DefaultCropSize");
    ExifAttribute exifAttribute3 = this.mAttributes[paramInt].get("SensorTopBorder");
    ExifAttribute exifAttribute4 = this.mAttributes[paramInt].get("SensorLeftBorder");
    ExifAttribute exifAttribute5 = this.mAttributes[paramInt].get("SensorBottomBorder");
    ExifAttribute exifAttribute6 = this.mAttributes[paramInt].get("SensorRightBorder");
    if (exifAttribute2 != null) {
      ExifAttribute exifAttribute;
      if (exifAttribute2.format == 5) {
        Rational[] arrayOfRational = (Rational[])exifAttribute2.getValue(this.mExifByteOrder);
        if (arrayOfRational == null || arrayOfRational.length != 2) {
          StringBuilder stringBuilder = new StringBuilder();
          stringBuilder.append("Invalid crop size values. cropSize=");
          stringBuilder.append(Arrays.toString((Object[])arrayOfRational));
          Log.w("ExifInterface", stringBuilder.toString());
          return;
        } 
        exifAttribute1 = ExifAttribute.createURational(arrayOfRational[0], this.mExifByteOrder);
        exifAttribute = ExifAttribute.createURational(arrayOfRational[1], this.mExifByteOrder);
      } else {
        int[] arrayOfInt = (int[])exifAttribute.getValue(this.mExifByteOrder);
        if (arrayOfInt == null || arrayOfInt.length != 2) {
          StringBuilder stringBuilder = new StringBuilder();
          stringBuilder.append("Invalid crop size values. cropSize=");
          stringBuilder.append(Arrays.toString(arrayOfInt));
          Log.w("ExifInterface", stringBuilder.toString());
          return;
        } 
        exifAttribute1 = ExifAttribute.createUShort(arrayOfInt[0], this.mExifByteOrder);
        exifAttribute = ExifAttribute.createUShort(arrayOfInt[1], this.mExifByteOrder);
      } 
      this.mAttributes[paramInt].put("ImageWidth", exifAttribute1);
      this.mAttributes[paramInt].put("ImageLength", exifAttribute);
      return;
    } 
    if (exifAttribute3 != null && exifAttribute4 != null && exifAttribute5 != null && exifAttribute6 != null) {
      int i = exifAttribute3.getIntValue(this.mExifByteOrder);
      int j = exifAttribute5.getIntValue(this.mExifByteOrder);
      int k = exifAttribute6.getIntValue(this.mExifByteOrder);
      int m = exifAttribute4.getIntValue(this.mExifByteOrder);
      if (j > i && k > m) {
        exifAttribute1 = ExifAttribute.createUShort(j - i, this.mExifByteOrder);
        exifAttribute2 = ExifAttribute.createUShort(k - m, this.mExifByteOrder);
        this.mAttributes[paramInt].put("ImageLength", exifAttribute1);
        this.mAttributes[paramInt].put("ImageWidth", exifAttribute2);
        return;
      } 
    } else {
      retrieveJpegImageSize((ByteOrderedDataInputStream)exifAttribute1, paramInt);
    } 
  }
  
  private void validateImages(InputStream paramInputStream) throws IOException {
    swapBasedOnImageSize(0, 5);
    swapBasedOnImageSize(0, 4);
    swapBasedOnImageSize(5, 4);
    ExifAttribute exifAttribute1 = this.mAttributes[1].get("PixelXDimension");
    ExifAttribute exifAttribute2 = this.mAttributes[1].get("PixelYDimension");
    if (exifAttribute1 != null && exifAttribute2 != null) {
      this.mAttributes[0].put("ImageWidth", exifAttribute1);
      this.mAttributes[0].put("ImageLength", exifAttribute2);
    } 
    if (this.mAttributes[4].isEmpty() && isThumbnail(this.mAttributes[5])) {
      this.mAttributes[4] = this.mAttributes[5];
      this.mAttributes[5] = new HashMap<String, ExifAttribute>();
    } 
    if (!isThumbnail(this.mAttributes[4]))
      Log.d("ExifInterface", "No image meets the size requirements of a thumbnail image."); 
  }
  
  private int writeExifSegment(ByteOrderedDataOutputStream paramByteOrderedDataOutputStream, int paramInt) throws IOException {
    char c;
    int[] arrayOfInt1 = new int[EXIF_TAGS.length];
    int[] arrayOfInt2 = new int[EXIF_TAGS.length];
    ExifTag[] arrayOfExifTag = EXIF_POINTER_TAGS;
    int j = arrayOfExifTag.length;
    int i;
    for (i = 0; i < j; i++)
      removeAttribute((arrayOfExifTag[i]).name); 
    removeAttribute(JPEG_INTERCHANGE_FORMAT_TAG.name);
    removeAttribute(JPEG_INTERCHANGE_FORMAT_LENGTH_TAG.name);
    for (i = 0; i < EXIF_TAGS.length; i++) {
      Object[] arrayOfObject = this.mAttributes[i].entrySet().toArray();
      int m = arrayOfObject.length;
      for (j = 0; j < m; j++) {
        Map.Entry entry = (Map.Entry)arrayOfObject[j];
        if (entry.getValue() == null)
          this.mAttributes[i].remove(entry.getKey()); 
      } 
    } 
    if (!this.mAttributes[1].isEmpty())
      this.mAttributes[0].put((EXIF_POINTER_TAGS[1]).name, ExifAttribute.createULong(0L, this.mExifByteOrder)); 
    if (!this.mAttributes[2].isEmpty())
      this.mAttributes[0].put((EXIF_POINTER_TAGS[2]).name, ExifAttribute.createULong(0L, this.mExifByteOrder)); 
    if (!this.mAttributes[3].isEmpty())
      this.mAttributes[1].put((EXIF_POINTER_TAGS[3]).name, ExifAttribute.createULong(0L, this.mExifByteOrder)); 
    if (this.mHasThumbnail) {
      this.mAttributes[4].put(JPEG_INTERCHANGE_FORMAT_TAG.name, ExifAttribute.createULong(0L, this.mExifByteOrder));
      this.mAttributes[4].put(JPEG_INTERCHANGE_FORMAT_LENGTH_TAG.name, ExifAttribute.createULong(this.mThumbnailLength, this.mExifByteOrder));
    } 
    for (i = 0; i < EXIF_TAGS.length; i++) {
      Iterator<Map.Entry> iterator = this.mAttributes[i].entrySet().iterator();
      j = 0;
      while (iterator.hasNext()) {
        int m = ((ExifAttribute)((Map.Entry)iterator.next()).getValue()).size();
        if (m > 4)
          j += m; 
      } 
      arrayOfInt2[i] = arrayOfInt2[i] + j;
    } 
    j = 0;
    for (i = 8; j < EXIF_TAGS.length; i = m) {
      int m = i;
      if (!this.mAttributes[j].isEmpty()) {
        arrayOfInt1[j] = i;
        m = i + this.mAttributes[j].size() * 12 + 2 + 4 + arrayOfInt2[j];
      } 
      j++;
    } 
    j = i;
    if (this.mHasThumbnail) {
      this.mAttributes[4].put(JPEG_INTERCHANGE_FORMAT_TAG.name, ExifAttribute.createULong(i, this.mExifByteOrder));
      this.mThumbnailOffset = paramInt + i;
      j = i + this.mThumbnailLength;
    } 
    int k = j + 8;
    if (!this.mAttributes[1].isEmpty())
      this.mAttributes[0].put((EXIF_POINTER_TAGS[1]).name, ExifAttribute.createULong(arrayOfInt1[1], this.mExifByteOrder)); 
    if (!this.mAttributes[2].isEmpty())
      this.mAttributes[0].put((EXIF_POINTER_TAGS[2]).name, ExifAttribute.createULong(arrayOfInt1[2], this.mExifByteOrder)); 
    if (!this.mAttributes[3].isEmpty())
      this.mAttributes[1].put((EXIF_POINTER_TAGS[3]).name, ExifAttribute.createULong(arrayOfInt1[3], this.mExifByteOrder)); 
    paramByteOrderedDataOutputStream.writeUnsignedShort(k);
    paramByteOrderedDataOutputStream.write(IDENTIFIER_EXIF_APP1);
    if (this.mExifByteOrder == ByteOrder.BIG_ENDIAN) {
      c = '䵍';
    } else {
      c = '䥉';
    } 
    paramByteOrderedDataOutputStream.writeShort(c);
    paramByteOrderedDataOutputStream.setByteOrder(this.mExifByteOrder);
    paramByteOrderedDataOutputStream.writeUnsignedShort(42);
    paramByteOrderedDataOutputStream.writeUnsignedInt(8L);
    for (paramInt = 0; paramInt < EXIF_TAGS.length; paramInt++) {
      if (!this.mAttributes[paramInt].isEmpty()) {
        paramByteOrderedDataOutputStream.writeUnsignedShort(this.mAttributes[paramInt].size());
        i = arrayOfInt1[paramInt] + 2 + this.mAttributes[paramInt].size() * 12 + 4;
        for (Map.Entry<String, ExifAttribute> entry : this.mAttributes[paramInt].entrySet()) {
          int m = ((ExifTag)sExifTagMapsForWriting[paramInt].get(entry.getKey())).number;
          ExifAttribute exifAttribute = (ExifAttribute)entry.getValue();
          j = exifAttribute.size();
          paramByteOrderedDataOutputStream.writeUnsignedShort(m);
          paramByteOrderedDataOutputStream.writeUnsignedShort(exifAttribute.format);
          paramByteOrderedDataOutputStream.writeInt(exifAttribute.numberOfComponents);
          if (j > 4) {
            paramByteOrderedDataOutputStream.writeUnsignedInt(i);
            i += j;
            continue;
          } 
          paramByteOrderedDataOutputStream.write(exifAttribute.bytes);
          if (j < 4)
            while (j < 4) {
              paramByteOrderedDataOutputStream.writeByte(0);
              j++;
            }  
        } 
        if (paramInt == 0 && !this.mAttributes[4].isEmpty()) {
          paramByteOrderedDataOutputStream.writeUnsignedInt(arrayOfInt1[4]);
        } else {
          paramByteOrderedDataOutputStream.writeUnsignedInt(0L);
        } 
        Iterator<Map.Entry> iterator = this.mAttributes[paramInt].entrySet().iterator();
        while (iterator.hasNext()) {
          ExifAttribute exifAttribute = (ExifAttribute)((Map.Entry)iterator.next()).getValue();
          if (exifAttribute.bytes.length > 4)
            paramByteOrderedDataOutputStream.write(exifAttribute.bytes, 0, exifAttribute.bytes.length); 
        } 
      } 
    } 
    if (this.mHasThumbnail)
      paramByteOrderedDataOutputStream.write(getThumbnailBytes()); 
    paramByteOrderedDataOutputStream.setByteOrder(ByteOrder.BIG_ENDIAN);
    return k;
  }
  
  public void flipHorizontally() {
    byte b = 1;
    switch (getAttributeInt("Orientation", 1)) {
      default:
        b = 0;
        break;
      case 8:
        b = 7;
        break;
      case 7:
        b = 8;
        break;
      case 6:
        b = 5;
        break;
      case 5:
        b = 6;
        break;
      case 4:
        b = 3;
        break;
      case 3:
        b = 4;
        break;
      case 1:
        b = 2;
        break;
      case 2:
        break;
    } 
    setAttribute("Orientation", Integer.toString(b));
  }
  
  public void flipVertically() {
    byte b = 1;
    switch (getAttributeInt("Orientation", 1)) {
      default:
        b = 0;
        break;
      case 8:
        b = 5;
        break;
      case 7:
        b = 6;
        break;
      case 6:
        b = 7;
        break;
      case 5:
        b = 8;
        break;
      case 3:
        b = 2;
        break;
      case 2:
        b = 3;
        break;
      case 1:
        b = 4;
        break;
      case 4:
        break;
    } 
    setAttribute("Orientation", Integer.toString(b));
  }
  
  public double getAltitude(double paramDouble) {
    double d = getAttributeDouble("GPSAltitude", -1.0D);
    int i = getAttributeInt("GPSAltitudeRef", -1);
    if (d >= 0.0D && i >= 0) {
      byte b = 1;
      if (i == 1)
        b = -1; 
      paramDouble = b;
      Double.isNaN(paramDouble);
      return d * paramDouble;
    } 
    return paramDouble;
  }
  
  @Nullable
  public String getAttribute(@NonNull String paramString) {
    ExifAttribute exifAttribute = getExifAttribute(paramString);
    if (exifAttribute != null) {
      StringBuilder stringBuilder;
      if (!sTagSetForCompatibility.contains(paramString))
        return exifAttribute.getStringValue(this.mExifByteOrder); 
      if (paramString.equals("GPSTimeStamp")) {
        if (exifAttribute.format != 5 && exifAttribute.format != 10) {
          StringBuilder stringBuilder1 = new StringBuilder();
          stringBuilder1.append("GPS Timestamp format is not rational. format=");
          stringBuilder1.append(exifAttribute.format);
          Log.w("ExifInterface", stringBuilder1.toString());
          return null;
        } 
        Rational[] arrayOfRational = (Rational[])exifAttribute.getValue(this.mExifByteOrder);
        if (arrayOfRational == null || arrayOfRational.length != 3) {
          stringBuilder = new StringBuilder();
          stringBuilder.append("Invalid GPS Timestamp array. array=");
          stringBuilder.append(Arrays.toString((Object[])arrayOfRational));
          Log.w("ExifInterface", stringBuilder.toString());
          return null;
        } 
        return String.format("%02d:%02d:%02d", new Object[] { Integer.valueOf((int)((float)(arrayOfRational[0]).numerator / (float)(arrayOfRational[0]).denominator)), Integer.valueOf((int)((float)(arrayOfRational[1]).numerator / (float)(arrayOfRational[1]).denominator)), Integer.valueOf((int)((float)(arrayOfRational[2]).numerator / (float)(arrayOfRational[2]).denominator)) });
      } 
      try {
        return Double.toString(stringBuilder.getDoubleValue(this.mExifByteOrder));
      } catch (NumberFormatException numberFormatException) {
        return null;
      } 
    } 
    return null;
  }
  
  public double getAttributeDouble(@NonNull String paramString, double paramDouble) {
    ExifAttribute exifAttribute = getExifAttribute(paramString);
    if (exifAttribute == null)
      return paramDouble; 
    try {
      return exifAttribute.getDoubleValue(this.mExifByteOrder);
    } catch (NumberFormatException numberFormatException) {
      return paramDouble;
    } 
  }
  
  public int getAttributeInt(@NonNull String paramString, int paramInt) {
    ExifAttribute exifAttribute = getExifAttribute(paramString);
    if (exifAttribute == null)
      return paramInt; 
    try {
      return exifAttribute.getIntValue(this.mExifByteOrder);
    } catch (NumberFormatException numberFormatException) {
      return paramInt;
    } 
  }
  
  @RestrictTo({RestrictTo.Scope.LIBRARY})
  public long getDateTime() {
    String str = getAttribute("DateTime");
    if (str != null) {
      if (!sNonZeroTimePattern.matcher(str).matches())
        return -1L; 
      ParsePosition parsePosition = new ParsePosition(0);
      try {
        Date date = sFormatter.parse(str, parsePosition);
        if (date == null)
          return -1L; 
        long l2 = date.getTime();
        String str1 = getAttribute("SubSecTime");
        long l1 = l2;
        if (str1 != null)
          try {
            for (l1 = Long.parseLong(str1); l1 > 1000L; l1 /= 10L);
            return l2 + l1;
          } catch (NumberFormatException numberFormatException) {
            return l2;
          }  
        return l1;
      } catch (IllegalArgumentException illegalArgumentException) {
        return -1L;
      } 
    } 
    return -1L;
  }
  
  @RestrictTo({RestrictTo.Scope.LIBRARY})
  public long getGpsDateTime() {
    String str1 = getAttribute("GPSDateStamp");
    String str2 = getAttribute("GPSTimeStamp");
    if (str1 != null && str2 != null) {
      if (!sNonZeroTimePattern.matcher(str1).matches() && !sNonZeroTimePattern.matcher(str2).matches())
        return -1L; 
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append(str1);
      stringBuilder.append(' ');
      stringBuilder.append(str2);
      str1 = stringBuilder.toString();
      ParsePosition parsePosition = new ParsePosition(0);
      try {
        Date date = sFormatter.parse(str1, parsePosition);
        return (date == null) ? -1L : date.getTime();
      } catch (IllegalArgumentException illegalArgumentException) {
        return -1L;
      } 
    } 
    return -1L;
  }
  
  @Deprecated
  public boolean getLatLong(float[] paramArrayOffloat) {
    double[] arrayOfDouble = getLatLong();
    if (arrayOfDouble == null)
      return false; 
    paramArrayOffloat[0] = (float)arrayOfDouble[0];
    paramArrayOffloat[1] = (float)arrayOfDouble[1];
    return true;
  }
  
  @Nullable
  public double[] getLatLong() {
    String str1 = getAttribute("GPSLatitude");
    String str2 = getAttribute("GPSLatitudeRef");
    String str3 = getAttribute("GPSLongitude");
    String str4 = getAttribute("GPSLongitudeRef");
    if (str1 != null && str2 != null && str3 != null && str4 != null)
      try {
        double d1 = convertRationalLatLonToDouble(str1, str2);
        double d2 = convertRationalLatLonToDouble(str3, str4);
        return new double[] { d1, d2 };
      } catch (IllegalArgumentException illegalArgumentException) {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("Latitude/longitude values are not parseable. ");
        stringBuilder.append(String.format("latValue=%s, latRef=%s, lngValue=%s, lngRef=%s", new Object[] { str1, str2, str3, str4 }));
        Log.w("ExifInterface", stringBuilder.toString());
      }  
    return null;
  }
  
  public int getRotationDegrees() {
    switch (getAttributeInt("Orientation", 1)) {
      default:
        return 0;
      case 6:
      case 7:
        return 90;
      case 5:
      case 8:
        return 270;
      case 3:
      case 4:
        break;
    } 
    return 180;
  }
  
  @Nullable
  public byte[] getThumbnail() {
    return (this.mThumbnailCompression == 6 || this.mThumbnailCompression == 7) ? getThumbnailBytes() : null;
  }
  
  @Nullable
  public Bitmap getThumbnailBitmap() {
    if (!this.mHasThumbnail)
      return null; 
    if (this.mThumbnailBytes == null)
      this.mThumbnailBytes = getThumbnailBytes(); 
    if (this.mThumbnailCompression == 6 || this.mThumbnailCompression == 7)
      return BitmapFactory.decodeByteArray(this.mThumbnailBytes, 0, this.mThumbnailLength); 
    if (this.mThumbnailCompression == 1) {
      int[] arrayOfInt = new int[this.mThumbnailBytes.length / 3];
      int i;
      for (i = 0; i < arrayOfInt.length; i++) {
        byte[] arrayOfByte = this.mThumbnailBytes;
        int j = i * 3;
        arrayOfInt[i] = (arrayOfByte[j] << 16) + 0 + (this.mThumbnailBytes[j + 1] << 8) + this.mThumbnailBytes[j + 2];
      } 
      ExifAttribute exifAttribute1 = this.mAttributes[4].get("ImageLength");
      ExifAttribute exifAttribute2 = this.mAttributes[4].get("ImageWidth");
      if (exifAttribute1 != null && exifAttribute2 != null) {
        i = exifAttribute1.getIntValue(this.mExifByteOrder);
        return Bitmap.createBitmap(arrayOfInt, exifAttribute2.getIntValue(this.mExifByteOrder), i, Bitmap.Config.ARGB_8888);
      } 
    } 
    return null;
  }
  
  @Nullable
  public byte[] getThumbnailBytes() {
    // Byte code:
    //   0: aload_0
    //   1: getfield mHasThumbnail : Z
    //   4: ifne -> 9
    //   7: aconst_null
    //   8: areturn
    //   9: aload_0
    //   10: getfield mThumbnailBytes : [B
    //   13: ifnull -> 21
    //   16: aload_0
    //   17: getfield mThumbnailBytes : [B
    //   20: areturn
    //   21: aload_0
    //   22: getfield mAssetInputStream : Landroid/content/res/AssetManager$AssetInputStream;
    //   25: ifnull -> 79
    //   28: aload_0
    //   29: getfield mAssetInputStream : Landroid/content/res/AssetManager$AssetInputStream;
    //   32: astore_1
    //   33: aload_1
    //   34: astore_3
    //   35: aload_1
    //   36: astore_2
    //   37: aload_1
    //   38: invokevirtual markSupported : ()Z
    //   41: ifeq -> 55
    //   44: aload_1
    //   45: astore_3
    //   46: aload_1
    //   47: astore_2
    //   48: aload_1
    //   49: invokevirtual reset : ()V
    //   52: goto -> 103
    //   55: aload_1
    //   56: astore_3
    //   57: aload_1
    //   58: astore_2
    //   59: ldc_w 'ExifInterface'
    //   62: ldc_w 'Cannot read thumbnail from inputstream without mark/reset support'
    //   65: invokestatic d : (Ljava/lang/String;Ljava/lang/String;)I
    //   68: pop
    //   69: aload_1
    //   70: invokestatic closeQuietly : (Ljava/io/Closeable;)V
    //   73: aconst_null
    //   74: areturn
    //   75: astore_1
    //   76: goto -> 226
    //   79: aload_0
    //   80: getfield mFilename : Ljava/lang/String;
    //   83: ifnull -> 101
    //   86: new java/io/FileInputStream
    //   89: dup
    //   90: aload_0
    //   91: getfield mFilename : Ljava/lang/String;
    //   94: invokespecial <init> : (Ljava/lang/String;)V
    //   97: astore_1
    //   98: goto -> 103
    //   101: aconst_null
    //   102: astore_1
    //   103: aload_1
    //   104: ifnull -> 205
    //   107: aload_1
    //   108: astore_3
    //   109: aload_1
    //   110: astore_2
    //   111: aload_1
    //   112: aload_0
    //   113: getfield mThumbnailOffset : I
    //   116: i2l
    //   117: invokevirtual skip : (J)J
    //   120: aload_0
    //   121: getfield mThumbnailOffset : I
    //   124: i2l
    //   125: lcmp
    //   126: ifne -> 190
    //   129: aload_1
    //   130: astore_3
    //   131: aload_1
    //   132: astore_2
    //   133: aload_0
    //   134: getfield mThumbnailLength : I
    //   137: newarray byte
    //   139: astore #4
    //   141: aload_1
    //   142: astore_3
    //   143: aload_1
    //   144: astore_2
    //   145: aload_1
    //   146: aload #4
    //   148: invokevirtual read : ([B)I
    //   151: aload_0
    //   152: getfield mThumbnailLength : I
    //   155: if_icmpne -> 175
    //   158: aload_1
    //   159: astore_3
    //   160: aload_1
    //   161: astore_2
    //   162: aload_0
    //   163: aload #4
    //   165: putfield mThumbnailBytes : [B
    //   168: aload_1
    //   169: invokestatic closeQuietly : (Ljava/io/Closeable;)V
    //   172: aload #4
    //   174: areturn
    //   175: aload_1
    //   176: astore_3
    //   177: aload_1
    //   178: astore_2
    //   179: new java/io/IOException
    //   182: dup
    //   183: ldc_w 'Corrupted image'
    //   186: invokespecial <init> : (Ljava/lang/String;)V
    //   189: athrow
    //   190: aload_1
    //   191: astore_3
    //   192: aload_1
    //   193: astore_2
    //   194: new java/io/IOException
    //   197: dup
    //   198: ldc_w 'Corrupted image'
    //   201: invokespecial <init> : (Ljava/lang/String;)V
    //   204: athrow
    //   205: aload_1
    //   206: astore_3
    //   207: aload_1
    //   208: astore_2
    //   209: new java/io/FileNotFoundException
    //   212: dup
    //   213: invokespecial <init> : ()V
    //   216: athrow
    //   217: astore_1
    //   218: aconst_null
    //   219: astore_2
    //   220: goto -> 246
    //   223: astore_1
    //   224: aconst_null
    //   225: astore_3
    //   226: aload_3
    //   227: astore_2
    //   228: ldc_w 'ExifInterface'
    //   231: ldc_w 'Encountered exception while getting thumbnail'
    //   234: aload_1
    //   235: invokestatic d : (Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I
    //   238: pop
    //   239: aload_3
    //   240: invokestatic closeQuietly : (Ljava/io/Closeable;)V
    //   243: aconst_null
    //   244: areturn
    //   245: astore_1
    //   246: aload_2
    //   247: invokestatic closeQuietly : (Ljava/io/Closeable;)V
    //   250: aload_1
    //   251: athrow
    // Exception table:
    //   from	to	target	type
    //   21	33	223	java/io/IOException
    //   21	33	217	finally
    //   37	44	75	java/io/IOException
    //   37	44	245	finally
    //   48	52	75	java/io/IOException
    //   48	52	245	finally
    //   59	69	75	java/io/IOException
    //   59	69	245	finally
    //   79	98	223	java/io/IOException
    //   79	98	217	finally
    //   111	129	75	java/io/IOException
    //   111	129	245	finally
    //   133	141	75	java/io/IOException
    //   133	141	245	finally
    //   145	158	75	java/io/IOException
    //   145	158	245	finally
    //   162	168	75	java/io/IOException
    //   162	168	245	finally
    //   179	190	75	java/io/IOException
    //   179	190	245	finally
    //   194	205	75	java/io/IOException
    //   194	205	245	finally
    //   209	217	75	java/io/IOException
    //   209	217	245	finally
    //   228	239	245	finally
  }
  
  @Nullable
  public long[] getThumbnailRange() {
    return !this.mHasThumbnail ? null : new long[] { this.mThumbnailOffset, this.mThumbnailLength };
  }
  
  public boolean hasThumbnail() {
    return this.mHasThumbnail;
  }
  
  public boolean isFlipped() {
    int i = getAttributeInt("Orientation", 1);
    if (i != 2 && i != 7)
      switch (i) {
        default:
          return false;
        case 4:
        case 5:
          break;
      }  
    return true;
  }
  
  public boolean isThumbnailCompressed() {
    return (this.mThumbnailCompression == 6 || this.mThumbnailCompression == 7);
  }
  
  public void resetOrientation() {
    setAttribute("Orientation", Integer.toString(1));
  }
  
  public void rotate(int paramInt) {
    if (paramInt % 90 == 0) {
      int k = getAttributeInt("Orientation", 1);
      boolean bool1 = ROTATION_ORDER.contains(Integer.valueOf(k));
      int j = 0;
      boolean bool = false;
      int i = 0;
      if (bool1) {
        j = (ROTATION_ORDER.indexOf(Integer.valueOf(k)) + paramInt / 90) % 4;
        paramInt = i;
        if (j < 0)
          paramInt = 4; 
        i = ((Integer)ROTATION_ORDER.get(j + paramInt)).intValue();
      } else {
        i = bool;
        if (FLIPPED_ROTATION_ORDER.contains(Integer.valueOf(k))) {
          i = (FLIPPED_ROTATION_ORDER.indexOf(Integer.valueOf(k)) + paramInt / 90) % 4;
          paramInt = j;
          if (i < 0)
            paramInt = 4; 
          i = ((Integer)FLIPPED_ROTATION_ORDER.get(i + paramInt)).intValue();
        } 
      } 
      setAttribute("Orientation", Integer.toString(i));
      return;
    } 
    throw new IllegalArgumentException("degree should be a multiple of 90");
  }
  
  public void saveAttributes() throws IOException {
    if (this.mIsSupportedFile && this.mMimeType == 4) {
      if (this.mFilename != null) {
        this.mThumbnailBytes = getThumbnail();
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append(this.mFilename);
        stringBuilder.append(".tmp");
        File file = new File(stringBuilder.toString());
        if ((new File(this.mFilename)).renameTo(file)) {
          Closeable closeable;
          FileOutputStream fileOutputStream = null;
          try {
            closeable = new FileInputStream(file);
          } finally {
            stringBuilder = null;
          } 
          closeQuietly(closeable);
          closeQuietly(fileOutputStream);
          file.delete();
          throw stringBuilder;
        } 
        stringBuilder = new StringBuilder();
        stringBuilder.append("Could not rename to ");
        stringBuilder.append(file.getAbsolutePath());
        throw new IOException(stringBuilder.toString());
      } 
      throw new IOException("ExifInterface does not support saving attributes for the current input.");
    } 
    throw new IOException("ExifInterface only supports saving attributes on JPEG formats.");
  }
  
  public void setAltitude(double paramDouble) {
    String str;
    if (paramDouble >= 0.0D) {
      str = "0";
    } else {
      str = "1";
    } 
    setAttribute("GPSAltitude", (new Rational(Math.abs(paramDouble))).toString());
    setAttribute("GPSAltitudeRef", str);
  }
  
  public void setAttribute(@NonNull String paramString1, @Nullable String paramString2) {
    // Byte code:
    //   0: aload_2
    //   1: astore #6
    //   3: ldc_w 'ISOSpeedRatings'
    //   6: aload_1
    //   7: invokevirtual equals : (Ljava/lang/Object;)Z
    //   10: ifeq -> 21
    //   13: ldc_w 'PhotographicSensitivity'
    //   16: astore #5
    //   18: goto -> 24
    //   21: aload_1
    //   22: astore #5
    //   24: aload #6
    //   26: astore_1
    //   27: aload #6
    //   29: ifnull -> 271
    //   32: aload #6
    //   34: astore_1
    //   35: getstatic android/support/media/ExifInterface.sTagSetForCompatibility : Ljava/util/HashSet;
    //   38: aload #5
    //   40: invokevirtual contains : (Ljava/lang/Object;)Z
    //   43: ifeq -> 271
    //   46: aload #5
    //   48: ldc_w 'GPSTimeStamp'
    //   51: invokevirtual equals : (Ljava/lang/Object;)Z
    //   54: ifeq -> 202
    //   57: getstatic android/support/media/ExifInterface.sGpsTimestampPattern : Ljava/util/regex/Pattern;
    //   60: aload #6
    //   62: invokevirtual matcher : (Ljava/lang/CharSequence;)Ljava/util/regex/Matcher;
    //   65: astore_1
    //   66: aload_1
    //   67: invokevirtual find : ()Z
    //   70: ifne -> 123
    //   73: new java/lang/StringBuilder
    //   76: dup
    //   77: invokespecial <init> : ()V
    //   80: astore_1
    //   81: aload_1
    //   82: ldc_w 'Invalid value for '
    //   85: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   88: pop
    //   89: aload_1
    //   90: aload #5
    //   92: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   95: pop
    //   96: aload_1
    //   97: ldc_w ' : '
    //   100: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   103: pop
    //   104: aload_1
    //   105: aload #6
    //   107: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   110: pop
    //   111: ldc_w 'ExifInterface'
    //   114: aload_1
    //   115: invokevirtual toString : ()Ljava/lang/String;
    //   118: invokestatic w : (Ljava/lang/String;Ljava/lang/String;)I
    //   121: pop
    //   122: return
    //   123: new java/lang/StringBuilder
    //   126: dup
    //   127: invokespecial <init> : ()V
    //   130: astore_2
    //   131: aload_2
    //   132: aload_1
    //   133: iconst_1
    //   134: invokevirtual group : (I)Ljava/lang/String;
    //   137: invokestatic parseInt : (Ljava/lang/String;)I
    //   140: invokevirtual append : (I)Ljava/lang/StringBuilder;
    //   143: pop
    //   144: aload_2
    //   145: ldc_w '/1,'
    //   148: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   151: pop
    //   152: aload_2
    //   153: aload_1
    //   154: iconst_2
    //   155: invokevirtual group : (I)Ljava/lang/String;
    //   158: invokestatic parseInt : (Ljava/lang/String;)I
    //   161: invokevirtual append : (I)Ljava/lang/StringBuilder;
    //   164: pop
    //   165: aload_2
    //   166: ldc_w '/1,'
    //   169: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   172: pop
    //   173: aload_2
    //   174: aload_1
    //   175: iconst_3
    //   176: invokevirtual group : (I)Ljava/lang/String;
    //   179: invokestatic parseInt : (Ljava/lang/String;)I
    //   182: invokevirtual append : (I)Ljava/lang/StringBuilder;
    //   185: pop
    //   186: aload_2
    //   187: ldc_w '/1'
    //   190: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   193: pop
    //   194: aload_2
    //   195: invokevirtual toString : ()Ljava/lang/String;
    //   198: astore_1
    //   199: goto -> 271
    //   202: new android/support/media/ExifInterface$Rational
    //   205: dup
    //   206: aload_2
    //   207: invokestatic parseDouble : (Ljava/lang/String;)D
    //   210: aconst_null
    //   211: invokespecial <init> : (DLandroid/support/media/ExifInterface$1;)V
    //   214: invokevirtual toString : ()Ljava/lang/String;
    //   217: astore_1
    //   218: goto -> 271
    //   221: new java/lang/StringBuilder
    //   224: dup
    //   225: invokespecial <init> : ()V
    //   228: astore_1
    //   229: aload_1
    //   230: ldc_w 'Invalid value for '
    //   233: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   236: pop
    //   237: aload_1
    //   238: aload #5
    //   240: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   243: pop
    //   244: aload_1
    //   245: ldc_w ' : '
    //   248: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   251: pop
    //   252: aload_1
    //   253: aload #6
    //   255: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   258: pop
    //   259: ldc_w 'ExifInterface'
    //   262: aload_1
    //   263: invokevirtual toString : ()Ljava/lang/String;
    //   266: invokestatic w : (Ljava/lang/String;Ljava/lang/String;)I
    //   269: pop
    //   270: return
    //   271: iconst_0
    //   272: istore #4
    //   274: iload #4
    //   276: getstatic android/support/media/ExifInterface.EXIF_TAGS : [[Landroid/support/media/ExifInterface$ExifTag;
    //   279: arraylength
    //   280: if_icmpge -> 1306
    //   283: iload #4
    //   285: iconst_4
    //   286: if_icmpne -> 299
    //   289: aload_0
    //   290: getfield mHasThumbnail : Z
    //   293: ifne -> 299
    //   296: goto -> 1297
    //   299: getstatic android/support/media/ExifInterface.sExifTagMapsForWriting : [Ljava/util/HashMap;
    //   302: iload #4
    //   304: aaload
    //   305: aload #5
    //   307: invokevirtual get : (Ljava/lang/Object;)Ljava/lang/Object;
    //   310: checkcast android/support/media/ExifInterface$ExifTag
    //   313: astore_2
    //   314: aload_2
    //   315: ifnull -> 1297
    //   318: aload_1
    //   319: ifnonnull -> 338
    //   322: aload_0
    //   323: getfield mAttributes : [Ljava/util/HashMap;
    //   326: iload #4
    //   328: aaload
    //   329: aload #5
    //   331: invokevirtual remove : (Ljava/lang/Object;)Ljava/lang/Object;
    //   334: pop
    //   335: goto -> 1297
    //   338: aload_1
    //   339: invokestatic guessDataFormat : (Ljava/lang/String;)Landroid/util/Pair;
    //   342: astore #7
    //   344: aload_2
    //   345: getfield primaryFormat : I
    //   348: aload #7
    //   350: getfield first : Ljava/lang/Object;
    //   353: checkcast java/lang/Integer
    //   356: invokevirtual intValue : ()I
    //   359: if_icmpeq -> 713
    //   362: aload_2
    //   363: getfield primaryFormat : I
    //   366: aload #7
    //   368: getfield second : Ljava/lang/Object;
    //   371: checkcast java/lang/Integer
    //   374: invokevirtual intValue : ()I
    //   377: if_icmpne -> 383
    //   380: goto -> 713
    //   383: aload_2
    //   384: getfield secondaryFormat : I
    //   387: iconst_m1
    //   388: if_icmpeq -> 435
    //   391: aload_2
    //   392: getfield secondaryFormat : I
    //   395: aload #7
    //   397: getfield first : Ljava/lang/Object;
    //   400: checkcast java/lang/Integer
    //   403: invokevirtual intValue : ()I
    //   406: if_icmpeq -> 427
    //   409: aload_2
    //   410: getfield secondaryFormat : I
    //   413: aload #7
    //   415: getfield second : Ljava/lang/Object;
    //   418: checkcast java/lang/Integer
    //   421: invokevirtual intValue : ()I
    //   424: if_icmpne -> 435
    //   427: aload_2
    //   428: getfield secondaryFormat : I
    //   431: istore_3
    //   432: goto -> 718
    //   435: aload_2
    //   436: getfield primaryFormat : I
    //   439: iconst_1
    //   440: if_icmpeq -> 705
    //   443: aload_2
    //   444: getfield primaryFormat : I
    //   447: bipush #7
    //   449: if_icmpeq -> 705
    //   452: aload_2
    //   453: getfield primaryFormat : I
    //   456: iconst_2
    //   457: if_icmpne -> 463
    //   460: goto -> 705
    //   463: new java/lang/StringBuilder
    //   466: dup
    //   467: invokespecial <init> : ()V
    //   470: astore #6
    //   472: aload #6
    //   474: ldc_w 'Given tag ('
    //   477: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   480: pop
    //   481: aload #6
    //   483: aload #5
    //   485: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   488: pop
    //   489: aload #6
    //   491: ldc_w ') value didn't match with one of expected '
    //   494: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   497: pop
    //   498: aload #6
    //   500: ldc_w 'formats: '
    //   503: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   506: pop
    //   507: aload #6
    //   509: getstatic android/support/media/ExifInterface.IFD_FORMAT_NAMES : [Ljava/lang/String;
    //   512: aload_2
    //   513: getfield primaryFormat : I
    //   516: aaload
    //   517: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   520: pop
    //   521: aload_2
    //   522: getfield secondaryFormat : I
    //   525: iconst_m1
    //   526: if_icmpne -> 536
    //   529: ldc_w ''
    //   532: astore_2
    //   533: goto -> 574
    //   536: new java/lang/StringBuilder
    //   539: dup
    //   540: invokespecial <init> : ()V
    //   543: astore #8
    //   545: aload #8
    //   547: ldc_w ', '
    //   550: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   553: pop
    //   554: aload #8
    //   556: getstatic android/support/media/ExifInterface.IFD_FORMAT_NAMES : [Ljava/lang/String;
    //   559: aload_2
    //   560: getfield secondaryFormat : I
    //   563: aaload
    //   564: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   567: pop
    //   568: aload #8
    //   570: invokevirtual toString : ()Ljava/lang/String;
    //   573: astore_2
    //   574: aload #6
    //   576: aload_2
    //   577: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   580: pop
    //   581: aload #6
    //   583: ldc_w ' (guess: '
    //   586: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   589: pop
    //   590: aload #6
    //   592: getstatic android/support/media/ExifInterface.IFD_FORMAT_NAMES : [Ljava/lang/String;
    //   595: aload #7
    //   597: getfield first : Ljava/lang/Object;
    //   600: checkcast java/lang/Integer
    //   603: invokevirtual intValue : ()I
    //   606: aaload
    //   607: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   610: pop
    //   611: aload #7
    //   613: getfield second : Ljava/lang/Object;
    //   616: checkcast java/lang/Integer
    //   619: invokevirtual intValue : ()I
    //   622: iconst_m1
    //   623: if_icmpne -> 633
    //   626: ldc_w ''
    //   629: astore_2
    //   630: goto -> 674
    //   633: new java/lang/StringBuilder
    //   636: dup
    //   637: invokespecial <init> : ()V
    //   640: astore_2
    //   641: aload_2
    //   642: ldc_w ', '
    //   645: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   648: pop
    //   649: aload_2
    //   650: getstatic android/support/media/ExifInterface.IFD_FORMAT_NAMES : [Ljava/lang/String;
    //   653: aload #7
    //   655: getfield second : Ljava/lang/Object;
    //   658: checkcast java/lang/Integer
    //   661: invokevirtual intValue : ()I
    //   664: aaload
    //   665: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   668: pop
    //   669: aload_2
    //   670: invokevirtual toString : ()Ljava/lang/String;
    //   673: astore_2
    //   674: aload #6
    //   676: aload_2
    //   677: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   680: pop
    //   681: aload #6
    //   683: ldc_w ')'
    //   686: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   689: pop
    //   690: ldc_w 'ExifInterface'
    //   693: aload #6
    //   695: invokevirtual toString : ()Ljava/lang/String;
    //   698: invokestatic w : (Ljava/lang/String;Ljava/lang/String;)I
    //   701: pop
    //   702: goto -> 1297
    //   705: aload_2
    //   706: getfield primaryFormat : I
    //   709: istore_3
    //   710: goto -> 718
    //   713: aload_2
    //   714: getfield primaryFormat : I
    //   717: istore_3
    //   718: iload_3
    //   719: tableswitch default -> 780, 1 -> 1280, 2 -> 1260, 3 -> 1196, 4 -> 1132, 5 -> 1038, 6 -> 780, 7 -> 1260, 8 -> 780, 9 -> 974, 10 -> 880, 11 -> 780, 12 -> 816
    //   780: new java/lang/StringBuilder
    //   783: dup
    //   784: invokespecial <init> : ()V
    //   787: astore_2
    //   788: aload_2
    //   789: ldc_w 'Data format isn't one of expected formats: '
    //   792: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   795: pop
    //   796: aload_2
    //   797: iload_3
    //   798: invokevirtual append : (I)Ljava/lang/StringBuilder;
    //   801: pop
    //   802: ldc_w 'ExifInterface'
    //   805: aload_2
    //   806: invokevirtual toString : ()Ljava/lang/String;
    //   809: invokestatic w : (Ljava/lang/String;Ljava/lang/String;)I
    //   812: pop
    //   813: goto -> 1297
    //   816: aload_1
    //   817: ldc_w ','
    //   820: invokevirtual split : (Ljava/lang/String;)[Ljava/lang/String;
    //   823: astore_2
    //   824: aload_2
    //   825: arraylength
    //   826: newarray double
    //   828: astore #6
    //   830: iconst_0
    //   831: istore_3
    //   832: iload_3
    //   833: aload_2
    //   834: arraylength
    //   835: if_icmpge -> 855
    //   838: aload #6
    //   840: iload_3
    //   841: aload_2
    //   842: iload_3
    //   843: aaload
    //   844: invokestatic parseDouble : (Ljava/lang/String;)D
    //   847: dastore
    //   848: iload_3
    //   849: iconst_1
    //   850: iadd
    //   851: istore_3
    //   852: goto -> 832
    //   855: aload_0
    //   856: getfield mAttributes : [Ljava/util/HashMap;
    //   859: iload #4
    //   861: aaload
    //   862: aload #5
    //   864: aload #6
    //   866: aload_0
    //   867: getfield mExifByteOrder : Ljava/nio/ByteOrder;
    //   870: invokestatic createDouble : ([DLjava/nio/ByteOrder;)Landroid/support/media/ExifInterface$ExifAttribute;
    //   873: invokevirtual put : (Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    //   876: pop
    //   877: goto -> 1297
    //   880: aload_1
    //   881: ldc_w ','
    //   884: invokevirtual split : (Ljava/lang/String;)[Ljava/lang/String;
    //   887: astore_2
    //   888: aload_2
    //   889: arraylength
    //   890: anewarray android/support/media/ExifInterface$Rational
    //   893: astore #6
    //   895: iconst_0
    //   896: istore_3
    //   897: iload_3
    //   898: aload_2
    //   899: arraylength
    //   900: if_icmpge -> 949
    //   903: aload_2
    //   904: iload_3
    //   905: aaload
    //   906: ldc_w '/'
    //   909: invokevirtual split : (Ljava/lang/String;)[Ljava/lang/String;
    //   912: astore #7
    //   914: aload #6
    //   916: iload_3
    //   917: new android/support/media/ExifInterface$Rational
    //   920: dup
    //   921: aload #7
    //   923: iconst_0
    //   924: aaload
    //   925: invokestatic parseDouble : (Ljava/lang/String;)D
    //   928: d2l
    //   929: aload #7
    //   931: iconst_1
    //   932: aaload
    //   933: invokestatic parseDouble : (Ljava/lang/String;)D
    //   936: d2l
    //   937: aconst_null
    //   938: invokespecial <init> : (JJLandroid/support/media/ExifInterface$1;)V
    //   941: aastore
    //   942: iload_3
    //   943: iconst_1
    //   944: iadd
    //   945: istore_3
    //   946: goto -> 897
    //   949: aload_0
    //   950: getfield mAttributes : [Ljava/util/HashMap;
    //   953: iload #4
    //   955: aaload
    //   956: aload #5
    //   958: aload #6
    //   960: aload_0
    //   961: getfield mExifByteOrder : Ljava/nio/ByteOrder;
    //   964: invokestatic createSRational : ([Landroid/support/media/ExifInterface$Rational;Ljava/nio/ByteOrder;)Landroid/support/media/ExifInterface$ExifAttribute;
    //   967: invokevirtual put : (Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    //   970: pop
    //   971: goto -> 1297
    //   974: aload_1
    //   975: ldc_w ','
    //   978: invokevirtual split : (Ljava/lang/String;)[Ljava/lang/String;
    //   981: astore_2
    //   982: aload_2
    //   983: arraylength
    //   984: newarray int
    //   986: astore #6
    //   988: iconst_0
    //   989: istore_3
    //   990: iload_3
    //   991: aload_2
    //   992: arraylength
    //   993: if_icmpge -> 1013
    //   996: aload #6
    //   998: iload_3
    //   999: aload_2
    //   1000: iload_3
    //   1001: aaload
    //   1002: invokestatic parseInt : (Ljava/lang/String;)I
    //   1005: iastore
    //   1006: iload_3
    //   1007: iconst_1
    //   1008: iadd
    //   1009: istore_3
    //   1010: goto -> 990
    //   1013: aload_0
    //   1014: getfield mAttributes : [Ljava/util/HashMap;
    //   1017: iload #4
    //   1019: aaload
    //   1020: aload #5
    //   1022: aload #6
    //   1024: aload_0
    //   1025: getfield mExifByteOrder : Ljava/nio/ByteOrder;
    //   1028: invokestatic createSLong : ([ILjava/nio/ByteOrder;)Landroid/support/media/ExifInterface$ExifAttribute;
    //   1031: invokevirtual put : (Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    //   1034: pop
    //   1035: goto -> 1297
    //   1038: aload_1
    //   1039: ldc_w ','
    //   1042: invokevirtual split : (Ljava/lang/String;)[Ljava/lang/String;
    //   1045: astore_2
    //   1046: aload_2
    //   1047: arraylength
    //   1048: anewarray android/support/media/ExifInterface$Rational
    //   1051: astore #6
    //   1053: iconst_0
    //   1054: istore_3
    //   1055: iload_3
    //   1056: aload_2
    //   1057: arraylength
    //   1058: if_icmpge -> 1107
    //   1061: aload_2
    //   1062: iload_3
    //   1063: aaload
    //   1064: ldc_w '/'
    //   1067: invokevirtual split : (Ljava/lang/String;)[Ljava/lang/String;
    //   1070: astore #7
    //   1072: aload #6
    //   1074: iload_3
    //   1075: new android/support/media/ExifInterface$Rational
    //   1078: dup
    //   1079: aload #7
    //   1081: iconst_0
    //   1082: aaload
    //   1083: invokestatic parseDouble : (Ljava/lang/String;)D
    //   1086: d2l
    //   1087: aload #7
    //   1089: iconst_1
    //   1090: aaload
    //   1091: invokestatic parseDouble : (Ljava/lang/String;)D
    //   1094: d2l
    //   1095: aconst_null
    //   1096: invokespecial <init> : (JJLandroid/support/media/ExifInterface$1;)V
    //   1099: aastore
    //   1100: iload_3
    //   1101: iconst_1
    //   1102: iadd
    //   1103: istore_3
    //   1104: goto -> 1055
    //   1107: aload_0
    //   1108: getfield mAttributes : [Ljava/util/HashMap;
    //   1111: iload #4
    //   1113: aaload
    //   1114: aload #5
    //   1116: aload #6
    //   1118: aload_0
    //   1119: getfield mExifByteOrder : Ljava/nio/ByteOrder;
    //   1122: invokestatic createURational : ([Landroid/support/media/ExifInterface$Rational;Ljava/nio/ByteOrder;)Landroid/support/media/ExifInterface$ExifAttribute;
    //   1125: invokevirtual put : (Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    //   1128: pop
    //   1129: goto -> 1297
    //   1132: aload_1
    //   1133: ldc_w ','
    //   1136: invokevirtual split : (Ljava/lang/String;)[Ljava/lang/String;
    //   1139: astore_2
    //   1140: aload_2
    //   1141: arraylength
    //   1142: newarray long
    //   1144: astore #6
    //   1146: iconst_0
    //   1147: istore_3
    //   1148: iload_3
    //   1149: aload_2
    //   1150: arraylength
    //   1151: if_icmpge -> 1171
    //   1154: aload #6
    //   1156: iload_3
    //   1157: aload_2
    //   1158: iload_3
    //   1159: aaload
    //   1160: invokestatic parseLong : (Ljava/lang/String;)J
    //   1163: lastore
    //   1164: iload_3
    //   1165: iconst_1
    //   1166: iadd
    //   1167: istore_3
    //   1168: goto -> 1148
    //   1171: aload_0
    //   1172: getfield mAttributes : [Ljava/util/HashMap;
    //   1175: iload #4
    //   1177: aaload
    //   1178: aload #5
    //   1180: aload #6
    //   1182: aload_0
    //   1183: getfield mExifByteOrder : Ljava/nio/ByteOrder;
    //   1186: invokestatic createULong : ([JLjava/nio/ByteOrder;)Landroid/support/media/ExifInterface$ExifAttribute;
    //   1189: invokevirtual put : (Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    //   1192: pop
    //   1193: goto -> 1297
    //   1196: aload_1
    //   1197: ldc_w ','
    //   1200: invokevirtual split : (Ljava/lang/String;)[Ljava/lang/String;
    //   1203: astore_2
    //   1204: aload_2
    //   1205: arraylength
    //   1206: newarray int
    //   1208: astore #6
    //   1210: iconst_0
    //   1211: istore_3
    //   1212: iload_3
    //   1213: aload_2
    //   1214: arraylength
    //   1215: if_icmpge -> 1235
    //   1218: aload #6
    //   1220: iload_3
    //   1221: aload_2
    //   1222: iload_3
    //   1223: aaload
    //   1224: invokestatic parseInt : (Ljava/lang/String;)I
    //   1227: iastore
    //   1228: iload_3
    //   1229: iconst_1
    //   1230: iadd
    //   1231: istore_3
    //   1232: goto -> 1212
    //   1235: aload_0
    //   1236: getfield mAttributes : [Ljava/util/HashMap;
    //   1239: iload #4
    //   1241: aaload
    //   1242: aload #5
    //   1244: aload #6
    //   1246: aload_0
    //   1247: getfield mExifByteOrder : Ljava/nio/ByteOrder;
    //   1250: invokestatic createUShort : ([ILjava/nio/ByteOrder;)Landroid/support/media/ExifInterface$ExifAttribute;
    //   1253: invokevirtual put : (Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    //   1256: pop
    //   1257: goto -> 1297
    //   1260: aload_0
    //   1261: getfield mAttributes : [Ljava/util/HashMap;
    //   1264: iload #4
    //   1266: aaload
    //   1267: aload #5
    //   1269: aload_1
    //   1270: invokestatic createString : (Ljava/lang/String;)Landroid/support/media/ExifInterface$ExifAttribute;
    //   1273: invokevirtual put : (Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    //   1276: pop
    //   1277: goto -> 1297
    //   1280: aload_0
    //   1281: getfield mAttributes : [Ljava/util/HashMap;
    //   1284: iload #4
    //   1286: aaload
    //   1287: aload #5
    //   1289: aload_1
    //   1290: invokestatic createByte : (Ljava/lang/String;)Landroid/support/media/ExifInterface$ExifAttribute;
    //   1293: invokevirtual put : (Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    //   1296: pop
    //   1297: iload #4
    //   1299: iconst_1
    //   1300: iadd
    //   1301: istore #4
    //   1303: goto -> 274
    //   1306: return
    //   1307: astore_1
    //   1308: goto -> 221
    // Exception table:
    //   from	to	target	type
    //   202	218	1307	java/lang/NumberFormatException
  }
  
  @RestrictTo({RestrictTo.Scope.LIBRARY})
  public void setDateTime(long paramLong) {
    setAttribute("DateTime", sFormatter.format(new Date(paramLong)));
    setAttribute("SubSecTime", Long.toString(paramLong % 1000L));
  }
  
  public void setGpsInfo(Location paramLocation) {
    if (paramLocation == null)
      return; 
    setAttribute("GPSProcessingMethod", paramLocation.getProvider());
    setLatLong(paramLocation.getLatitude(), paramLocation.getLongitude());
    setAltitude(paramLocation.getAltitude());
    setAttribute("GPSSpeedRef", "K");
    setAttribute("GPSSpeed", (new Rational((paramLocation.getSpeed() * (float)TimeUnit.HOURS.toSeconds(1L) / 1000.0F))).toString());
    String[] arrayOfString = sFormatter.format(new Date(paramLocation.getTime())).split("\\s+");
    setAttribute("GPSDateStamp", arrayOfString[0]);
    setAttribute("GPSTimeStamp", arrayOfString[1]);
  }
  
  public void setLatLong(double paramDouble1, double paramDouble2) {
    if (paramDouble1 >= -90.0D && paramDouble1 <= 90.0D && !Double.isNaN(paramDouble1)) {
      if (paramDouble2 >= -180.0D && paramDouble2 <= 180.0D && !Double.isNaN(paramDouble2)) {
        String str;
        if (paramDouble1 >= 0.0D) {
          str = "N";
        } else {
          str = "S";
        } 
        setAttribute("GPSLatitudeRef", str);
        setAttribute("GPSLatitude", convertDecimalDegree(Math.abs(paramDouble1)));
        if (paramDouble2 >= 0.0D) {
          str = "E";
        } else {
          str = "W";
        } 
        setAttribute("GPSLongitudeRef", str);
        setAttribute("GPSLongitude", convertDecimalDegree(Math.abs(paramDouble2)));
        return;
      } 
      StringBuilder stringBuilder1 = new StringBuilder();
      stringBuilder1.append("Longitude value ");
      stringBuilder1.append(paramDouble2);
      stringBuilder1.append(" is not valid.");
      throw new IllegalArgumentException(stringBuilder1.toString());
    } 
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("Latitude value ");
    stringBuilder.append(paramDouble1);
    stringBuilder.append(" is not valid.");
    throw new IllegalArgumentException(stringBuilder.toString());
  }
  
  private static class ByteOrderedDataInputStream extends InputStream implements DataInput {
    private static final ByteOrder BIG_ENDIAN = ByteOrder.BIG_ENDIAN;
    
    private static final ByteOrder LITTLE_ENDIAN = ByteOrder.LITTLE_ENDIAN;
    
    private ByteOrder mByteOrder = ByteOrder.BIG_ENDIAN;
    
    private DataInputStream mDataInputStream;
    
    private final int mLength;
    
    private int mPosition;
    
    static {
    
    }
    
    public ByteOrderedDataInputStream(InputStream param1InputStream) throws IOException {
      this.mDataInputStream = new DataInputStream(param1InputStream);
      this.mLength = this.mDataInputStream.available();
      this.mPosition = 0;
      this.mDataInputStream.mark(this.mLength);
    }
    
    public ByteOrderedDataInputStream(byte[] param1ArrayOfbyte) throws IOException {
      this(new ByteArrayInputStream(param1ArrayOfbyte));
    }
    
    public int available() throws IOException {
      return this.mDataInputStream.available();
    }
    
    public int peek() {
      return this.mPosition;
    }
    
    public int read() throws IOException {
      this.mPosition++;
      return this.mDataInputStream.read();
    }
    
    public int read(byte[] param1ArrayOfbyte, int param1Int1, int param1Int2) throws IOException {
      param1Int1 = this.mDataInputStream.read(param1ArrayOfbyte, param1Int1, param1Int2);
      this.mPosition += param1Int1;
      return param1Int1;
    }
    
    public boolean readBoolean() throws IOException {
      this.mPosition++;
      return this.mDataInputStream.readBoolean();
    }
    
    public byte readByte() throws IOException {
      this.mPosition++;
      if (this.mPosition <= this.mLength) {
        int i = this.mDataInputStream.read();
        if (i >= 0)
          return (byte)i; 
        throw new EOFException();
      } 
      throw new EOFException();
    }
    
    public char readChar() throws IOException {
      this.mPosition += 2;
      return this.mDataInputStream.readChar();
    }
    
    public double readDouble() throws IOException {
      return Double.longBitsToDouble(readLong());
    }
    
    public float readFloat() throws IOException {
      return Float.intBitsToFloat(readInt());
    }
    
    public void readFully(byte[] param1ArrayOfbyte) throws IOException {
      this.mPosition += param1ArrayOfbyte.length;
      if (this.mPosition <= this.mLength) {
        if (this.mDataInputStream.read(param1ArrayOfbyte, 0, param1ArrayOfbyte.length) == param1ArrayOfbyte.length)
          return; 
        throw new IOException("Couldn't read up to the length of buffer");
      } 
      throw new EOFException();
    }
    
    public void readFully(byte[] param1ArrayOfbyte, int param1Int1, int param1Int2) throws IOException {
      this.mPosition += param1Int2;
      if (this.mPosition <= this.mLength) {
        if (this.mDataInputStream.read(param1ArrayOfbyte, param1Int1, param1Int2) == param1Int2)
          return; 
        throw new IOException("Couldn't read up to the length of buffer");
      } 
      throw new EOFException();
    }
    
    public int readInt() throws IOException {
      this.mPosition += 4;
      if (this.mPosition <= this.mLength) {
        int i = this.mDataInputStream.read();
        int j = this.mDataInputStream.read();
        int k = this.mDataInputStream.read();
        int m = this.mDataInputStream.read();
        if ((i | j | k | m) >= 0) {
          if (this.mByteOrder == LITTLE_ENDIAN)
            return (m << 24) + (k << 16) + (j << 8) + i; 
          if (this.mByteOrder == BIG_ENDIAN)
            return (i << 24) + (j << 16) + (k << 8) + m; 
          StringBuilder stringBuilder = new StringBuilder();
          stringBuilder.append("Invalid byte order: ");
          stringBuilder.append(this.mByteOrder);
          throw new IOException(stringBuilder.toString());
        } 
        throw new EOFException();
      } 
      throw new EOFException();
    }
    
    public String readLine() throws IOException {
      Log.d("ExifInterface", "Currently unsupported");
      return null;
    }
    
    public long readLong() throws IOException {
      this.mPosition += 8;
      if (this.mPosition <= this.mLength) {
        int i = this.mDataInputStream.read();
        int j = this.mDataInputStream.read();
        int k = this.mDataInputStream.read();
        int m = this.mDataInputStream.read();
        int n = this.mDataInputStream.read();
        int i1 = this.mDataInputStream.read();
        int i2 = this.mDataInputStream.read();
        int i3 = this.mDataInputStream.read();
        if ((i | j | k | m | n | i1 | i2 | i3) >= 0) {
          if (this.mByteOrder == LITTLE_ENDIAN)
            return (i3 << 56L) + (i2 << 48L) + (i1 << 40L) + (n << 32L) + (m << 24L) + (k << 16L) + (j << 8L) + i; 
          if (this.mByteOrder == BIG_ENDIAN)
            return (i << 56L) + (j << 48L) + (k << 40L) + (m << 32L) + (n << 24L) + (i1 << 16L) + (i2 << 8L) + i3; 
          StringBuilder stringBuilder = new StringBuilder();
          stringBuilder.append("Invalid byte order: ");
          stringBuilder.append(this.mByteOrder);
          throw new IOException(stringBuilder.toString());
        } 
        throw new EOFException();
      } 
      throw new EOFException();
    }
    
    public short readShort() throws IOException {
      this.mPosition += 2;
      if (this.mPosition <= this.mLength) {
        int i = this.mDataInputStream.read();
        int j = this.mDataInputStream.read();
        if ((i | j) >= 0) {
          if (this.mByteOrder == LITTLE_ENDIAN)
            return (short)((j << 8) + i); 
          if (this.mByteOrder == BIG_ENDIAN)
            return (short)((i << 8) + j); 
          StringBuilder stringBuilder = new StringBuilder();
          stringBuilder.append("Invalid byte order: ");
          stringBuilder.append(this.mByteOrder);
          throw new IOException(stringBuilder.toString());
        } 
        throw new EOFException();
      } 
      throw new EOFException();
    }
    
    public String readUTF() throws IOException {
      this.mPosition += 2;
      return this.mDataInputStream.readUTF();
    }
    
    public int readUnsignedByte() throws IOException {
      this.mPosition++;
      return this.mDataInputStream.readUnsignedByte();
    }
    
    public long readUnsignedInt() throws IOException {
      return readInt() & 0xFFFFFFFFL;
    }
    
    public int readUnsignedShort() throws IOException {
      this.mPosition += 2;
      if (this.mPosition <= this.mLength) {
        int i = this.mDataInputStream.read();
        int j = this.mDataInputStream.read();
        if ((i | j) >= 0) {
          if (this.mByteOrder == LITTLE_ENDIAN)
            return (j << 8) + i; 
          if (this.mByteOrder == BIG_ENDIAN)
            return (i << 8) + j; 
          StringBuilder stringBuilder = new StringBuilder();
          stringBuilder.append("Invalid byte order: ");
          stringBuilder.append(this.mByteOrder);
          throw new IOException(stringBuilder.toString());
        } 
        throw new EOFException();
      } 
      throw new EOFException();
    }
    
    public void seek(long param1Long) throws IOException {
      if (this.mPosition > param1Long) {
        this.mPosition = 0;
        this.mDataInputStream.reset();
        this.mDataInputStream.mark(this.mLength);
      } else {
        param1Long -= this.mPosition;
      } 
      int i = (int)param1Long;
      if (skipBytes(i) == i)
        return; 
      throw new IOException("Couldn't seek up to the byteCount");
    }
    
    public void setByteOrder(ByteOrder param1ByteOrder) {
      this.mByteOrder = param1ByteOrder;
    }
    
    public int skipBytes(int param1Int) throws IOException {
      int i = Math.min(param1Int, this.mLength - this.mPosition);
      for (param1Int = 0; param1Int < i; param1Int += this.mDataInputStream.skipBytes(i - param1Int));
      this.mPosition += param1Int;
      return param1Int;
    }
  }
  
  private static class ByteOrderedDataOutputStream extends FilterOutputStream {
    private ByteOrder mByteOrder;
    
    private final OutputStream mOutputStream;
    
    public ByteOrderedDataOutputStream(OutputStream param1OutputStream, ByteOrder param1ByteOrder) {
      super(param1OutputStream);
      this.mOutputStream = param1OutputStream;
      this.mByteOrder = param1ByteOrder;
    }
    
    public void setByteOrder(ByteOrder param1ByteOrder) {
      this.mByteOrder = param1ByteOrder;
    }
    
    public void write(byte[] param1ArrayOfbyte) throws IOException {
      this.mOutputStream.write(param1ArrayOfbyte);
    }
    
    public void write(byte[] param1ArrayOfbyte, int param1Int1, int param1Int2) throws IOException {
      this.mOutputStream.write(param1ArrayOfbyte, param1Int1, param1Int2);
    }
    
    public void writeByte(int param1Int) throws IOException {
      this.mOutputStream.write(param1Int);
    }
    
    public void writeInt(int param1Int) throws IOException {
      if (this.mByteOrder == ByteOrder.LITTLE_ENDIAN) {
        this.mOutputStream.write(param1Int >>> 0 & 0xFF);
        this.mOutputStream.write(param1Int >>> 8 & 0xFF);
        this.mOutputStream.write(param1Int >>> 16 & 0xFF);
        this.mOutputStream.write(param1Int >>> 24 & 0xFF);
        return;
      } 
      if (this.mByteOrder == ByteOrder.BIG_ENDIAN) {
        this.mOutputStream.write(param1Int >>> 24 & 0xFF);
        this.mOutputStream.write(param1Int >>> 16 & 0xFF);
        this.mOutputStream.write(param1Int >>> 8 & 0xFF);
        this.mOutputStream.write(param1Int >>> 0 & 0xFF);
      } 
    }
    
    public void writeShort(short param1Short) throws IOException {
      if (this.mByteOrder == ByteOrder.LITTLE_ENDIAN) {
        this.mOutputStream.write(param1Short >>> 0 & 0xFF);
        this.mOutputStream.write(param1Short >>> 8 & 0xFF);
        return;
      } 
      if (this.mByteOrder == ByteOrder.BIG_ENDIAN) {
        this.mOutputStream.write(param1Short >>> 8 & 0xFF);
        this.mOutputStream.write(param1Short >>> 0 & 0xFF);
      } 
    }
    
    public void writeUnsignedInt(long param1Long) throws IOException {
      writeInt((int)param1Long);
    }
    
    public void writeUnsignedShort(int param1Int) throws IOException {
      writeShort((short)param1Int);
    }
  }
  
  private static class ExifAttribute {
    public final byte[] bytes;
    
    public final int format;
    
    public final int numberOfComponents;
    
    private ExifAttribute(int param1Int1, int param1Int2, byte[] param1ArrayOfbyte) {
      this.format = param1Int1;
      this.numberOfComponents = param1Int2;
      this.bytes = param1ArrayOfbyte;
    }
    
    public static ExifAttribute createByte(String param1String) {
      if (param1String.length() == 1 && param1String.charAt(0) >= '0' && param1String.charAt(0) <= '1') {
        byte[] arrayOfByte1 = new byte[1];
        arrayOfByte1[0] = (byte)(param1String.charAt(0) - 48);
        return new ExifAttribute(1, arrayOfByte1.length, arrayOfByte1);
      } 
      byte[] arrayOfByte = param1String.getBytes(ExifInterface.ASCII);
      return new ExifAttribute(1, arrayOfByte.length, arrayOfByte);
    }
    
    public static ExifAttribute createDouble(double param1Double, ByteOrder param1ByteOrder) {
      return createDouble(new double[] { param1Double }, param1ByteOrder);
    }
    
    public static ExifAttribute createDouble(double[] param1ArrayOfdouble, ByteOrder param1ByteOrder) {
      ByteBuffer byteBuffer = ByteBuffer.wrap(new byte[ExifInterface.IFD_FORMAT_BYTES_PER_FORMAT[12] * param1ArrayOfdouble.length]);
      byteBuffer.order(param1ByteOrder);
      int j = param1ArrayOfdouble.length;
      for (int i = 0; i < j; i++)
        byteBuffer.putDouble(param1ArrayOfdouble[i]); 
      return new ExifAttribute(12, param1ArrayOfdouble.length, byteBuffer.array());
    }
    
    public static ExifAttribute createSLong(int param1Int, ByteOrder param1ByteOrder) {
      return createSLong(new int[] { param1Int }, param1ByteOrder);
    }
    
    public static ExifAttribute createSLong(int[] param1ArrayOfint, ByteOrder param1ByteOrder) {
      ByteBuffer byteBuffer = ByteBuffer.wrap(new byte[ExifInterface.IFD_FORMAT_BYTES_PER_FORMAT[9] * param1ArrayOfint.length]);
      byteBuffer.order(param1ByteOrder);
      int j = param1ArrayOfint.length;
      for (int i = 0; i < j; i++)
        byteBuffer.putInt(param1ArrayOfint[i]); 
      return new ExifAttribute(9, param1ArrayOfint.length, byteBuffer.array());
    }
    
    public static ExifAttribute createSRational(ExifInterface.Rational param1Rational, ByteOrder param1ByteOrder) {
      return createSRational(new ExifInterface.Rational[] { param1Rational }, param1ByteOrder);
    }
    
    public static ExifAttribute createSRational(ExifInterface.Rational[] param1ArrayOfRational, ByteOrder param1ByteOrder) {
      ByteBuffer byteBuffer = ByteBuffer.wrap(new byte[ExifInterface.IFD_FORMAT_BYTES_PER_FORMAT[10] * param1ArrayOfRational.length]);
      byteBuffer.order(param1ByteOrder);
      int j = param1ArrayOfRational.length;
      for (int i = 0; i < j; i++) {
        ExifInterface.Rational rational = param1ArrayOfRational[i];
        byteBuffer.putInt((int)rational.numerator);
        byteBuffer.putInt((int)rational.denominator);
      } 
      return new ExifAttribute(10, param1ArrayOfRational.length, byteBuffer.array());
    }
    
    public static ExifAttribute createString(String param1String) {
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append(param1String);
      stringBuilder.append(false);
      byte[] arrayOfByte = stringBuilder.toString().getBytes(ExifInterface.ASCII);
      return new ExifAttribute(2, arrayOfByte.length, arrayOfByte);
    }
    
    public static ExifAttribute createULong(long param1Long, ByteOrder param1ByteOrder) {
      return createULong(new long[] { param1Long }, param1ByteOrder);
    }
    
    public static ExifAttribute createULong(long[] param1ArrayOflong, ByteOrder param1ByteOrder) {
      ByteBuffer byteBuffer = ByteBuffer.wrap(new byte[ExifInterface.IFD_FORMAT_BYTES_PER_FORMAT[4] * param1ArrayOflong.length]);
      byteBuffer.order(param1ByteOrder);
      int j = param1ArrayOflong.length;
      for (int i = 0; i < j; i++)
        byteBuffer.putInt((int)param1ArrayOflong[i]); 
      return new ExifAttribute(4, param1ArrayOflong.length, byteBuffer.array());
    }
    
    public static ExifAttribute createURational(ExifInterface.Rational param1Rational, ByteOrder param1ByteOrder) {
      return createURational(new ExifInterface.Rational[] { param1Rational }, param1ByteOrder);
    }
    
    public static ExifAttribute createURational(ExifInterface.Rational[] param1ArrayOfRational, ByteOrder param1ByteOrder) {
      ByteBuffer byteBuffer = ByteBuffer.wrap(new byte[ExifInterface.IFD_FORMAT_BYTES_PER_FORMAT[5] * param1ArrayOfRational.length]);
      byteBuffer.order(param1ByteOrder);
      int j = param1ArrayOfRational.length;
      for (int i = 0; i < j; i++) {
        ExifInterface.Rational rational = param1ArrayOfRational[i];
        byteBuffer.putInt((int)rational.numerator);
        byteBuffer.putInt((int)rational.denominator);
      } 
      return new ExifAttribute(5, param1ArrayOfRational.length, byteBuffer.array());
    }
    
    public static ExifAttribute createUShort(int param1Int, ByteOrder param1ByteOrder) {
      return createUShort(new int[] { param1Int }, param1ByteOrder);
    }
    
    public static ExifAttribute createUShort(int[] param1ArrayOfint, ByteOrder param1ByteOrder) {
      ByteBuffer byteBuffer = ByteBuffer.wrap(new byte[ExifInterface.IFD_FORMAT_BYTES_PER_FORMAT[3] * param1ArrayOfint.length]);
      byteBuffer.order(param1ByteOrder);
      int j = param1ArrayOfint.length;
      for (int i = 0; i < j; i++)
        byteBuffer.putShort((short)param1ArrayOfint[i]); 
      return new ExifAttribute(3, param1ArrayOfint.length, byteBuffer.array());
    }
    
    private Object getValue(ByteOrder param1ByteOrder) {
      // Byte code:
      //   0: new android/support/media/ExifInterface$ByteOrderedDataInputStream
      //   3: dup
      //   4: aload_0
      //   5: getfield bytes : [B
      //   8: invokespecial <init> : ([B)V
      //   11: astore #14
      //   13: aload #14
      //   15: astore #13
      //   17: aload #14
      //   19: aload_1
      //   20: invokevirtual setByteOrder : (Ljava/nio/ByteOrder;)V
      //   23: aload #14
      //   25: astore #13
      //   27: aload_0
      //   28: getfield format : I
      //   31: istore #12
      //   33: iconst_1
      //   34: istore #5
      //   36: iconst_0
      //   37: istore_3
      //   38: iconst_0
      //   39: istore #6
      //   41: iconst_0
      //   42: istore #7
      //   44: iconst_0
      //   45: istore #8
      //   47: iconst_0
      //   48: istore #9
      //   50: iconst_0
      //   51: istore #10
      //   53: iconst_0
      //   54: istore #11
      //   56: iconst_0
      //   57: istore #4
      //   59: iconst_0
      //   60: istore_2
      //   61: iload #12
      //   63: tableswitch default -> 1093, 1 -> 859, 2 -> 679, 3 -> 613, 4 -> 547, 5 -> 467, 6 -> 859, 7 -> 679, 8 -> 401, 9 -> 335, 10 -> 253, 11 -> 187, 12 -> 124
      //   124: aload #14
      //   126: astore #13
      //   128: aload_0
      //   129: getfield numberOfComponents : I
      //   132: newarray double
      //   134: astore_1
      //   135: aload #14
      //   137: astore #13
      //   139: iload_2
      //   140: aload_0
      //   141: getfield numberOfComponents : I
      //   144: if_icmpge -> 166
      //   147: aload #14
      //   149: astore #13
      //   151: aload_1
      //   152: iload_2
      //   153: aload #14
      //   155: invokevirtual readDouble : ()D
      //   158: dastore
      //   159: iload_2
      //   160: iconst_1
      //   161: iadd
      //   162: istore_2
      //   163: goto -> 135
      //   166: aload #14
      //   168: invokevirtual close : ()V
      //   171: aload_1
      //   172: areturn
      //   173: astore #13
      //   175: ldc 'ExifInterface'
      //   177: ldc 'IOException occurred while closing InputStream'
      //   179: aload #13
      //   181: invokestatic e : (Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I
      //   184: pop
      //   185: aload_1
      //   186: areturn
      //   187: aload #14
      //   189: astore #13
      //   191: aload_0
      //   192: getfield numberOfComponents : I
      //   195: newarray double
      //   197: astore_1
      //   198: iload_3
      //   199: istore_2
      //   200: aload #14
      //   202: astore #13
      //   204: iload_2
      //   205: aload_0
      //   206: getfield numberOfComponents : I
      //   209: if_icmpge -> 232
      //   212: aload #14
      //   214: astore #13
      //   216: aload_1
      //   217: iload_2
      //   218: aload #14
      //   220: invokevirtual readFloat : ()F
      //   223: f2d
      //   224: dastore
      //   225: iload_2
      //   226: iconst_1
      //   227: iadd
      //   228: istore_2
      //   229: goto -> 200
      //   232: aload #14
      //   234: invokevirtual close : ()V
      //   237: aload_1
      //   238: areturn
      //   239: astore #13
      //   241: ldc 'ExifInterface'
      //   243: ldc 'IOException occurred while closing InputStream'
      //   245: aload #13
      //   247: invokestatic e : (Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I
      //   250: pop
      //   251: aload_1
      //   252: areturn
      //   253: aload #14
      //   255: astore #13
      //   257: aload_0
      //   258: getfield numberOfComponents : I
      //   261: anewarray android/support/media/ExifInterface$Rational
      //   264: astore_1
      //   265: iload #6
      //   267: istore_2
      //   268: aload #14
      //   270: astore #13
      //   272: iload_2
      //   273: aload_0
      //   274: getfield numberOfComponents : I
      //   277: if_icmpge -> 314
      //   280: aload #14
      //   282: astore #13
      //   284: aload_1
      //   285: iload_2
      //   286: new android/support/media/ExifInterface$Rational
      //   289: dup
      //   290: aload #14
      //   292: invokevirtual readInt : ()I
      //   295: i2l
      //   296: aload #14
      //   298: invokevirtual readInt : ()I
      //   301: i2l
      //   302: aconst_null
      //   303: invokespecial <init> : (JJLandroid/support/media/ExifInterface$1;)V
      //   306: aastore
      //   307: iload_2
      //   308: iconst_1
      //   309: iadd
      //   310: istore_2
      //   311: goto -> 268
      //   314: aload #14
      //   316: invokevirtual close : ()V
      //   319: aload_1
      //   320: areturn
      //   321: astore #13
      //   323: ldc 'ExifInterface'
      //   325: ldc 'IOException occurred while closing InputStream'
      //   327: aload #13
      //   329: invokestatic e : (Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I
      //   332: pop
      //   333: aload_1
      //   334: areturn
      //   335: aload #14
      //   337: astore #13
      //   339: aload_0
      //   340: getfield numberOfComponents : I
      //   343: newarray int
      //   345: astore_1
      //   346: iload #7
      //   348: istore_2
      //   349: aload #14
      //   351: astore #13
      //   353: iload_2
      //   354: aload_0
      //   355: getfield numberOfComponents : I
      //   358: if_icmpge -> 380
      //   361: aload #14
      //   363: astore #13
      //   365: aload_1
      //   366: iload_2
      //   367: aload #14
      //   369: invokevirtual readInt : ()I
      //   372: iastore
      //   373: iload_2
      //   374: iconst_1
      //   375: iadd
      //   376: istore_2
      //   377: goto -> 349
      //   380: aload #14
      //   382: invokevirtual close : ()V
      //   385: aload_1
      //   386: areturn
      //   387: astore #13
      //   389: ldc 'ExifInterface'
      //   391: ldc 'IOException occurred while closing InputStream'
      //   393: aload #13
      //   395: invokestatic e : (Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I
      //   398: pop
      //   399: aload_1
      //   400: areturn
      //   401: aload #14
      //   403: astore #13
      //   405: aload_0
      //   406: getfield numberOfComponents : I
      //   409: newarray int
      //   411: astore_1
      //   412: iload #8
      //   414: istore_2
      //   415: aload #14
      //   417: astore #13
      //   419: iload_2
      //   420: aload_0
      //   421: getfield numberOfComponents : I
      //   424: if_icmpge -> 446
      //   427: aload #14
      //   429: astore #13
      //   431: aload_1
      //   432: iload_2
      //   433: aload #14
      //   435: invokevirtual readShort : ()S
      //   438: iastore
      //   439: iload_2
      //   440: iconst_1
      //   441: iadd
      //   442: istore_2
      //   443: goto -> 415
      //   446: aload #14
      //   448: invokevirtual close : ()V
      //   451: aload_1
      //   452: areturn
      //   453: astore #13
      //   455: ldc 'ExifInterface'
      //   457: ldc 'IOException occurred while closing InputStream'
      //   459: aload #13
      //   461: invokestatic e : (Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I
      //   464: pop
      //   465: aload_1
      //   466: areturn
      //   467: aload #14
      //   469: astore #13
      //   471: aload_0
      //   472: getfield numberOfComponents : I
      //   475: anewarray android/support/media/ExifInterface$Rational
      //   478: astore_1
      //   479: iload #9
      //   481: istore_2
      //   482: aload #14
      //   484: astore #13
      //   486: iload_2
      //   487: aload_0
      //   488: getfield numberOfComponents : I
      //   491: if_icmpge -> 526
      //   494: aload #14
      //   496: astore #13
      //   498: aload_1
      //   499: iload_2
      //   500: new android/support/media/ExifInterface$Rational
      //   503: dup
      //   504: aload #14
      //   506: invokevirtual readUnsignedInt : ()J
      //   509: aload #14
      //   511: invokevirtual readUnsignedInt : ()J
      //   514: aconst_null
      //   515: invokespecial <init> : (JJLandroid/support/media/ExifInterface$1;)V
      //   518: aastore
      //   519: iload_2
      //   520: iconst_1
      //   521: iadd
      //   522: istore_2
      //   523: goto -> 482
      //   526: aload #14
      //   528: invokevirtual close : ()V
      //   531: aload_1
      //   532: areturn
      //   533: astore #13
      //   535: ldc 'ExifInterface'
      //   537: ldc 'IOException occurred while closing InputStream'
      //   539: aload #13
      //   541: invokestatic e : (Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I
      //   544: pop
      //   545: aload_1
      //   546: areturn
      //   547: aload #14
      //   549: astore #13
      //   551: aload_0
      //   552: getfield numberOfComponents : I
      //   555: newarray long
      //   557: astore_1
      //   558: iload #10
      //   560: istore_2
      //   561: aload #14
      //   563: astore #13
      //   565: iload_2
      //   566: aload_0
      //   567: getfield numberOfComponents : I
      //   570: if_icmpge -> 592
      //   573: aload #14
      //   575: astore #13
      //   577: aload_1
      //   578: iload_2
      //   579: aload #14
      //   581: invokevirtual readUnsignedInt : ()J
      //   584: lastore
      //   585: iload_2
      //   586: iconst_1
      //   587: iadd
      //   588: istore_2
      //   589: goto -> 561
      //   592: aload #14
      //   594: invokevirtual close : ()V
      //   597: aload_1
      //   598: areturn
      //   599: astore #13
      //   601: ldc 'ExifInterface'
      //   603: ldc 'IOException occurred while closing InputStream'
      //   605: aload #13
      //   607: invokestatic e : (Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I
      //   610: pop
      //   611: aload_1
      //   612: areturn
      //   613: aload #14
      //   615: astore #13
      //   617: aload_0
      //   618: getfield numberOfComponents : I
      //   621: newarray int
      //   623: astore_1
      //   624: iload #11
      //   626: istore_2
      //   627: aload #14
      //   629: astore #13
      //   631: iload_2
      //   632: aload_0
      //   633: getfield numberOfComponents : I
      //   636: if_icmpge -> 658
      //   639: aload #14
      //   641: astore #13
      //   643: aload_1
      //   644: iload_2
      //   645: aload #14
      //   647: invokevirtual readUnsignedShort : ()I
      //   650: iastore
      //   651: iload_2
      //   652: iconst_1
      //   653: iadd
      //   654: istore_2
      //   655: goto -> 627
      //   658: aload #14
      //   660: invokevirtual close : ()V
      //   663: aload_1
      //   664: areturn
      //   665: astore #13
      //   667: ldc 'ExifInterface'
      //   669: ldc 'IOException occurred while closing InputStream'
      //   671: aload #13
      //   673: invokestatic e : (Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I
      //   676: pop
      //   677: aload_1
      //   678: areturn
      //   679: iload #4
      //   681: istore_2
      //   682: aload #14
      //   684: astore #13
      //   686: aload_0
      //   687: getfield numberOfComponents : I
      //   690: invokestatic access$100 : ()[B
      //   693: arraylength
      //   694: if_icmplt -> 753
      //   697: iconst_0
      //   698: istore_2
      //   699: iload #5
      //   701: istore_3
      //   702: aload #14
      //   704: astore #13
      //   706: iload_2
      //   707: invokestatic access$100 : ()[B
      //   710: arraylength
      //   711: if_icmpge -> 737
      //   714: aload #14
      //   716: astore #13
      //   718: aload_0
      //   719: getfield bytes : [B
      //   722: iload_2
      //   723: baload
      //   724: invokestatic access$100 : ()[B
      //   727: iload_2
      //   728: baload
      //   729: if_icmpeq -> 1096
      //   732: iconst_0
      //   733: istore_3
      //   734: goto -> 737
      //   737: iload #4
      //   739: istore_2
      //   740: iload_3
      //   741: ifeq -> 753
      //   744: aload #14
      //   746: astore #13
      //   748: invokestatic access$100 : ()[B
      //   751: arraylength
      //   752: istore_2
      //   753: aload #14
      //   755: astore #13
      //   757: new java/lang/StringBuilder
      //   760: dup
      //   761: invokespecial <init> : ()V
      //   764: astore_1
      //   765: aload #14
      //   767: astore #13
      //   769: iload_2
      //   770: aload_0
      //   771: getfield numberOfComponents : I
      //   774: if_icmpge -> 829
      //   777: aload #14
      //   779: astore #13
      //   781: aload_0
      //   782: getfield bytes : [B
      //   785: iload_2
      //   786: baload
      //   787: istore_3
      //   788: iload_3
      //   789: ifne -> 795
      //   792: goto -> 829
      //   795: iload_3
      //   796: bipush #32
      //   798: if_icmplt -> 815
      //   801: aload #14
      //   803: astore #13
      //   805: aload_1
      //   806: iload_3
      //   807: i2c
      //   808: invokevirtual append : (C)Ljava/lang/StringBuilder;
      //   811: pop
      //   812: goto -> 1103
      //   815: aload #14
      //   817: astore #13
      //   819: aload_1
      //   820: bipush #63
      //   822: invokevirtual append : (C)Ljava/lang/StringBuilder;
      //   825: pop
      //   826: goto -> 1103
      //   829: aload #14
      //   831: astore #13
      //   833: aload_1
      //   834: invokevirtual toString : ()Ljava/lang/String;
      //   837: astore_1
      //   838: aload #14
      //   840: invokevirtual close : ()V
      //   843: aload_1
      //   844: areturn
      //   845: astore #13
      //   847: ldc 'ExifInterface'
      //   849: ldc 'IOException occurred while closing InputStream'
      //   851: aload #13
      //   853: invokestatic e : (Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I
      //   856: pop
      //   857: aload_1
      //   858: areturn
      //   859: aload #14
      //   861: astore #13
      //   863: aload_0
      //   864: getfield bytes : [B
      //   867: arraylength
      //   868: iconst_1
      //   869: if_icmpne -> 948
      //   872: aload #14
      //   874: astore #13
      //   876: aload_0
      //   877: getfield bytes : [B
      //   880: iconst_0
      //   881: baload
      //   882: iflt -> 948
      //   885: aload #14
      //   887: astore #13
      //   889: aload_0
      //   890: getfield bytes : [B
      //   893: iconst_0
      //   894: baload
      //   895: iconst_1
      //   896: if_icmpgt -> 948
      //   899: aload #14
      //   901: astore #13
      //   903: new java/lang/String
      //   906: dup
      //   907: iconst_1
      //   908: newarray char
      //   910: dup
      //   911: iconst_0
      //   912: aload_0
      //   913: getfield bytes : [B
      //   916: iconst_0
      //   917: baload
      //   918: bipush #48
      //   920: iadd
      //   921: i2c
      //   922: castore
      //   923: invokespecial <init> : ([C)V
      //   926: astore_1
      //   927: aload #14
      //   929: invokevirtual close : ()V
      //   932: aload_1
      //   933: areturn
      //   934: astore #13
      //   936: ldc 'ExifInterface'
      //   938: ldc 'IOException occurred while closing InputStream'
      //   940: aload #13
      //   942: invokestatic e : (Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I
      //   945: pop
      //   946: aload_1
      //   947: areturn
      //   948: aload #14
      //   950: astore #13
      //   952: new java/lang/String
      //   955: dup
      //   956: aload_0
      //   957: getfield bytes : [B
      //   960: invokestatic access$000 : ()Ljava/nio/charset/Charset;
      //   963: invokespecial <init> : ([BLjava/nio/charset/Charset;)V
      //   966: astore_1
      //   967: aload #14
      //   969: invokevirtual close : ()V
      //   972: aload_1
      //   973: areturn
      //   974: astore #13
      //   976: ldc 'ExifInterface'
      //   978: ldc 'IOException occurred while closing InputStream'
      //   980: aload #13
      //   982: invokestatic e : (Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I
      //   985: pop
      //   986: aload_1
      //   987: areturn
      //   988: aload #14
      //   990: invokevirtual close : ()V
      //   993: aconst_null
      //   994: areturn
      //   995: astore_1
      //   996: ldc 'ExifInterface'
      //   998: ldc 'IOException occurred while closing InputStream'
      //   1000: aload_1
      //   1001: invokestatic e : (Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I
      //   1004: pop
      //   1005: aconst_null
      //   1006: areturn
      //   1007: astore #13
      //   1009: aload #14
      //   1011: astore_1
      //   1012: aload #13
      //   1014: astore #14
      //   1016: goto -> 1030
      //   1019: astore_1
      //   1020: aconst_null
      //   1021: astore #13
      //   1023: goto -> 1066
      //   1026: astore #14
      //   1028: aconst_null
      //   1029: astore_1
      //   1030: aload_1
      //   1031: astore #13
      //   1033: ldc 'ExifInterface'
      //   1035: ldc 'IOException occurred during reading a value'
      //   1037: aload #14
      //   1039: invokestatic w : (Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I
      //   1042: pop
      //   1043: aload_1
      //   1044: ifnull -> 1063
      //   1047: aload_1
      //   1048: invokevirtual close : ()V
      //   1051: aconst_null
      //   1052: areturn
      //   1053: astore_1
      //   1054: ldc 'ExifInterface'
      //   1056: ldc 'IOException occurred while closing InputStream'
      //   1058: aload_1
      //   1059: invokestatic e : (Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I
      //   1062: pop
      //   1063: aconst_null
      //   1064: areturn
      //   1065: astore_1
      //   1066: aload #13
      //   1068: ifnull -> 1091
      //   1071: aload #13
      //   1073: invokevirtual close : ()V
      //   1076: goto -> 1091
      //   1079: astore #13
      //   1081: ldc 'ExifInterface'
      //   1083: ldc 'IOException occurred while closing InputStream'
      //   1085: aload #13
      //   1087: invokestatic e : (Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I
      //   1090: pop
      //   1091: aload_1
      //   1092: athrow
      //   1093: goto -> 988
      //   1096: iload_2
      //   1097: iconst_1
      //   1098: iadd
      //   1099: istore_2
      //   1100: goto -> 699
      //   1103: iload_2
      //   1104: iconst_1
      //   1105: iadd
      //   1106: istore_2
      //   1107: goto -> 765
      // Exception table:
      //   from	to	target	type
      //   0	13	1026	java/io/IOException
      //   0	13	1019	finally
      //   17	23	1007	java/io/IOException
      //   17	23	1065	finally
      //   27	33	1007	java/io/IOException
      //   27	33	1065	finally
      //   128	135	1007	java/io/IOException
      //   128	135	1065	finally
      //   139	147	1007	java/io/IOException
      //   139	147	1065	finally
      //   151	159	1007	java/io/IOException
      //   151	159	1065	finally
      //   166	171	173	java/io/IOException
      //   191	198	1007	java/io/IOException
      //   191	198	1065	finally
      //   204	212	1007	java/io/IOException
      //   204	212	1065	finally
      //   216	225	1007	java/io/IOException
      //   216	225	1065	finally
      //   232	237	239	java/io/IOException
      //   257	265	1007	java/io/IOException
      //   257	265	1065	finally
      //   272	280	1007	java/io/IOException
      //   272	280	1065	finally
      //   284	307	1007	java/io/IOException
      //   284	307	1065	finally
      //   314	319	321	java/io/IOException
      //   339	346	1007	java/io/IOException
      //   339	346	1065	finally
      //   353	361	1007	java/io/IOException
      //   353	361	1065	finally
      //   365	373	1007	java/io/IOException
      //   365	373	1065	finally
      //   380	385	387	java/io/IOException
      //   405	412	1007	java/io/IOException
      //   405	412	1065	finally
      //   419	427	1007	java/io/IOException
      //   419	427	1065	finally
      //   431	439	1007	java/io/IOException
      //   431	439	1065	finally
      //   446	451	453	java/io/IOException
      //   471	479	1007	java/io/IOException
      //   471	479	1065	finally
      //   486	494	1007	java/io/IOException
      //   486	494	1065	finally
      //   498	519	1007	java/io/IOException
      //   498	519	1065	finally
      //   526	531	533	java/io/IOException
      //   551	558	1007	java/io/IOException
      //   551	558	1065	finally
      //   565	573	1007	java/io/IOException
      //   565	573	1065	finally
      //   577	585	1007	java/io/IOException
      //   577	585	1065	finally
      //   592	597	599	java/io/IOException
      //   617	624	1007	java/io/IOException
      //   617	624	1065	finally
      //   631	639	1007	java/io/IOException
      //   631	639	1065	finally
      //   643	651	1007	java/io/IOException
      //   643	651	1065	finally
      //   658	663	665	java/io/IOException
      //   686	697	1007	java/io/IOException
      //   686	697	1065	finally
      //   706	714	1007	java/io/IOException
      //   706	714	1065	finally
      //   718	732	1007	java/io/IOException
      //   718	732	1065	finally
      //   748	753	1007	java/io/IOException
      //   748	753	1065	finally
      //   757	765	1007	java/io/IOException
      //   757	765	1065	finally
      //   769	777	1007	java/io/IOException
      //   769	777	1065	finally
      //   781	788	1007	java/io/IOException
      //   781	788	1065	finally
      //   805	812	1007	java/io/IOException
      //   805	812	1065	finally
      //   819	826	1007	java/io/IOException
      //   819	826	1065	finally
      //   833	838	1007	java/io/IOException
      //   833	838	1065	finally
      //   838	843	845	java/io/IOException
      //   863	872	1007	java/io/IOException
      //   863	872	1065	finally
      //   876	885	1007	java/io/IOException
      //   876	885	1065	finally
      //   889	899	1007	java/io/IOException
      //   889	899	1065	finally
      //   903	927	1007	java/io/IOException
      //   903	927	1065	finally
      //   927	932	934	java/io/IOException
      //   952	967	1007	java/io/IOException
      //   952	967	1065	finally
      //   967	972	974	java/io/IOException
      //   988	993	995	java/io/IOException
      //   1033	1043	1065	finally
      //   1047	1051	1053	java/io/IOException
      //   1071	1076	1079	java/io/IOException
    }
    
    public double getDoubleValue(ByteOrder param1ByteOrder) {
      Object object = getValue(param1ByteOrder);
      if (object != null) {
        if (object instanceof String)
          return Double.parseDouble((String)object); 
        if (object instanceof long[]) {
          object = object;
          if (object.length == 1)
            return object[0]; 
          throw new NumberFormatException("There are more than one component");
        } 
        if (object instanceof int[]) {
          object = object;
          if (object.length == 1)
            return object[0]; 
          throw new NumberFormatException("There are more than one component");
        } 
        if (object instanceof double[]) {
          object = object;
          if (object.length == 1)
            return object[0]; 
          throw new NumberFormatException("There are more than one component");
        } 
        if (object instanceof ExifInterface.Rational[]) {
          object = object;
          if (object.length == 1)
            return object[0].calculate(); 
          throw new NumberFormatException("There are more than one component");
        } 
        throw new NumberFormatException("Couldn't find a double value");
      } 
      throw new NumberFormatException("NULL can't be converted to a double value");
    }
    
    public int getIntValue(ByteOrder param1ByteOrder) {
      Object object = getValue(param1ByteOrder);
      if (object != null) {
        if (object instanceof String)
          return Integer.parseInt((String)object); 
        if (object instanceof long[]) {
          object = object;
          if (object.length == 1)
            return (int)object[0]; 
          throw new NumberFormatException("There are more than one component");
        } 
        if (object instanceof int[]) {
          object = object;
          if (object.length == 1)
            return object[0]; 
          throw new NumberFormatException("There are more than one component");
        } 
        throw new NumberFormatException("Couldn't find a integer value");
      } 
      throw new NumberFormatException("NULL can't be converted to a integer value");
    }
    
    public String getStringValue(ByteOrder param1ByteOrder) {
      Object object = getValue(param1ByteOrder);
      if (object == null)
        return null; 
      if (object instanceof String)
        return (String)object; 
      StringBuilder stringBuilder = new StringBuilder();
      boolean bool = object instanceof long[];
      int j = 0;
      boolean bool1 = false;
      boolean bool2 = false;
      int i = 0;
      if (bool) {
        object = object;
        while (i < object.length) {
          stringBuilder.append(object[i]);
          j = i + 1;
          i = j;
          if (j != object.length) {
            stringBuilder.append(",");
            i = j;
          } 
        } 
        return stringBuilder.toString();
      } 
      if (object instanceof int[]) {
        object = object;
        i = j;
        while (i < object.length) {
          stringBuilder.append(object[i]);
          j = i + 1;
          i = j;
          if (j != object.length) {
            stringBuilder.append(",");
            i = j;
          } 
        } 
        return stringBuilder.toString();
      } 
      if (object instanceof double[]) {
        object = object;
        i = bool1;
        while (i < object.length) {
          stringBuilder.append(object[i]);
          j = i + 1;
          i = j;
          if (j != object.length) {
            stringBuilder.append(",");
            i = j;
          } 
        } 
        return stringBuilder.toString();
      } 
      if (object instanceof ExifInterface.Rational[]) {
        object = object;
        i = bool2;
        while (i < object.length) {
          stringBuilder.append(((ExifInterface.Rational)object[i]).numerator);
          stringBuilder.append('/');
          stringBuilder.append(((ExifInterface.Rational)object[i]).denominator);
          j = i + 1;
          i = j;
          if (j != object.length) {
            stringBuilder.append(",");
            i = j;
          } 
        } 
        return stringBuilder.toString();
      } 
      return null;
    }
    
    public int size() {
      return ExifInterface.IFD_FORMAT_BYTES_PER_FORMAT[this.format] * this.numberOfComponents;
    }
    
    public String toString() {
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("(");
      stringBuilder.append(ExifInterface.IFD_FORMAT_NAMES[this.format]);
      stringBuilder.append(", data length:");
      stringBuilder.append(this.bytes.length);
      stringBuilder.append(")");
      return stringBuilder.toString();
    }
  }
  
  static class ExifTag {
    public final String name;
    
    public final int number;
    
    public final int primaryFormat;
    
    public final int secondaryFormat;
    
    private ExifTag(String param1String, int param1Int1, int param1Int2) {
      this.name = param1String;
      this.number = param1Int1;
      this.primaryFormat = param1Int2;
      this.secondaryFormat = -1;
    }
    
    private ExifTag(String param1String, int param1Int1, int param1Int2, int param1Int3) {
      this.name = param1String;
      this.number = param1Int1;
      this.primaryFormat = param1Int2;
      this.secondaryFormat = param1Int3;
    }
    
    private boolean isFormatCompatible(int param1Int) {
      return (this.primaryFormat != 7) ? ((param1Int == 7) ? true : ((this.primaryFormat != param1Int) ? ((this.secondaryFormat == param1Int) ? true : (((this.primaryFormat == 4 || this.secondaryFormat == 4) && param1Int == 3) ? true : (((this.primaryFormat == 9 || this.secondaryFormat == 9) && param1Int == 8) ? true : (((this.primaryFormat == 12 || this.secondaryFormat == 12) && param1Int == 11))))) : true)) : true;
    }
  }
  
  @Retention(RetentionPolicy.SOURCE)
  @RestrictTo({RestrictTo.Scope.LIBRARY})
  public static @interface IfdType {}
  
  private static class Rational {
    public final long denominator;
    
    public final long numerator;
    
    private Rational(double param1Double) {
      this((long)(param1Double * 10000.0D), 10000L);
    }
    
    private Rational(long param1Long1, long param1Long2) {
      if (param1Long2 == 0L) {
        this.numerator = 0L;
        this.denominator = 1L;
        return;
      } 
      this.numerator = param1Long1;
      this.denominator = param1Long2;
    }
    
    public double calculate() {
      double d1 = this.numerator;
      double d2 = this.denominator;
      Double.isNaN(d1);
      Double.isNaN(d2);
      return d1 / d2;
    }
    
    public String toString() {
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append(this.numerator);
      stringBuilder.append("/");
      stringBuilder.append(this.denominator);
      return stringBuilder.toString();
    }
  }
}


/* Location:              C:\soft\dex2jar-2.0\9 Ball Pool-dex2jar.jar!\android\support\media\ExifInterface.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */